import { hmac } from "@noble/hashes/hmac.js";
import { sha256 } from "@noble/hashes/sha2.js";
import {
  bytes,
  bytesFromHex,
  hexFromBytes,
  randomBytes,
  utf8Bytes
} from "../core/browser-crypto.js";
import {
  normalizeFoundNote
} from "../core/note.js";
import {
  canonicalizeShieldedAddressForOperationHash
} from "../core/crypto.js";

export const reservationStatuses = Object.freeze({
  Discovered: "Discovered",
  Available: "Available",
  Reserved: "Reserved",
  Proving: "Proving",
  ProofReady: "ProofReady",
  Submitted: "Submitted",
  ConfirmedSpent: "ConfirmedSpent",
  Failed: "Failed",
  ReplanRequired: "ReplanRequired",
  Released: "Released",
  Unknown: "Unknown",
  ManualReview: "ManualReview"
});

export const operationStatuses = Object.freeze({
  Planned: "Planned",
  Proving: "Proving",
  ProofReady: "ProofReady",
  Submitted: "Submitted",
  Succeeded: "Succeeded",
  Failed: "Failed",
  ReplanRequired: "ReplanRequired",
  Unknown: "Unknown",
  ManualReview: "ManualReview",
  ConflictSpent: "ConflictSpent"
});

export const activeReservationStatuses = Object.freeze([
  reservationStatuses.Reserved,
  reservationStatuses.Proving,
  reservationStatuses.ProofReady,
  reservationStatuses.Submitted,
  reservationStatuses.Unknown,
  reservationStatuses.ManualReview
]);

const activeReservationStatusSet = new Set(activeReservationStatuses);

const allowedReservationTransitions = new Set([
  "Discovered\x00Available",
  "Discovered\x00Failed",
  "Available\x00Reserved",
  "Reserved\x00Proving",
  "Reserved\x00Released",
  "Reserved\x00ReplanRequired",
  "Reserved\x00ManualReview",
  "Proving\x00ProofReady",
  "Proving\x00Reserved",
  "Proving\x00ReplanRequired",
  "Proving\x00ManualReview",
  "ProofReady\x00Submitted",
  "ProofReady\x00Unknown",
  "ProofReady\x00ConfirmedSpent",
  "ProofReady\x00ReplanRequired",
  "ProofReady\x00ManualReview",
  "Submitted\x00ConfirmedSpent",
  "Submitted\x00Failed",
  "Submitted\x00Unknown",
  "Submitted\x00ReplanRequired",
  "Submitted\x00ManualReview",
  "Unknown\x00ConfirmedSpent",
  "Unknown\x00Failed",
  "Unknown\x00ReplanRequired",
  "Unknown\x00ManualReview",
  "ManualReview\x00ConfirmedSpent",
  "ManualReview\x00Failed",
  "ManualReview\x00Released",
  "ManualReview\x00ReplanRequired",
  "Failed\x00ReplanRequired",
  "Released\x00Available",
  "ReplanRequired\x00Reserved",
  "ReplanRequired\x00Failed",
  "ReplanRequired\x00ManualReview"
]);

const leaseRequiredTransitions = new Set([
  "Reserved\x00Proving",
  "Proving\x00Reserved",
  "Proving\x00ProofReady",
  "Proving\x00ReplanRequired",
  "Proving\x00ManualReview",
  "ProofReady\x00Submitted",
  "ProofReady\x00Unknown",
  "ProofReady\x00ReplanRequired",
  "ProofReady\x00ManualReview"
]);

const expiredLeaseRecoveryTransitions = new Set([
  "Proving\x00ReplanRequired",
  "Proving\x00ManualReview",
  "ProofReady\x00ManualReview"
]);

const defaultLeaseDurationMs = 15 * 60 * 1000;
const defaultHeartbeatIntervalMs = 60 * 1000;
const reconciledSpentTransition = Symbol("reconciledSpentTransition");
const managedReservationEvidenceMutation = Symbol("managedReservationEvidenceMutation");
const managedOperationReconciliation = Symbol("managedOperationReconciliation");
const inProcessMutationQueues = new Map();

function withInProcessMutationLock(lockName, callback) {
  const previous = inProcessMutationQueues.get(lockName) || Promise.resolve();
  let release;
  const current = new Promise(resolve => {
    release = resolve;
  });
  const queueTail = previous.catch(() => {}).then(() => current);
  inProcessMutationQueues.set(lockName, queueTail);
  return previous
    .catch(() => {})
    .then(callback)
    .finally(() => {
      release();
      if (inProcessMutationQueues.get(lockName) === queueTail) {
        inProcessMutationQueues.delete(lockName);
      }
    });
}

function transitionKey(from, to) {
  return `${from}\x00${to}`;
}

export function isActiveReservationStatus(status) {
  return activeReservationStatusSet.has(String(status || ""));
}

export function canTransitionReservation(from, to) {
  return allowedReservationTransitions.has(transitionKey(String(from || ""), String(to || "")));
}

export function canRecoverReservationAfterLeaseExpiry(from, to) {
  return expiredLeaseRecoveryTransitions.has(
    transitionKey(String(from || ""), String(to || ""))
  );
}

export function requiresReservationLeaseToken(from, to) {
  return leaseRequiredTransitions.has(transitionKey(String(from || ""), String(to || "")));
}

export function reservationHeartbeatIntervalMs({
  leaseDurationMs,
  lease_duration_ms,
  leaseUntil,
  lease_until,
  minIntervalMs = 100,
  maxIntervalMs = defaultHeartbeatIntervalMs,
  now = new Date()
} = {}) {
  const durationMs = Number(leaseDurationMs ?? lease_duration_ms ?? 0);
  const leaseUntilMs = Date.parse(leaseUntil || lease_until || "");
  const nowMs = new Date(now).getTime();
  const remainingMs = Number.isFinite(leaseUntilMs) ? leaseUntilMs - nowMs : 0;
  const windows = [durationMs, remainingMs]
    .filter(value => Number.isFinite(value) && value > 0);
  const budgetMs = windows.length ? Math.min(...windows) : defaultLeaseDurationMs;
  const requestedMax = Number(maxIntervalMs) > 0 ? Number(maxIntervalMs) : defaultHeartbeatIntervalMs;
  const requestedMin = Number(minIntervalMs) > 0 ? Number(minIntervalMs) : 1;
  const interval = Math.floor(budgetMs / 3);
  return Math.max(1, Math.min(requestedMax, Math.max(requestedMin, interval || requestedMin)));
}

export function nullifierLookupKey(indexKey, nullifier) {
  const keyBytes = bytes(indexKey);
  if (typeof nullifier === "string" && /^(0x)?[0-9a-fA-F]{64}$/.test(nullifier.trim())) {
    throw new Error("nullifier hex strings must use nullifierLookupKeyFromHex");
  }
  const nullifierBytes = bytes(nullifier);
  if (!keyBytes.length) {
    throw new Error("index key is required");
  }
  if (!nullifierBytes.length) {
    throw new Error("nullifier is required");
  }
  return hexFromBytes(hmac(sha256, keyBytes, nullifierBytes));
}

export function nullifierLookupKeyFromHex(indexKey, nullifierHex) {
  const normalized = String(nullifierHex ?? "").trim().replace(/^0x/i, "");
  if (!/^[0-9a-fA-F]{64}$/.test(normalized)) {
    throw new Error("nullifier must be exactly 32 bytes of hex");
  }
  return nullifierLookupKey(indexKey, bytesFromHex(normalized, "nullifier"));
}

/** Go-compatible SHA-256 commitment used by payment/payroll operation evidence. */
export function hashRecipient(recipient, options = {}) {
  const normalizedRecipient = String(recipient ?? "").trim();
  if (!normalizedRecipient) {
    throw new Error("recipient is required");
  }
  let canonicalRecipient;
  try {
    canonicalRecipient = canonicalizeShieldedAddressForOperationHash(normalizedRecipient, options);
  } catch {
    throw new Error("recipient must be a valid shielded address");
  }
  return hexFromBytes(sha256(utf8Bytes(canonicalRecipient)));
}

/** Go-compatible SHA-256 commitment over the canonical `denom:amount` string. */
export function hashAmount(denom, amount) {
  if (typeof denom !== "string") {
    throw new Error("denom must be a valid Cosmos SDK denomination string");
  }
  const rawDenom = denom;
  const normalizedDenom = rawDenom.trim();
  if (
    rawDenom !== normalizedDenom ||
    !/^[A-Za-z][A-Za-z0-9/:._-]{2,127}$/.test(normalizedDenom)
  ) {
    throw new Error("denom must be a valid Cosmos SDK denomination");
  }
  if (amount === undefined || amount === null || amount === "") {
    throw new Error("amount is required");
  }
  if (!["bigint", "number", "string"].includes(typeof amount)) {
    throw new Error("amount must be a safe integer, bigint, or canonical uint64 string");
  }
  if (typeof amount === "number" && !Number.isSafeInteger(amount)) {
    throw new Error("amount must be a safe integer, bigint, or canonical uint64 string");
  }
  if (typeof amount === "string" && !/^(0|[1-9][0-9]*)$/.test(amount)) {
    throw new Error("amount must be a canonical uint64 decimal string");
  }
  let normalizedAmount;
  try {
    normalizedAmount = BigInt(amount);
  } catch {
    throw new Error("amount must be a safe integer, bigint, or canonical uint64 string");
  }
  if (normalizedAmount < 0n || normalizedAmount > 18446744073709551615n) {
    throw new Error("amount must be within uint64 range");
  }
  return hexFromBytes(sha256(utf8Bytes(`${normalizedDenom}:${normalizedAmount}`)));
}

function nowIso(now = new Date()) {
  return new Date(now).toISOString();
}

function randomHex(bytesLength = 16) {
  return hexFromBytes(randomBytes(bytesLength));
}

function futureIso(now, durationMs = defaultLeaseDurationMs) {
  return new Date(new Date(now).getTime() + durationMs).toISOString();
}

function normalizedBatchItemIndex(value) {
  const provided = value !== undefined && value !== null && value !== "";
  if (!provided) {
    return { value: 0, valid: true, provided: false };
  }
  const parsed = typeof value === "number" ? value : Number(String(value).trim());
  if (!Number.isSafeInteger(parsed) || parsed < 0) {
    return { value: 0, valid: false, provided: true };
  }
  return { value: parsed, valid: true, provided: true };
}

function normalizeStatus(status, fallback = reservationStatuses.Reserved) {
  return String(status || fallback);
}

function cloneJSON(value) {
  return value == null ? value : JSON.parse(JSON.stringify(value));
}

export function noteNullifierHex(noteLike) {
  const direct = noteLike?.nullifier_hex ?? noteLike?.nullifierHex ?? noteLike?.nullifier;
  if (direct) {
    return String(direct).trim().replace(/^0x/i, "").toLowerCase();
  }
  return String(normalizeFoundNote(noteLike).nullifier || "").trim().replace(/^0x/i, "").toLowerCase();
}

export function noteReservationIdentity(noteLike) {
  const found = normalizeFoundNote(noteLike);
  const nullifierHex = noteNullifierHex(noteLike);
  if (!nullifierHex) {
    throw new Error("note nullifier is required for reservation");
  }
  const height = Number(found.height || 0);
  const sequence = Number(found.sequence || 0);
  const txHash = String(found.txHash || noteLike?.tx_hash || "").toUpperCase();
  return {
    nullifierHex,
    noteId: String(
      noteLike?.note_id ??
      noteLike?.noteId ??
      `${height}:${sequence}:${txHash}`
    ),
    amount: found.note.amount.toString(),
    height,
    sequence,
    txHash
  };
}

export function selectedReservationNotesFromPlan(plan) {
  if (!plan) return [];
  if (Array.isArray(plan.selection?.inputs)) {
    return plan.selection.inputs;
  }
  if (Array.isArray(plan.selections)) {
    return plan.selections.flatMap(selection => selection?.inputs || []);
  }
  if (plan.selectedNote) {
    return [plan.selectedNote];
  }
  return [];
}

function normalizeReservation(input = {}) {
  const status = normalizeStatus(input.status);
  const createdAt = input.created_at || input.createdAt || nowIso();
  const updatedAt = input.updated_at || input.updatedAt || createdAt;
  const reservationID = String(input.reservation_id || input.reservationID || input.reservationId || "");
  const operationID = String(input.operation_id || input.operationID || input.operationId || "");
  const ownerKeyID = String(input.owner_key_id || input.ownerKeyID || input.ownerKeyId || "");
  const nullifierLookupKeyValue = String(input.nullifier_lookup_key || input.nullifierLookupKey || "");
  const batchItemIndex = normalizedBatchItemIndex(
    firstDefined(input.batch_item_index, input.batchItemIndex, "")
  );
  const batchItemIndexKnown = booleanEvidence(firstDefined(
    input.batch_item_index_known,
    input.batchItemIndexKnown,
    false
  ));
  if (!reservationID) throw new Error("reservation_id is required");
  if (!ownerKeyID) throw new Error("owner_key_id is required");
  if (!nullifierLookupKeyValue) throw new Error("nullifier_lookup_key is required");
  if (batchItemIndexKnown && (!batchItemIndex.valid || !batchItemIndex.provided)) {
    throw new Error("batch_item_index must be a non-negative safe integer when known");
  }
  return {
    reservation_id: reservationID,
    operation_id: operationID,
    owner_key_id: ownerKeyID,
    nullifier_lookup_key: nullifierLookupKeyValue,
    nullifier_lookup_key_id: String(input.nullifier_lookup_key_id || input.nullifierLookupKeyID || input.nullifierLookupKeyId || ""),
    status,
    lease_owner: String(input.lease_owner || input.leaseOwner || ""),
    lease_token: String(input.lease_token || input.leaseToken || ""),
    lease_until: String(input.lease_until || input.leaseUntil || ""),
    last_heartbeat_at: String(input.last_heartbeat_at || input.lastHeartbeatAt || ""),
    kind: String(input.kind || input.operation_kind || input.operationKind || ""),
    note_id: String(input.note_id || input.noteID || input.noteId || ""),
    amount: String(input.amount || ""),
    tx_hash: String(input.tx_hash || input.txHash || "").toUpperCase(),
    height: Number(input.height || 0),
    sequence: Number(input.sequence || 0),
    payload_hash: String(input.payload_hash || input.payloadHash || ""),
    expected_output_commitment: String(input.expected_output_commitment || input.expectedOutputCommitment || ""),
    expected_disclosure_digest: String(input.expected_disclosure_digest || input.expectedDisclosureDigest || ""),
    expected_recipient_hash: String(input.expected_recipient_hash || input.expectedRecipientHash || ""),
    expected_amount: String(firstDefined(input.expected_amount, input.expectedAmount, "")),
    expected_amount_hash: String(input.expected_amount_hash || input.expectedAmountHash || ""),
    expected_denom: String(input.expected_denom || input.expectedDenom || ""),
    batch_item_index: batchItemIndex.value,
    batch_item_index_known: batchItemIndexKnown,
    sign_doc_hash: String(input.sign_doc_hash || input.signDocHash || ""),
    tx_bytes_hash: String(input.tx_bytes_hash || input.txBytesHash || ""),
    submitted_tx_hash: String(input.submitted_tx_hash || input.submittedTxHash || input.txHashSubmitted || ""),
    broadcast_attempt_count: Number(input.broadcast_attempt_count || input.broadcastAttemptCount || 0),
    broadcast_in_flight: input.broadcast_in_flight === true || input.broadcastInFlight === true,
    last_broadcast_error: String(input.last_broadcast_error || input.lastBroadcastError || ""),
    created_at: createdAt,
    updated_at: updatedAt,
    metadata: cloneJSON(input.metadata || {})
  };
}

const initialLifecycleMetadataFields = new Set([
  "relay_handed_off",
  "relay_handed_off_at",
  "broadcast_attempt_started_at",
  "broadcast_attempt_reason",
  "no_broadcast_attempt",
  "proof_discarded",
  "operator_approved",
  "operator_id",
  "operator_approval_reference",
  "operation_status",
  "operation_success_evidence_matches",
  "operation_success_evidence_errors"
]);

function assertInitialReservationRecord(reservation) {
  if (reservation.status !== reservationStatuses.Reserved) {
    throw new Error("new reservations must start as Reserved");
  }
  if (
    reservation.lease_owner ||
    reservation.lease_token ||
    reservation.lease_until ||
    reservation.last_heartbeat_at ||
    reservation.payload_hash ||
    reservation.expected_output_commitment ||
    reservation.expected_disclosure_digest ||
    reservation.expected_recipient_hash ||
    reservation.expected_amount ||
    reservation.expected_amount_hash ||
    reservation.expected_denom ||
    reservation.batch_item_index_known ||
    reservation.batch_item_index !== 0 ||
    reservation.sign_doc_hash ||
    reservation.tx_bytes_hash ||
    reservation.submitted_tx_hash ||
    reservation.broadcast_attempt_count ||
    reservation.broadcast_in_flight ||
    reservation.last_broadcast_error
  ) {
    throw new Error("new reservations cannot include lifecycle, broadcast, or relay evidence");
  }
  const metadata = reservation.metadata || {};
  if (
    Object.keys(metadata).some(
      key => initialLifecycleMetadataFields.has(key) && metadata[key] !== undefined && metadata[key] !== null && metadata[key] !== "" && metadata[key] !== false,
    )
  ) {
    throw new Error("new reservations cannot include lifecycle evidence metadata");
  }
}

function activeKey(reservation) {
  return `${reservation.owner_key_id}\x00${reservation.nullifier_lookup_key}`;
}

function normalizeState(state = {}) {
  return {
    version: 1,
    reservations: (state.reservations || []).map(normalizeReservation)
  };
}

function activeConflict(reservations, candidate, excludeReservationID = "") {
  if (!isActiveReservationStatus(candidate.status)) return false;
  const key = activeKey(candidate);
  return reservations.some(reservation =>
    reservation.reservation_id !== excludeReservationID &&
    isActiveReservationStatus(reservation.status) &&
    activeKey(reservation) === key
  );
}

function confirmedSpentConflict(reservations, candidate, excludeReservationID = "") {
  if (!isActiveReservationStatus(candidate.status)) return false;
  const key = activeKey(candidate);
  return reservations.some(reservation =>
    reservation.reservation_id !== excludeReservationID &&
    reservation.status === reservationStatuses.ConfirmedSpent &&
    activeKey(reservation) === key
  );
}

function patchLeaseToken(patch = {}) {
  return String(patch.lease_token || patch.leaseToken || "");
}

function patchLeaseOwner(patch = {}) {
  return String(patch.lease_owner || patch.leaseOwner || "");
}

function leaseExpirationMs(reservation) {
  const value = Date.parse(reservation.lease_until || "");
  return Number.isFinite(value) ? value : 0;
}

function assertCurrentLeaseToken(current, token, owner, now) {
  if (!token) {
    throw new Error("lease token is required");
  }
  if (!current.lease_token || token !== current.lease_token) {
    throw new Error("reservation lease token mismatch");
  }
  if (!owner) {
    throw new Error("lease owner is required");
  }
  if (!current.lease_owner || owner !== current.lease_owner) {
    throw new Error("reservation lease owner mismatch");
  }
  if (leaseExpirationMs(current) <= new Date(now).getTime()) {
    throw new Error("reservation lease expired");
  }
}

function isLeaseExpiredError(error) {
  return /reservation lease expired/.test(error?.message || "");
}

function assertLeaseTransitionAllowed(current, to, patch, now) {
  if (!requiresReservationLeaseToken(current.status, to)) return;
  if (
    current.status === reservationStatuses.Reserved &&
    to === reservationStatuses.Proving &&
    !current.lease_token
  ) {
    const token = patchLeaseToken(patch);
    const owner = String(patch.lease_owner || patch.leaseOwner || "");
    const until = Date.parse(patch.lease_until || patch.leaseUntil || "");
    if (!token || !owner || !Number.isFinite(until)) {
      throw new Error("a future lease owner, token, and expiry are required to start proving");
    }
    if (until <= new Date(now).getTime()) throw new Error("reservation lease expired");
    return;
  }
  const leaseExpiresAt = leaseExpirationMs(current);
  const recoveryAfterExpiredWorkerLease =
    canRecoverReservationAfterLeaseExpiry(current.status, to) &&
    leaseExpiresAt > 0 &&
    leaseExpiresAt <= new Date(now).getTime();
  if (recoveryAfterExpiredWorkerLease) return;
  const token = patchLeaseToken(patch);
  const owner = patchLeaseOwner(patch);
  try {
    assertCurrentLeaseToken(current, token, owner, now);
  } catch (error) {
    if (/lease token is required/.test(error?.message || "")) {
      throw new Error(`lease token is required for reservation transition: ${current.status} -> ${to}`);
    }
    throw error;
  }
}

function isLeaseRenewalPatch(current, to, patch = {}) {
  if (current.status !== to) return false;
  return ["lease_owner", "leaseOwner", "lease_token", "leaseToken", "lease_until", "leaseUntil", "last_heartbeat_at", "lastHeartbeatAt"]
    .some(key => Object.prototype.hasOwnProperty.call(patch, key));
}

const sameStatusLeasePatchFields = new Set([
  "lease_owner", "leaseOwner",
  "lease_token", "leaseToken",
  "lease_until", "leaseUntil",
  "last_heartbeat_at", "lastHeartbeatAt",
  "updated_at", "updatedAt"
]);

const writeOnceReservationEvidenceFields = [
  ["payload_hash", "payloadHash"],
  ["submitted_tx_hash", "submittedTxHash", "txHashSubmitted"],
  ["tx_bytes_hash", "txBytesHash"],
  ["sign_doc_hash", "signDocHash"]
];

const operationSuccessPredicateFields = [
  ["expected_output_commitment", "expectedOutputCommitment"],
  ["expected_disclosure_digest", "expectedDisclosureDigest"],
  ["expected_recipient_hash", "expectedRecipientHash"],
  ["expected_amount", "expectedAmount"],
  ["expected_amount_hash", "expectedAmountHash"],
  ["expected_denom", "expectedDenom"],
  ["batch_item_index", "batchItemIndex"],
  ["batch_item_index_known", "batchItemIndexKnown"]
];

const operationOutcomeMetadataFields = new Set([
  "operation_status",
  "operation_success_evidence_matches",
  "operation_success_evidence_errors"
]);

const protectedMetadataEvidenceFields = [
  "relay_handed_off",
  "relay_handed_off_at",
  "broadcast_attempt_started_at",
  "broadcast_attempt_reason",
  "operation_status",
  "operation_success_evidence_matches",
  "operation_success_evidence_errors",
  "operation_success_evidence_required",
  "operator_approved",
  "operator_id",
  "operator_approval_reference",
  "manual_review_resolution_reason"
];

function patchHasAnyOwnProperty(patch = {}, keys = []) {
  return keys.some(key => Object.prototype.hasOwnProperty.call(patch, key));
}

function patchValueForAliases(patch = {}, keys = []) {
  return firstDefined(...keys.map(key => patch[key]));
}

function assertReservationEvidencePatchMonotonic(current, patch = {}, {
  allowOperationOutcomeMutation = false
} = {}) {
  for (const aliases of writeOnceReservationEvidenceFields) {
    if (!patchHasAnyOwnProperty(patch, aliases)) continue;
    const field = aliases[0];
    const existing = String(current[field] || "");
    const incoming = String(patchValueForAliases(patch, aliases) || "");
    if (!incoming) {
      if (existing) {
        throw new Error(`${field} cannot be cleared through reservation mutation`);
      }
      continue;
    }
    if (existing && incoming !== existing) {
      throw new Error(`${field} is write-once once broadcast evidence is recorded`);
    }
  }
  if (Object.prototype.hasOwnProperty.call(patch, "broadcast_attempt_count") ||
      Object.prototype.hasOwnProperty.call(patch, "broadcastAttemptCount")) {
    const nextCount = Number(patch.broadcast_attempt_count ?? patch.broadcastAttemptCount);
    const currentCount = Number(current.broadcast_attempt_count || 0);
    if (!Number.isSafeInteger(nextCount) || nextCount < currentCount) {
      throw new Error("broadcast_attempt_count cannot decrease through reservation mutation");
    }
  }
  if (!Object.prototype.hasOwnProperty.call(patch, "metadata")) return;
  const nextMetadata = patch.metadata;
  if (!nextMetadata || typeof nextMetadata !== "object" || Array.isArray(nextMetadata)) {
    throw new Error("reservation metadata evidence cannot be cleared through mutation");
  }
  for (const field of protectedMetadataEvidenceFields) {
    if (allowOperationOutcomeMutation && operationOutcomeMetadataFields.has(field)) continue;
    const existing = current.metadata?.[field];
    if (existing === undefined || existing === null || existing === "") continue;
    if (!Object.prototype.hasOwnProperty.call(nextMetadata, field) ||
        JSON.stringify(nextMetadata[field]) !== JSON.stringify(existing)) {
      throw new Error(`${field} metadata evidence cannot be replaced or cleared through reservation mutation`);
    }
  }
}

function comparablePredicateValue(field, value) {
  if (field === "batch_item_index") return Number(value || 0);
  if (field === "batch_item_index_known") return value === true;
  return String(value || "");
}

function assertOperationSuccessPredicateImmutable(current, to, patch = {}) {
  const initializing = current.status === reservationStatuses.Proving && to === reservationStatuses.ProofReady;
  for (const aliases of operationSuccessPredicateFields) {
    if (!patchHasAnyOwnProperty(patch, aliases)) continue;
    const field = aliases[0];
    const existing = comparablePredicateValue(field, current[field]);
    const incoming = comparablePredicateValue(field, patchValueForAliases(patch, aliases));
    if (!initializing && incoming !== existing) {
      throw new Error(`${field} is write-once after ProofReady success evidence is established`);
    }
  }
  if (!Object.prototype.hasOwnProperty.call(patch, "metadata")) return;
  const metadata = patch.metadata;
  if (!metadata || typeof metadata !== "object" || Array.isArray(metadata)) return;
  if (!Object.prototype.hasOwnProperty.call(metadata, "operation_success_evidence_required")) return;
  const existing = current.metadata?.operation_success_evidence_required === true;
  const incoming = metadata.operation_success_evidence_required === true;
  if (!initializing && incoming !== existing) {
    throw new Error("operation_success_evidence_required is write-once after ProofReady success evidence is established");
  }
}

const commonReservationPatchFields = new Set([
  "updated_at", "updatedAt", "metadata",
  "lease_owner", "leaseOwner", "lease_token", "leaseToken",
  "lease_until", "leaseUntil", "last_heartbeat_at", "lastHeartbeatAt"
]);
const broadcastReservationPatchFields = new Set([
  "submitted_tx_hash", "submittedTxHash", "txHashSubmitted",
  "tx_bytes_hash", "txBytesHash", "sign_doc_hash", "signDocHash",
  "broadcast_attempt_count", "broadcastAttemptCount",
  "broadcast_in_flight", "broadcastInFlight",
  "last_broadcast_error", "lastBroadcastError"
]);
const reconciliationReservationPatchFields = new Set([
  "nullifier_unspent_confirmed", "nullifierUnspentConfirmed",
  "checked_height", "checkedHeight",
  "tx_hash_checked", "txHashChecked",
  "tx_absent_or_failed_confirmed", "txAbsentOrFailedConfirmed",
  "proof_discarded", "proofDiscarded",
  "authoritative_expiry_confirmed", "authoritativeExpiryConfirmed"
]);

function allowedReservationPatchFields(current, to, {
  managedRelayHandoff = false,
  managedBroadcastAttempt = false,
  managedOperationReconcile = false
} = {}) {
  const allowed = new Set(commonReservationPatchFields);
  if (to === reservationStatuses.ProofReady && current.status === reservationStatuses.Proving) {
    for (const aliases of operationSuccessPredicateFields) {
      for (const alias of aliases) allowed.add(alias);
    }
    allowed.add("payload_hash");
    allowed.add("payloadHash");
    allowed.add("sign_doc_hash");
    allowed.add("signDocHash");
    allowed.add("tx_bytes_hash");
    allowed.add("txBytesHash");
  }
  if (managedRelayHandoff) {
    allowed.add("payload_hash");
    allowed.add("payloadHash");
  }
  if (managedBroadcastAttempt) {
    for (const field of broadcastReservationPatchFields) allowed.add(field);
  }
  if ([
    reservationStatuses.Submitted,
    reservationStatuses.Unknown,
    reservationStatuses.ReplanRequired,
    reservationStatuses.Failed,
    reservationStatuses.ManualReview
  ].includes(to)) {
    for (const field of broadcastReservationPatchFields) allowed.add(field);
    for (const field of reconciliationReservationPatchFields) allowed.add(field);
  }
  if (managedOperationReconcile) {
    return new Set(["updated_at", "updatedAt", "metadata"]);
  }
  return allowed;
}

function assertReservationTransitionPatchFields(current, to, patch = {}, options = {}) {
  const allowed = allowedReservationPatchFields(current, to, options);
  const disallowed = Object.keys(patch).find(field => !allowed.has(field));
  if (disallowed) {
    throw new Error(`reservation patch field is not allowed for ${current.status} -> ${to}: ${disallowed}`);
  }
}

function assertManagedOperationReconciliation(current, to, patch = {}) {
  if (patch[managedOperationReconciliation] !== true) return false;
  if (to !== current.status && to !== reservationStatuses.ConfirmedSpent) {
    throw new Error("managed operation reconciliation may only retain status or quarantine a spent note");
  }
  const metadata = patch.metadata;
  if (!metadata || typeof metadata !== "object" || Array.isArray(metadata)) {
    throw new Error("managed operation reconciliation requires operation outcome metadata");
  }
  for (const [field, value] of Object.entries(current.metadata || {})) {
    if (operationOutcomeMetadataFields.has(field)) continue;
    if (!Object.prototype.hasOwnProperty.call(metadata, field) ||
        JSON.stringify(metadata[field]) !== JSON.stringify(value)) {
      throw new Error(`${field} metadata cannot change during operation reconciliation`);
    }
  }
  const unexpected = Object.keys(metadata).find(field =>
    !operationOutcomeMetadataFields.has(field) &&
    !Object.prototype.hasOwnProperty.call(current.metadata || {}, field)
  );
  if (unexpected) {
    throw new Error(`${unexpected} metadata cannot be added during operation reconciliation`);
  }
  return true;
}

function assertSameStatusLeaseRenewalPatch(current, patch = {}, now) {
  const keys = Object.keys(patch);
  if (!keys.some(key => sameStatusLeasePatchFields.has(key)) ||
      keys.some(key => !sameStatusLeasePatchFields.has(key))) {
    throw new Error("same-status reservation mutations are limited to lease renewal fields");
  }
  const leaseUntil = Date.parse(String(patch.lease_until || patch.leaseUntil || ""));
  if (!Number.isFinite(leaseUntil) || leaseUntil <= new Date(now).getTime()) {
    throw new Error("same-status lease renewal requires a future lease_until");
  }
  const existingLeaseUntil = leaseExpirationMs(current);
  if (existingLeaseUntil > leaseUntil) {
    throw new Error("same-status lease renewal cannot shorten an existing lease");
  }
  assertCurrentLeaseToken(current, patchLeaseToken(patch), patchLeaseOwner(patch), now);
}

function isManagedRelayHandoffMutation(current, to, patch = {}) {
  return patch[managedReservationEvidenceMutation] === "relay_handoff" &&
    current.status === reservationStatuses.ProofReady &&
    to === reservationStatuses.ProofReady;
}

function isManagedBroadcastAttemptMutation(current, to, patch = {}) {
  return patch[managedReservationEvidenceMutation] === "broadcast_attempt" &&
    current.status === reservationStatuses.ProofReady &&
    to === reservationStatuses.ProofReady;
}

function assertManagedBroadcastAttemptMutation(current, to, patch, now) {
  if (!isManagedBroadcastAttemptMutation(current, to, patch)) return false;
  if (current.broadcast_in_flight || Number(current.broadcast_attempt_count || 0) > 0) {
    throw new Error("broadcast attempt already started; reconcile before retry");
  }
  if (patch.broadcast_in_flight !== true) {
    throw new Error("broadcast attempt must set broadcast_in_flight");
  }
  if (Number(patch.broadcast_attempt_count) !== Number(current.broadcast_attempt_count || 0) + 1) {
    throw new Error("broadcast attempt count must increase exactly once");
  }
  if (patch.metadata?.no_broadcast_attempt !== false) {
    throw new Error("broadcast attempt must clear no_broadcast_attempt evidence");
  }
  assertCurrentLeaseToken(current, patchLeaseToken(patch), patchLeaseOwner(patch), now);
  return true;
}

function isManagedBroadcastRejectionMutation(current, to, patch = {}) {
  return patch[managedReservationEvidenceMutation] === "broadcast_rejected" &&
    current.status === reservationStatuses.ProofReady &&
    to === reservationStatuses.ReplanRequired;
}

function assertManagedBroadcastRejectionMutation(current, to, patch, now) {
  if (!isManagedBroadcastRejectionMutation(current, to, patch)) return false;
  if (!current.broadcast_in_flight || Number(current.broadcast_attempt_count || 0) < 1) {
    throw new Error("wallet rejection resolution requires a durable in-flight broadcast attempt");
  }
  if (
    patch.metadata?.wallet_rejected_before_broadcast !== true ||
    patch.metadata?.no_broadcast_attempt !== true ||
    patch.metadata?.proof_discarded !== true
  ) {
    throw new Error("wallet rejection resolution requires definitive no-broadcast and proof-discard evidence");
  }
  assertCurrentLeaseToken(current, patchLeaseToken(patch), patchLeaseOwner(patch), now);
  return true;
}

function assertManagedRelayHandoffMutation(current, to, patch, now) {
  if (!isManagedRelayHandoffMutation(current, to, patch)) return false;
  const metadata = patch.metadata;
  if (!metadata || !booleanEvidence(metadata.relay_handed_off)) {
    throw new Error("relay handoff evidence requires relay_handed_off metadata");
  }
  const payloadHash = String(patch.payload_hash || patch.payloadHash || "");
  if (!payloadHash || !current.payload_hash || payloadHash !== current.payload_hash) {
    throw new Error("relay handoff payload hash must match the ProofReady reservation");
  }
  assertCurrentLeaseToken(current, patchLeaseToken(patch), patchLeaseOwner(patch), now);
  return true;
}

function assertStoreLeaseMutationAllowed(current, to, patch, now) {
  if (requiresReservationLeaseToken(current.status, to)) {
    if (
      canRecoverReservationAfterLeaseExpiry(current.status, to) &&
      leaseExpirationMs(current) > 0 &&
      leaseExpirationMs(current) <= new Date(now).getTime()
    ) {
      return;
    }
    assertLeaseTransitionAllowed(current, to, patch, now);
    return;
  }
  if (isLeaseRenewalPatch(current, to, patch)) {
    assertCurrentLeaseToken(current, patchLeaseToken(patch), patchLeaseOwner(patch), now);
  }
}

function clearsLeaseForStatusTransition(to) {
  return ![
    reservationStatuses.Proving,
    reservationStatuses.ProofReady
  ].includes(to);
}

function patchWithClearedLease(to, patch = {}) {
  if (!clearsLeaseForStatusTransition(to)) return patch;
  return {
    ...patch,
    lease_owner: "",
    lease_token: "",
    lease_until: "",
    last_heartbeat_at: "",
    broadcast_in_flight: false
  };
}

function leaseUntilFromMetadata(metadata = {}, now, fallbackDurationMs) {
  const explicitLeaseUntil = metadata.leaseUntil || metadata.lease_until;
  const leaseUntil = explicitLeaseUntil
    ? nowIso(explicitLeaseUntil)
    : futureIso(now, Number(metadata.leaseDurationMs || metadata.lease_duration_ms || fallbackDurationMs));
  if (Date.parse(leaseUntil) <= new Date(now).getTime()) {
    throw new Error("reservation lease renewal must extend into the future");
  }
  return leaseUntil;
}

function broadcastAttemptMetadata(metadata = {}) {
  return {
    txHash: String(metadata.txHash || metadata.tx_hash || metadata.submitted_tx_hash || metadata.submittedTxHash || metadata.txHashSubmitted || ""),
    txBytesHash: String(metadata.txBytesHash || metadata.tx_bytes_hash || ""),
    signDocHash: String(metadata.signDocHash || metadata.sign_doc_hash || "")
  };
}

function hasBroadcastAttemptMetadata(metadata = {}) {
  const attempt = broadcastAttemptMetadata(metadata);
  return Boolean(attempt.txHash || attempt.txBytesHash || attempt.signDocHash);
}

function hasSubmittedBroadcastAttemptMetadata(metadata = {}) {
  const attempt = broadcastAttemptMetadata(metadata);
  return Boolean(attempt.txHash || attempt.txBytesHash);
}

function assertBroadcastAttemptMetadata(metadata = {}, status = "reservation transition") {
  if (!hasBroadcastAttemptMetadata(metadata)) {
    throw new Error(`${status} requires broadcast attempt metadata`);
  }
}

function assertSubmittedBroadcastAttemptMetadata(metadata = {}, status = "reservation transition") {
  if (!hasSubmittedBroadcastAttemptMetadata(metadata)) {
    throw new Error(`${status} requires submitted tx hash or tx bytes hash`);
  }
}

function assertCoreTransitionEvidence(from, to, patch = {}) {
  if (to === reservationStatuses.ConfirmedSpent) {
    if (!patch[reconciledSpentTransition]) {
      throw new Error("ConfirmedSpent transitions require reconcileSpentNotes chain spent evidence");
    }
    return;
  }
  if (from !== reservationStatuses.ProofReady) return;
  if (to === reservationStatuses.Submitted) {
    assertSubmittedBroadcastAttemptMetadata(patch, "ProofReady -> Submitted");
  } else if (to === reservationStatuses.Unknown) {
    assertBroadcastAttemptMetadata(patch, "ProofReady -> Unknown");
  }
}

function assertStoreTransitionEvidence(current, to, patch = {}) {
  assertCoreTransitionEvidence(current.status, to, patch);
  assertInactiveTransitionEvidence(current, to, patch);
}

function metadataEvidenceValue(input = {}, ...keys) {
  const nested = metadataObject(input);
  return firstDefined(
    ...keys.flatMap(key => [input[key], nested[key]])
  );
}

function hasStoredBroadcastEvidence(reservation = {}) {
  return Boolean(
    reservation.submitted_tx_hash ||
    reservation.tx_bytes_hash ||
    reservation.sign_doc_hash ||
    Number(reservation.broadcast_attempt_count || 0) > 0 ||
    booleanEvidence(reservation.metadata?.relay_handed_off) ||
    booleanEvidence(reservation.metadata?.relayHandedOff)
  );
}

function hasProofDiscardEvidence(reservation = {}, metadata = {}) {
  return Boolean(
    booleanEvidence(metadataEvidenceValue(metadata, "no_broadcast_attempt", "noBroadcastAttempt")) &&
    booleanEvidence(metadataEvidenceValue(metadata, "proof_discarded", "proofDiscarded")) &&
    !hasStoredBroadcastEvidence(reservation)
  );
}

function hasManualReviewApprovalEvidence(metadata = {}) {
  const approved = booleanEvidence(metadataEvidenceValue(
    metadata,
    "operator_approved",
    "operatorApproved",
    "manual_review_approved",
    "manualReviewApproved"
  ));
  const reference = String(metadataEvidenceValue(
    metadata,
    "operator_approval_reference",
    "operatorApprovalReference",
    "manual_review_resolution",
    "manualReviewResolution"
  ) || "").trim();
  const operatorID = String(metadataEvidenceValue(
    metadata,
    "operator_id",
    "operatorId",
    "operatorID"
  ) || "").trim();
  return approved && Boolean(operatorID) && Boolean(reference);
}

function assertInactiveTransitionEvidence(current, to, metadata = {}) {
  const from = current.status;
  if (
    (from === reservationStatuses.Submitted || from === reservationStatuses.Unknown) &&
    (to === reservationStatuses.ReplanRequired || to === reservationStatuses.Failed) &&
    !hasPostBroadcastReplanEvidence(metadata)
  ) {
    throw new Error(`${from} -> ${to} requires nullifier_unspent_confirmed and tx_absent_or_failed_confirmed reconcile evidence`);
  }
  if (from === reservationStatuses.ProofReady && to === reservationStatuses.ReplanRequired) {
    if (!hasProofDiscardEvidence(current, metadata)) {
      throw new Error("ProofReady -> ReplanRequired requires no_broadcast_attempt and proof_discarded evidence");
    }
  }
  if (
    from === reservationStatuses.ManualReview &&
    [reservationStatuses.Released, reservationStatuses.ReplanRequired, reservationStatuses.Failed].includes(to) &&
    !hasManualReviewApprovalEvidence(metadata)
  ) {
    throw new Error(`${from} -> ${to} requires operator approval evidence`);
  }
}

function reconciledSpentPatch(patch = {}, { operationReconcile = false } = {}) {
  const authorized = { ...patch };
  Object.defineProperty(authorized, reconciledSpentTransition, { value: true });
  if (operationReconcile) {
    Object.defineProperty(authorized, managedOperationReconciliation, { value: true });
  }
  return authorized;
}

function operationReconciliationOutcome(reservations, spentNotesByLookupKey) {
  const requiresEvidence = reservations.some(operationSuccessEvidenceRequired);
  if (!requiresEvidence) return { evaluated: false, matches: true, errors: [] };
  const evaluations = [];
  for (const reservation of reservations) {
    const note = spentNotesByLookupKey.get(reservation.nullifier_lookup_key);
    if (!note) {
      return {
        evaluated: true,
        matches: false,
        operationStatus: operationStatuses.ManualReview,
        errors: ["operation input evidence incomplete"]
      };
    }
    const evidence = evaluateOperationSuccessEvidence(reservation, note);
    if (!evidence.evaluated) {
      return {
        evaluated: true,
        matches: false,
        operationStatus: operationStatuses.ManualReview,
        errors: ["operation input evidence incomplete"]
      };
    }
    evaluations.push(evidence);
  }
  const errors = [...new Set(evaluations.flatMap(evidence => evidence.errors))];
  if (evaluations.some(evidence => !evidence.matches)) {
    return {
      evaluated: true,
      matches: false,
      operationStatus: operationStatuses.ConflictSpent,
      errors: errors.length ? errors : ["operation input evidence conflict"]
    };
  }
  return {
    evaluated: true,
    matches: true,
    operationStatus: operationStatuses.Succeeded,
    errors: []
  };
}

function operationReconciliationTransitions(reservations, spentNotesByLookupKey, now) {
  const outcome = operationReconciliationOutcome(reservations, spentNotesByLookupKey);
  const transitions = [];
  for (const reservation of reservations) {
    const spent = spentNotesByLookupKey.has(reservation.nullifier_lookup_key);
    const to = spent ? reservationStatuses.ConfirmedSpent : reservation.status;
    if (!spent && !outcome.evaluated) continue;
    const patch = { updated_at: now };
    if (outcome.evaluated) {
      patch.metadata = {
        ...(reservation.metadata || {}),
        operation_status: outcome.operationStatus,
        operation_success_evidence_matches: outcome.matches,
        operation_success_evidence_errors: outcome.errors
      };
    }
    transitions.push({
      reservationID: reservation.reservation_id,
      from: reservation.status,
      to,
      patch: reconciledSpentPatch(patch, { operationReconcile: outcome.evaluated })
    });
  }
  return transitions;
}

function metadataObject(metadata = {}) {
  const nested = metadata.metadata;
  return nested && typeof nested === "object" && !Array.isArray(nested) ? nested : {};
}

function firstDefined(...values) {
  return values.find(value => value !== undefined && value !== null);
}

function booleanEvidence(value) {
  return value === true;
}

function nestedOperationEvidence(input = {}) {
  for (const key of ["operationSuccessEvidence", "operation_success_evidence", "successEvidence", "success_evidence", "evidence"]) {
    const candidate = input?.[key];
    if (candidate && typeof candidate === "object" && !Array.isArray(candidate)) {
      return candidate;
    }
  }
  return null;
}

function txResultObject(input = {}) {
  for (const key of ["txResult", "tx_result", "transactionResult", "transaction_result", "broadcastResult", "broadcast_result"]) {
    const candidate = input?.[key];
    if (candidate && typeof candidate === "object" && !Array.isArray(candidate)) {
      return candidate;
    }
  }
  return null;
}

function executionResultObjects(...sources) {
  const results = [];
  for (const source of sources) {
    if (!source || typeof source !== "object" || Array.isArray(source)) continue;
    const result = txResultObject(source) || (
      Object.prototype.hasOwnProperty.call(source, "code") ||
      Object.prototype.hasOwnProperty.call(source, "receipt")
        ? source
        : null
    );
    if (result && !results.includes(result)) results.push(result);
  }
  return results;
}

function txHashFromResult(result = {}) {
  if (!result || typeof result !== "object") return "";
  return String(firstDefined(
    result.txHash,
    result.tx_hash,
    result.txhash,
    result.hash,
    result.transactionHash,
    result.transaction_hash,
    result.transaction_hash_hex,
    result.broadcast?.txhash,
    result.broadcast?.txHash,
    result.tx?.txhash,
    result.tx?.txHash,
    ""
  ));
}

function txIdentityFromResult(result = {}, keys = []) {
  if (!result || typeof result !== "object") return "";
  const nested = [result.broadcast, result.tx]
    .filter(candidate => candidate && typeof candidate === "object" && !Array.isArray(candidate));
  return String(firstDefined(
    ...keys.flatMap(key => [result[key], ...nested.map(candidate => candidate[key])]),
    ""
  ));
}

function operationSuccessEvidence(input = {}) {
  const nested = nestedOperationEvidence(input);
  const evidenceSource = nested || input;
  const source = nested ? { ...input, ...nested } : input;
  const txResults = executionResultObjects(input, nested);
  const txResult = txResults[0] || null;
  const batchItemIndex = firstDefined(
    source.batchItemIndex,
    source.batch_item_index,
    source.itemIndex,
    source.item_index
  );
  const batchItemIndexKnown = firstDefined(
    source.batchItemIndexKnown,
    source.batch_item_index_known,
    source.itemIndexKnown,
    source.item_index_known
  );
  const normalizedItemIndex = normalizedBatchItemIndex(batchItemIndex);
  return {
    txHash: String(firstDefined(
      evidenceSource.txHash,
      evidenceSource.tx_hash,
      evidenceSource.txhash,
      evidenceSource.submittedTxHash,
      evidenceSource.submitted_tx_hash,
      evidenceSource.txHashSubmitted,
      evidenceSource.transactionHash,
      evidenceSource.transaction_hash,
      evidenceSource.transaction_hash_hex,
      txHashFromResult(txResult),
      ""
    )),
    txBytesHash: String(firstDefined(
      evidenceSource.txBytesHash,
      evidenceSource.tx_bytes_hash,
      evidenceSource.txBytes,
      evidenceSource.tx_bytes,
      txIdentityFromResult(txResult, ["txBytesHash", "tx_bytes_hash", "txBytes", "tx_bytes"]),
      ""
    )),
    signDocHash: String(firstDefined(
      evidenceSource.signDocHash,
      evidenceSource.sign_doc_hash,
      evidenceSource.signDoc,
      evidenceSource.sign_doc,
      txIdentityFromResult(txResult, ["signDocHash", "sign_doc_hash", "signDoc", "sign_doc"]),
      ""
    )),
    txResult,
    txResults,
    outputCommitment: String(firstDefined(
      source.expectedOutputCommitment,
      source.expected_output_commitment,
      source.outputCommitment,
      source.output_commitment,
      source.outputCommitmentHex,
      source.output_commitment_hex,
      source.commitmentHex,
      source.commitment_hex,
      ""
    )),
    disclosureDigest: String(firstDefined(
      source.expectedDisclosureDigest,
      source.expected_disclosure_digest,
      source.auditDisclosureDigest,
      source.audit_disclosure_digest,
      source.auditDisclosureDigestHex,
      source.audit_disclosure_digest_hex,
      source.disclosureDigest,
      source.disclosure_digest,
      ""
    )),
    recipientHash: String(firstDefined(
      source.expectedRecipientHash,
      source.expected_recipient_hash,
      source.recipientHash,
      source.recipient_hash,
      source.recipientHashHex,
      source.recipient_hash_hex,
      ""
    )),
    amount: String(firstDefined(
      source.expectedAmount,
      source.expected_amount,
      source.operationAmount,
      source.operation_amount,
      source.actualAmount,
      source.actual_amount,
      nested ? source.amount : undefined,
      ""
    )),
    amountHash: String(firstDefined(
      source.expectedAmountHash,
      source.expected_amount_hash,
      source.amountHash,
      source.amount_hash,
      source.amountHashHex,
      source.amount_hash_hex,
      ""
    )),
    denom: String(firstDefined(
      source.expectedDenom,
      source.expected_denom,
      source.operationDenom,
      source.operation_denom,
      source.actualDenom,
      source.actual_denom,
      source.denom,
      source.assetDenom,
      source.asset_denom,
      ""
    )),
    batchItemIndex: normalizedItemIndex.value,
    batchItemIndexValid: normalizedItemIndex.valid,
    batchItemIndexProvided: normalizedItemIndex.provided,
    batchItemIndexKnown: batchItemIndexKnown !== undefined && batchItemIndexKnown !== null
      ? booleanEvidence(batchItemIndexKnown)
      : batchItemIndex !== undefined && batchItemIndex !== null
  };
}

function expectedOperationSuccessEvidence(reservation = {}) {
  const batchItemIndex = normalizedBatchItemIndex(reservation.batch_item_index);
  return {
    outputCommitment: String(reservation.expected_output_commitment || ""),
    disclosureDigest: String(reservation.expected_disclosure_digest || ""),
    recipientHash: String(reservation.expected_recipient_hash || ""),
    amount: String(reservation.expected_amount || ""),
    amountHash: String(reservation.expected_amount_hash || ""),
    denom: String(reservation.expected_denom || ""),
    batchItemIndex: batchItemIndex.value,
    batchItemIndexValid: batchItemIndex.valid,
    batchItemIndexProvided: batchItemIndex.provided,
    batchItemIndexKnown: booleanEvidence(reservation.batch_item_index_known)
  };
}

function operationSuccessEvidenceRequired(reservation = {}) {
  const metadata = reservation.metadata || {};
  return booleanEvidence(firstDefined(
    metadata.operation_success_evidence_required,
    metadata.operationSuccessEvidenceRequired,
    reservation.operation_success_evidence_required,
    reservation.operationSuccessEvidenceRequired,
    false
  ));
}

function operationEvidenceValuesEqual(expected, actual, { caseInsensitive = false } = {}) {
  const left = String(expected || "").trim();
  const right = String(actual || "").trim();
  if (caseInsensitive) return left.toLowerCase() === right.toLowerCase();
  return left === right;
}

function normalizedTxIdentity(value) {
  return String(value || "").trim().toLowerCase().replace(/^0x/, "");
}

function evaluateOperationTxIdentity(reservation = {}, actual = {}) {
  const expectedTxHash = normalizedTxIdentity(reservation.submitted_tx_hash);
  const expectedTxBytesHash = normalizedTxIdentity(reservation.tx_bytes_hash);
  const actualTxHash = normalizedTxIdentity(actual.txHash);
  const actualTxBytesHash = normalizedTxIdentity(actual.txBytesHash);
  const expectedSignDoc = normalizedTxIdentity(reservation.sign_doc_hash);
  const actualSignDoc = normalizedTxIdentity(actual.signDocHash);
  const actualIdentitySeen = Boolean(actualTxHash || actualTxBytesHash || actualSignDoc);
  const errors = [];
  let matched = false;

  if (!actualIdentitySeen) {
    errors.push("tx_hash_or_tx_result identity missing");
  }
  if (!expectedTxHash && !expectedTxBytesHash) {
    errors.push("persisted tx_hash_or_tx_bytes identity missing");
  }
  if (actualTxHash) {
    if (!expectedTxHash || actualTxHash !== expectedTxHash) {
      errors.push("tx_hash_or_tx_bytes mismatch");
    } else {
      matched = true;
    }
  }
  if (actualTxBytesHash) {
    if (!expectedTxBytesHash || actualTxBytesHash !== expectedTxBytesHash) {
      errors.push("tx_hash_or_tx_bytes mismatch");
    } else {
      matched = true;
    }
  }
  if (expectedSignDoc) {
    if (actualSignDoc && actualSignDoc !== expectedSignDoc) {
      errors.push("sign_doc_hash mismatch");
    }
  }
  if (!matched && !errors.length) {
    errors.push("matching persisted tx identity missing");
  }
  return { matches: errors.length === 0 && matched, errors };
}

function executionOutcomeErrors(txResult) {
  if (!txResult || typeof txResult !== "object") return [];
  const errors = [];
  const cosmosCode = firstDefined(
    txResult.code,
    txResult.tx_response?.code,
    txResult.txResponse?.code,
    txResult.broadcast?.code,
    txResult.tx?.code
  );
  if (cosmosCode !== undefined && cosmosCode !== null && String(cosmosCode).trim() !== "") {
    const normalized = Number(cosmosCode);
    if (!Number.isFinite(normalized) || normalized !== 0) {
      errors.push("tx_result_code indicates failure");
    }
  }
  const receipt = firstDefined(
    txResult.receipt,
    txResult.transactionReceipt,
    txResult.transaction_receipt,
    txResult.broadcast?.receipt,
    txResult.tx?.receipt
  );
  const receiptStatus = receipt && typeof receipt === "object"
    ? firstDefined(receipt.status, receipt.receipt_status)
    : firstDefined(txResult.receiptStatus, txResult.receipt_status);
  if (receiptStatus !== undefined && receiptStatus !== null && String(receiptStatus).trim() !== "") {
    const normalized = String(receiptStatus).trim().toLowerCase();
    const succeeded = receiptStatus === true || normalized === "1" || normalized === "0x1" || normalized === "true";
    if (!succeeded) errors.push("evm_receipt_status indicates failure");
  }
  return errors;
}

function evaluateOperationSuccessEvidence(reservation = {}, actualInput = {}) {
  if (!operationSuccessEvidenceRequired(reservation)) {
    return { evaluated: false, matches: true, errors: [] };
  }
  const expected = expectedOperationSuccessEvidence(reservation);
  const actual = operationSuccessEvidence(actualInput);
  const txIdentity = evaluateOperationTxIdentity(reservation, actual);
  const errors = [...new Set([
    ...txIdentity.errors,
    ...actual.txResults.flatMap(executionOutcomeErrors)
  ])];
  const check = (field, expectedValue, actualValue, options = {}) => {
    if (!expectedValue) {
      errors.push(`${field} expected value missing`);
      return;
    }
    if (!actualValue) {
      errors.push(`${field} missing`);
      return;
    }
    if (!operationEvidenceValuesEqual(expectedValue, actualValue, options)) {
      errors.push(`${field} mismatch`);
    }
  };
  check("expected_output_commitment", expected.outputCommitment, actual.outputCommitment, { caseInsensitive: true });
  check("expected_disclosure_digest", expected.disclosureDigest, actual.disclosureDigest, { caseInsensitive: true });
  check("expected_recipient_hash", expected.recipientHash, actual.recipientHash, { caseInsensitive: true });
  check("expected_amount_hash", expected.amountHash, actual.amountHash, { caseInsensitive: true });
  check("expected_denom", expected.denom, actual.denom);
  if (expected.batchItemIndexKnown && !actual.batchItemIndexProvided) {
    errors.push("batch_item_index missing");
  } else if (expected.batchItemIndexKnown && !actual.batchItemIndexValid) {
    errors.push("batch_item_index invalid");
  } else if (expected.batchItemIndexKnown && !actual.batchItemIndexKnown) {
    errors.push("batch_item_index missing");
  } else if (expected.batchItemIndexKnown && expected.batchItemIndex !== actual.batchItemIndex) {
    errors.push("batch_item_index mismatch");
  }
  return {
    evaluated: true,
    matches: errors.length === 0,
    errors
  };
}

function postBroadcastReplanEvidence(metadata = {}) {
  const nested = metadataObject(metadata);
  return {
    nullifierUnspentConfirmed: firstDefined(
      metadata.nullifierUnspentConfirmed,
      metadata.nullifier_unspent_confirmed,
      nested.nullifierUnspentConfirmed,
      nested.nullifier_unspent_confirmed
    ),
    checkedHeight: firstDefined(
      metadata.checkedHeight,
      metadata.checked_height,
      nested.checkedHeight,
      nested.checked_height
    ),
    txHashChecked: firstDefined(
      metadata.txHashChecked,
      metadata.tx_hash_checked,
      nested.txHashChecked,
      nested.tx_hash_checked
    ),
    txAbsentOrFailedConfirmed: firstDefined(
      metadata.txAbsentOrFailedConfirmed,
      metadata.tx_absent_or_failed_confirmed,
      nested.txAbsentOrFailedConfirmed,
      nested.tx_absent_or_failed_confirmed
    )
  };
}

function hasPostBroadcastReplanEvidence(metadata = {}) {
  const evidence = postBroadcastReplanEvidence(metadata);
  return Boolean(
    booleanEvidence(evidence.nullifierUnspentConfirmed) &&
    booleanEvidence(evidence.txAbsentOrFailedConfirmed)
  );
}

function proofReadyTransitionPatch(metadata = {}) {
  const evidence = operationSuccessEvidence(metadata);
  if (!evidence.batchItemIndexValid ||
      (evidence.batchItemIndexKnown && !evidence.batchItemIndexProvided)) {
    throw new Error("batch item index must be a non-negative safe integer");
  }
  const operationEvidenceRequired = booleanEvidence(firstDefined(
    metadata.operationSuccessEvidenceRequired,
    metadata.operation_success_evidence_required,
    metadata.metadata?.operationSuccessEvidenceRequired,
    metadata.metadata?.operation_success_evidence_required,
    false
  ));
  return {
    lease_token: metadata.leaseToken || metadata.lease_token || "",
    payload_hash: metadata.payloadHash || metadata.payload_hash || "",
    expected_output_commitment: evidence.outputCommitment,
    expected_disclosure_digest: evidence.disclosureDigest,
    expected_recipient_hash: evidence.recipientHash,
    expected_amount: evidence.amount,
    expected_amount_hash: evidence.amountHash,
    expected_denom: evidence.denom,
    batch_item_index: evidence.batchItemIndex,
    batch_item_index_known: evidence.batchItemIndexKnown,
    metadata: {
      ...(metadata.metadata || {}),
      no_broadcast_attempt: true,
      ...(operationEvidenceRequired ? { operation_success_evidence_required: true } : {})
    }
  };
}

function assertReplanTransitionEvidence(from, to, metadata = {}) {
  if (to !== reservationStatuses.ReplanRequired) return;
  if (from !== reservationStatuses.Submitted && from !== reservationStatuses.Unknown) return;
  if (!hasPostBroadcastReplanEvidence(metadata)) {
    throw new Error(`${from} -> ReplanRequired requires nullifier_unspent_confirmed and tx_absent_or_failed_confirmed reconcile evidence`);
  }
}

function patchIfPresent(patch, key, value) {
  if (value !== undefined && value !== null && value !== "") {
    patch[key] = value;
  }
}

const immutableReservationPatchFields = [
  "reservation_id", "reservationID", "reservationId",
  "operation_id", "operationID", "operationId",
  "owner_key_id", "ownerKeyId", "owner_keyID", "ownerKeyID",
  "nullifier_lookup_key", "nullifierLookupKey",
  "nullifier_lookup_key_id", "nullifierLookupKeyId", "nullifierLookupKeyID",
  "note_id", "noteId", "noteID",
  "kind", "operation_kind", "operationKind",
  "amount", "tx_hash", "txHash", "height", "sequence",
  "created_at", "createdAt"
];

function assertPatchKeepsReservationIdentity(patch = {}) {
  const changed = immutableReservationPatchFields.find(key =>
    Object.prototype.hasOwnProperty.call(patch, key)
  );
  if (changed) {
    throw new Error(`reservation identity field cannot be changed through mutation: ${changed}`);
  }
}

function assertReservationIdentityUnchanged(current, next) {
  const immutableFields = [
    "reservation_id", "operation_id", "owner_key_id", "nullifier_lookup_key",
    "nullifier_lookup_key_id", "note_id", "kind", "amount", "tx_hash",
    "height", "sequence", "created_at"
  ];
  const changed = immutableFields.find(field => current[field] !== next[field]);
  if (changed) {
    throw new Error(`reservation identity field cannot be changed through mutation: ${changed}`);
  }
}

const exactOperationLifecycleStatuses = new Set([
  reservationStatuses.Reserved,
  reservationStatuses.Proving,
  reservationStatuses.ProofReady,
  reservationStatuses.Submitted,
  reservationStatuses.Unknown,
  reservationStatuses.ManualReview,
  reservationStatuses.ReplanRequired,
  reservationStatuses.Released,
  reservationStatuses.Failed
]);

function operationReservationGroupKey(reservation) {
  return `${reservation.owner_key_id}\x00${reservation.operation_id}`;
}

function assertExactOperationLifecycleTransitionSets(reservations, transitions, currentByReservationID) {
  const selectedByOperation = new Map();
  for (const transition of transitions) {
    const current = currentByReservationID.get(transition.reservationID);
    if (!current?.operation_id || (
      !exactOperationLifecycleStatuses.has(transition.to) &&
      transition.patch?.[managedOperationReconciliation] !== true
    )) continue;
    const key = operationReservationGroupKey(current);
    if (!selectedByOperation.has(key)) selectedByOperation.set(key, new Set());
    selectedByOperation.get(key).add(current.reservation_id);
  }
  for (const [key, selected] of selectedByOperation) {
    const linked = reservations.filter(candidate => operationReservationGroupKey(candidate) === key);
    if (linked.length !== selected.size || linked.some(candidate => !selected.has(candidate.reservation_id))) {
      throw new Error("operation lifecycle transition requires the exact linked reservation set");
    }
  }
}

export class MemoryReservationStore {
  constructor({ state, now } = {}) {
    this.state = normalizeState(state);
    this.now = now || (() => new Date());
  }

  async load() {
    return cloneJSON(this.state);
  }

  // Test/migration escape hatch. Application code must use the CAS methods below.
  async unsafeReplaceState(state) {
    this.state = normalizeState(state);
    return this.load();
  }

  async listReservations(filter = {}) {
    const statuses = new Set((filter.statuses || []).map(String));
    const ownerKeyId = String(filter.ownerKeyId || filter.owner_key_id || "");
    const reservations = this.state.reservations
      .filter(reservation => !statuses.size || statuses.has(reservation.status))
      .filter(reservation => !ownerKeyId || reservation.owner_key_id === ownerKeyId)
      .sort((left, right) => left.created_at.localeCompare(right.created_at));
    return cloneJSON(filter.limit > 0 ? reservations.slice(0, filter.limit) : reservations);
  }

  async getReservation(reservationID) {
    const reservation = this.state.reservations.find(candidate => candidate.reservation_id === reservationID);
    if (!reservation) throw new Error(`reservation not found: ${reservationID}`);
    return cloneJSON(reservation);
  }

  async createReservationBatch(reservations = []) {
    const normalized = reservations.map(normalizeReservation);
    const existingIDs = new Set(this.state.reservations.map(reservation => reservation.reservation_id));
    const usedOperationIDs = new Set(this.state.reservations
      .filter(reservation => reservation.operation_id)
      .map(operationReservationGroupKey));
    const pendingIDs = new Set();
    const combined = [...this.state.reservations];
    for (const reservation of normalized) {
      assertInitialReservationRecord(reservation);
      if (reservation.operation_id && usedOperationIDs.has(operationReservationGroupKey(reservation))) {
        throw new Error(`operation_id has already been used: ${reservation.operation_id}`);
      }
      if (existingIDs.has(reservation.reservation_id) || pendingIDs.has(reservation.reservation_id)) {
        throw new Error(`active reservation already exists: ${reservation.reservation_id}`);
      }
      pendingIDs.add(reservation.reservation_id);
      if (activeConflict(combined, reservation)) {
        throw new Error("active reservation already exists");
      }
      if (confirmedSpentConflict(combined, reservation)) {
        throw new Error("confirmed spent reservation prevents note reuse");
      }
      combined.push(reservation);
    }
    this.state.reservations = combined;
    return cloneJSON(normalized);
  }

  // Test/migration escape hatch. This deliberately bypasses manager ownership and lease checks.
  async unsafeReplaceReservation(reservation) {
    const normalized = normalizeReservation(reservation);
    const index = this.state.reservations.findIndex(candidate => candidate.reservation_id === normalized.reservation_id);
    if (index < 0) throw new Error(`reservation not found: ${normalized.reservation_id}`);
    assertReservationIdentityUnchanged(this.state.reservations[index], normalized);
    if (this.state.reservations[index].status !== normalized.status) {
      throw new Error("reservation status changes require compareAndSetReservationStatus");
    }
    if (
      activeConflict(this.state.reservations, normalized, normalized.reservation_id) ||
      confirmedSpentConflict(this.state.reservations, normalized, normalized.reservation_id)
    ) {
      throw new Error("active reservation already exists");
    }
    this.state.reservations[index] = normalized;
    return cloneJSON(normalized);
  }

  async compareAndSetReservationStatus(reservationID, from, to, patch = {}) {
    const [updated] = await this.compareAndSetReservationStatusBatch([{
      reservationID,
      from,
      to,
      patch
    }]);
    return updated;
  }

  async compareAndSetReservationStatusBatch(transitions = []) {
    const normalizedTransitions = transitions.map(transition => ({
      reservationID: String(transition.reservationID || transition.reservation_id || ""),
      from: String(transition.from || ""),
      to: String(transition.to || ""),
      patch: transition.patch || {}
    }));
    const seen = new Set();
    const indexes = [];
    const updated = [];
    const currentByReservationID = new Map();
    const nextReservations = [...this.state.reservations];
    const now = this.now();
    for (const transition of normalizedTransitions) {
      if (!transition.reservationID) throw new Error("reservationID is required");
      if (seen.has(transition.reservationID)) {
        throw new Error(`duplicate reservation transition: ${transition.reservationID}`);
      }
      seen.add(transition.reservationID);
      const index = this.state.reservations.findIndex(candidate =>
        candidate.reservation_id === transition.reservationID
      );
      if (index < 0) throw new Error(`reservation not found: ${transition.reservationID}`);
      const current = this.state.reservations[index];
      currentByReservationID.set(transition.reservationID, current);
      if (current.status !== transition.from) {
        throw new Error(`reservation compare-and-set failed: expected ${transition.from}, got ${current.status}`);
      }
      const managedRelayHandoff = assertManagedRelayHandoffMutation(current, transition.to, transition.patch, now);
      const managedBroadcastAttempt = assertManagedBroadcastAttemptMutation(current, transition.to, transition.patch, now);
      const managedBroadcastRejection = assertManagedBroadcastRejectionMutation(current, transition.to, transition.patch, now);
      const managedOperationReconcile = assertManagedOperationReconciliation(
        current,
        transition.to,
        transition.patch
      );
      const quarantineSpent = transition.to === reservationStatuses.ConfirmedSpent &&
        transition.patch[reconciledSpentTransition] === true;
      if (transition.from === transition.to && !managedRelayHandoff && !managedBroadcastAttempt && !managedOperationReconcile) {
        assertSameStatusLeaseRenewalPatch(current, transition.patch, now);
      }
      if (transition.from !== transition.to && !quarantineSpent && !canTransitionReservation(transition.from, transition.to)) {
        throw new Error(`invalid reservation transition: ${transition.from} -> ${transition.to}`);
      }
      assertPatchKeepsReservationIdentity(transition.patch);
      assertReservationTransitionPatchFields(current, transition.to, transition.patch, {
        managedRelayHandoff,
        managedBroadcastAttempt,
        managedOperationReconcile
      });
      if (!managedBroadcastRejection) {
        assertStoreTransitionEvidence(current, transition.to, transition.patch);
      }
      assertOperationSuccessPredicateImmutable(current, transition.to, transition.patch);
      assertReservationEvidencePatchMonotonic(current, transition.patch, {
        allowOperationOutcomeMutation: managedOperationReconcile
      });
      assertStoreLeaseMutationAllowed(current, transition.to, transition.patch, now);
      const patch = patchWithClearedLease(transition.to, transition.patch);
      const next = normalizeReservation({
        ...current,
        ...patch,
        status: transition.to,
        updated_at: nowIso(now)
      });
      indexes.push(index);
      updated.push(next);
    }

    assertExactOperationLifecycleTransitionSets(
      this.state.reservations,
      normalizedTransitions,
      currentByReservationID,
    );

    for (let i = 0; i < updated.length; i += 1) {
      nextReservations[indexes[i]] = updated[i];
    }
    for (const reservation of updated) {
      if (
        activeConflict(nextReservations, reservation, reservation.reservation_id) ||
        confirmedSpentConflict(nextReservations, reservation, reservation.reservation_id)
      ) {
        throw new Error("active reservation already exists");
      }
    }
    this.state.reservations = nextReservations;
    return cloneJSON(updated);
  }

  async releaseReservationBatch({
    reservationIDs = [],
    ownerKeyId = "",
    leaseOwner = "",
    leaseToken = ""
  } = {}) {
    const ids = [...new Set((reservationIDs || []).map(String).filter(Boolean))];
    if (!ids.length) return [];
    if (!ownerKeyId) throw new Error("reservation owner key id is required");
    const now = this.now();
    const updated = [];
    const indexes = [];
    const currentByReservationID = new Map();
    const transitions = [];
    for (const reservationID of ids) {
      const index = this.state.reservations.findIndex(candidate =>
        candidate.reservation_id === reservationID
      );
      if (index < 0) throw new Error(`reservation not found: ${reservationID}`);
      const current = this.state.reservations[index];
      if (current.owner_key_id !== ownerKeyId) {
        throw new Error("reservation owner mismatch");
      }
      if (![reservationStatuses.Reserved, reservationStatuses.Proving].includes(current.status)) {
        throw new Error(`reservation rollback requires Reserved or Proving status: ${current.status}`);
      }
      if (current.status === reservationStatuses.Proving || current.lease_token) {
        assertCurrentLeaseToken(current, leaseToken, leaseOwner, now);
      }
      indexes.push(index);
      updated.push(normalizeReservation({
        ...current,
        status: reservationStatuses.Released,
        lease_owner: "",
        lease_token: "",
        lease_until: "",
        last_heartbeat_at: "",
        updated_at: nowIso(now)
      }));
      currentByReservationID.set(reservationID, current);
      transitions.push({
        reservationID,
        from: current.status,
        to: reservationStatuses.Released,
        patch: {}
      });
    }
    assertExactOperationLifecycleTransitionSets(
      this.state.reservations,
      transitions,
      currentByReservationID
    );
    for (let index = 0; index < updated.length; index += 1) {
      this.state.reservations[indexes[index]] = updated[index];
    }
    return cloneJSON(updated);
  }

  async findActiveReservationByLookupKey(ownerKeyId, lookupKey) {
    const reservation = this.state.reservations.find(candidate =>
      candidate.owner_key_id === ownerKeyId &&
      candidate.nullifier_lookup_key === lookupKey &&
      isActiveReservationStatus(candidate.status)
    );
    return reservation ? cloneJSON(reservation) : null;
  }

  async findReservationsByLookupKey(ownerKeyId, lookupKey) {
    return cloneJSON(this.state.reservations.filter(candidate =>
      candidate.owner_key_id === ownerKeyId &&
      candidate.nullifier_lookup_key === lookupKey
    ));
  }

  async reconcileSpentByLookupKey(ownerKeyId, lookupKey, note, { now = nowIso(this.now()) } = {}) {
    return this.reconcileSpentByLookupKeys(ownerKeyId, [{ lookupKey, note }], { now });
  }

  async reconcileSpentByLookupKeys(ownerKeyId, spentNotes = [], { now = nowIso(this.now()) } = {}) {
    const spentNotesByLookupKey = new Map(spentNotes.map(({ lookupKey, note }) => [lookupKey, note]));
    const transitions = [];
    const affectedGroups = new Map();
    for (const { lookupKey } of spentNotes) {
      for (const reservation of this.state.reservations) {
        if (reservation.owner_key_id !== ownerKeyId || reservation.nullifier_lookup_key !== lookupKey) continue;
        const key = reservation.operation_id
          ? operationReservationGroupKey(reservation)
          : `${reservation.owner_key_id}\x00reservation:${reservation.reservation_id}`;
        affectedGroups.set(key, reservation.operation_id
          ? this.state.reservations.filter(candidate =>
              candidate.owner_key_id === ownerKeyId &&
              candidate.operation_id === reservation.operation_id
            )
          : [reservation]);
      }
    }
    for (const reservations of affectedGroups.values()) {
      transitions.push(...operationReconciliationTransitions(reservations, spentNotesByLookupKey, now));
    }
    if (!transitions.length) return [];
    // This starts the CAS before yielding, so one snapshot covers every
    // matching lookup key and quarantine is all-or-nothing for the scan page.
    return this.compareAndSetReservationStatusBatch(transitions);
  }
}

function requestToPromise(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("IndexedDB request failed"));
  });
}

function txDone(transaction) {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error || new Error("IndexedDB transaction failed"));
    transaction.onabort = () => reject(transaction.error || new Error("IndexedDB transaction aborted"));
  });
}

export class IndexedDbReservationStore extends MemoryReservationStore {
  constructor({
    dbName = "clairveil-reservations",
    namespace = "default",
    indexedDB: indexedDBImpl,
    locks = globalThis.navigator?.locks,
    requireLocks = true,
    require_locks,
    encodeState,
    encode_state,
    decodeState,
    decode_state,
    unsafeAllowPlaintext = false,
    unsafe_allow_plaintext,
    now
  } = {}) {
    super({ now });
    this.dbName = dbName;
    this.namespace = namespace;
    this.indexedDB = indexedDBImpl || globalThis.indexedDB;
    if (!this.indexedDB) {
      throw new Error("IndexedDB is unavailable");
    }
    this.locks = locks || null;
    this.requireLocks = Boolean(require_locks ?? requireLocks);
    this.encodeState = encodeState || encode_state || null;
    this.decodeState = decodeState || decode_state || null;
    this.unsafeAllowPlaintext = Boolean(unsafe_allow_plaintext ?? unsafeAllowPlaintext);
    this.lockName = `clairveil-reservations:${this.dbName}:${this.namespace}`;
    if (this.requireLocks && typeof this.locks?.request !== "function") {
      throw new Error("Web Locks API is required for cross-tab atomic browser note reservation storage");
    }
    if (Boolean(this.encodeState) !== Boolean(this.decodeState)) {
      throw new Error("IndexedDB reservation state requires both encodeState and decodeState callbacks");
    }
    if (!this.encodeState && !this.unsafeAllowPlaintext) {
      throw new Error("IndexedDB reservation store requires at-rest state encryption callbacks; pass unsafeAllowPlaintext: true only for demos/tests");
    }
    this.dbPromise = null;
  }

  async db() {
    if (this.dbPromise) return this.dbPromise;
    this.dbPromise = new Promise((resolve, reject) => {
      const request = this.indexedDB.open(this.dbName, 1);
      request.onupgradeneeded = () => {
        request.result.createObjectStore("states");
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error("IndexedDB open failed"));
    });
    return this.dbPromise;
  }

  async load() {
    const db = await this.db();
    const tx = db.transaction("states", "readonly");
    const value = await requestToPromise(tx.objectStore("states").get(this.namespace));
    await txDone(tx);
    const decoded = this.decodeState && value != null
      ? await this.decodeState(value)
      : value;
    return normalizeState(decoded || {});
  }

  async #writeState(state) {
    const normalized = normalizeState(state);
    const encoded = this.encodeState
      ? await this.encodeState(cloneJSON(normalized))
      : normalized;
    const db = await this.db();
    const tx = db.transaction("states", "readwrite");
    tx.objectStore("states").put(encoded, this.namespace);
    await txDone(tx);
    return cloneJSON(normalized);
  }

  async mutate(mutator) {
    return this.withMutationLock(async () => {
      const state = await this.load();
      const result = await mutator(state);
      await this.#writeState(state);
      return result;
    });
  }

  async withMutationLock(callback) {
    return withInProcessMutationLock(this.lockName, () => {
      if (typeof this.locks?.request !== "function") {
        return callback();
      }
      return this.locks.request(this.lockName, { mode: "exclusive" }, callback);
    });
  }

  async listReservations(filter = {}) {
    const state = await this.load();
    return new MemoryReservationStore({ state, now: this.now }).listReservations(filter);
  }

  async getReservation(reservationID) {
    const state = await this.load();
    return new MemoryReservationStore({ state, now: this.now }).getReservation(reservationID);
  }

  async createReservationBatch(reservations = []) {
    return this.mutate(async state => {
      const memory = new MemoryReservationStore({ state, now: this.now });
      const created = await memory.createReservationBatch(reservations);
      Object.assign(state, await memory.load());
      return created;
    });
  }

  async unsafeReplaceState(state) {
    return this.withMutationLock(() => this.#writeState(state));
  }

  async unsafeReplaceReservation(reservation) {
    return this.mutate(async state => {
      const memory = new MemoryReservationStore({ state, now: this.now });
      const updated = await memory.unsafeReplaceReservation(reservation);
      Object.assign(state, await memory.load());
      return updated;
    });
  }

  async compareAndSetReservationStatus(reservationID, from, to, patch = {}) {
    return this.mutate(async state => {
      const memory = new MemoryReservationStore({ state, now: this.now });
      const updated = await memory.compareAndSetReservationStatus(reservationID, from, to, patch);
      Object.assign(state, await memory.load());
      return updated;
    });
  }

  async compareAndSetReservationStatusBatch(transitions = []) {
    return this.mutate(async state => {
      const memory = new MemoryReservationStore({ state, now: this.now });
      const updated = await memory.compareAndSetReservationStatusBatch(transitions);
      Object.assign(state, await memory.load());
      return updated;
    });
  }

  async releaseReservationBatch(options = {}) {
    return this.mutate(async state => {
      const memory = new MemoryReservationStore({ state, now: this.now });
      const updated = await memory.releaseReservationBatch(options);
      Object.assign(state, await memory.load());
      return updated;
    });
  }

  async findActiveReservationByLookupKey(ownerKeyId, lookupKey) {
    const state = await this.load();
    return new MemoryReservationStore({ state, now: this.now }).findActiveReservationByLookupKey(ownerKeyId, lookupKey);
  }

  async findReservationsByLookupKey(ownerKeyId, lookupKey) {
    const state = await this.load();
    return new MemoryReservationStore({ state, now: this.now }).findReservationsByLookupKey(ownerKeyId, lookupKey);
  }

  async reconcileSpentByLookupKey(ownerKeyId, lookupKey, note, options = {}) {
    return this.reconcileSpentByLookupKeys(ownerKeyId, [{ lookupKey, note }], options);
  }

  async reconcileSpentByLookupKeys(ownerKeyId, spentNotes, options = {}) {
    return this.mutate(async state => {
      const memory = new MemoryReservationStore({ state, now: this.now });
      const updated = await memory.reconcileSpentByLookupKeys(ownerKeyId, spentNotes, options);
      Object.assign(state, await memory.load());
      return updated;
    });
  }
}

export function createBrowserReservationStore(options = {}) {
  if (options.indexedDB !== null && (options.indexedDB || globalThis.indexedDB)) {
    return new IndexedDbReservationStore(options);
  }
  if (options.unsafeAllowMemoryFallback || options.unsafe_allow_memory_fallback) {
    return new MemoryReservationStore(options);
  }
  throw new Error("IndexedDB is unavailable for browser note reservations; use unsafeAllowMemoryFallback only for demos/tests");
}

export class NoteReservationManager {
  constructor({
    store,
    ownerKeyId,
    owner_key_id,
    indexKey,
    index_key,
    nullifierLookupKeyId,
    nullifier_lookup_key_id,
    leaseOwner,
    lease_owner,
    leaseDurationMs,
    lease_duration_ms,
    unsafeAllowPublicIndexKey,
    unsafe_allow_public_index_key,
    now
  } = {}) {
    if (!store) {
      throw new Error("reservation store is required; pass MemoryReservationStore explicitly only for demos/tests");
    }
    this.store = store;
    this.ownerKeyId = String(ownerKeyId || owner_key_id || "");
    if (!this.ownerKeyId) {
      throw new Error("ownerKeyId is required");
    }
    const explicitIndexKey = indexKey ?? index_key;
    const unsafePublicIndexKey = Boolean(unsafeAllowPublicIndexKey || unsafe_allow_public_index_key);
    if (explicitIndexKey === undefined || explicitIndexKey === null || explicitIndexKey === "") {
      if (!unsafePublicIndexKey) {
        throw new Error("indexKey is required for note reservations; pass unsafeAllowPublicIndexKey only for single-user demos");
      }
      this.indexKey = utf8Bytes(this.ownerKeyId);
    } else {
      const indexKeyBytes = bytes(explicitIndexKey);
      if (!indexKeyBytes.length) {
        throw new Error("indexKey is required for note reservations");
      }
      this.indexKey = indexKeyBytes;
    }
    this.nullifierLookupKeyId = String(nullifierLookupKeyId || nullifier_lookup_key_id || "default");
    this.leaseOwner = String(leaseOwner || lease_owner || `reservation-worker:${randomHex(16)}`);
    this.leaseDurationMs = Number(leaseDurationMs || lease_duration_ms || defaultLeaseDurationMs);
    this.now = now || (() => new Date());
  }

  timestamp() {
    return nowIso(this.now());
  }

  async lookupKeyForNote(noteLike) {
    return nullifierLookupKeyFromHex(this.indexKey, noteNullifierHex(noteLike));
  }

  async listActiveReservations() {
    return this.store.listReservations({
      ownerKeyId: this.ownerKeyId,
      statuses: activeReservationStatuses
    });
  }

  async getReservation(reservationID) {
    return this.getOwnedReservation(reservationID);
  }

  assertReservationOwner(reservation) {
    if (reservation.owner_key_id !== this.ownerKeyId) {
      throw new Error("reservation owner mismatch");
    }
  }

  async getOwnedReservation(reservationID) {
    const reservation = await this.store.getReservation(reservationID);
    this.assertReservationOwner(reservation);
    return reservation;
  }

  async reservationForNote(noteLike) {
    const lookupKey = await this.lookupKeyForNote(noteLike);
    const reservations = await this.store.findReservationsByLookupKey(this.ownerKeyId, lookupKey);
    return reservations.find(reservation => isActiveReservationStatus(reservation.status)) ||
      reservations.find(reservation => reservation.status === reservationStatuses.ConfirmedSpent) ||
      null;
  }

  async reservationStatusByNote(notes = []) {
    const entries = [];
    for (const note of notes || []) {
      const nullifierHex = noteNullifierHex(note);
      if (!nullifierHex) continue;
      const reservation = await this.reservationForNote(note);
      entries.push([nullifierHex, reservation]);
    }
    return new Map(entries);
  }

  async filterAvailableNotes(notes = []) {
    const out = [];
    for (const note of notes || []) {
      if (!(await this.reservationForNote(note))) {
        out.push(note);
      }
    }
    return out;
  }

  async reserveNotes({
    notes = [],
    operationId,
    operation_id,
    kind = "transfer",
    metadata = {}
  } = {}) {
    const selected = [...notes];
    if (!selected.length) {
      return {
        operation_id: String(operationId || operation_id || ""),
        lease_owner: this.leaseOwner,
        lease_token: "",
        lease_until: "",
        reservation_ids: [],
        reservations: []
      };
    }
    const operationID = String(operationId || operation_id || `${kind}:${randomHex(12)}`);
    const now = this.timestamp();
    const leaseToken = randomHex(16);
    const leaseUntil = futureIso(now, this.leaseDurationMs);
    const reservations = [];
    for (const note of selected) {
      const identity = noteReservationIdentity(note);
      const lookupKey = await this.lookupKeyForNote(note);
      reservations.push(normalizeReservation({
        reservation_id: `${operationID}:note:${lookupKey.slice(0, 20)}`,
        operation_id: operationID,
        owner_key_id: this.ownerKeyId,
        nullifier_lookup_key: lookupKey,
        nullifier_lookup_key_id: this.nullifierLookupKeyId,
        status: reservationStatuses.Reserved,
        lease_owner: "",
        lease_token: "",
        lease_until: "",
        last_heartbeat_at: "",
        kind,
        note_id: identity.noteId,
        amount: identity.amount,
        tx_hash: identity.txHash,
        height: identity.height,
        sequence: identity.sequence,
        created_at: now,
        updated_at: now,
        metadata
      }));
    }
    const created = await this.store.createReservationBatch(reservations);
    return {
      operation_id: operationID,
      lease_owner: this.leaseOwner,
      lease_token: leaseToken,
      lease_until: leaseUntil,
      reservation_ids: created.map(reservation => reservation.reservation_id),
      reservations: created
    };
  }

  async reservePlan({
    plan,
    kind = "transfer",
    operationId,
    operation_id,
    metadata = {}
  } = {}) {
    return this.reserveNotes({
      notes: selectedReservationNotesFromPlan(plan),
      operationId,
      operation_id,
      kind,
      metadata
    });
  }

  async transitionBatch(reservationIDs = [], from, to, patch = {}) {
    return this._transitionBatchEntries([{
      reservationIDs,
      from,
      to,
      patch
    }]);
  }

  async _transitionBatchEntries(entries = []) {
    const now = this.timestamp();
    const transitions = [];
    for (const entry of entries || []) {
      const {
        reservationIDs = [],
        from,
        to,
        patch = {}
      } = entry || {};
      assertPatchKeepsReservationIdentity(patch);
      assertCoreTransitionEvidence(from, to, patch);
      const transitionPatch = {
        ...patch,
        updated_at: now
      };
      const patchCarriesLeaseCredentials = [
        "lease_owner", "leaseOwner", "lease_token", "leaseToken",
        "lease_until", "leaseUntil", "last_heartbeat_at", "lastHeartbeatAt"
      ].some(key => Object.prototype.hasOwnProperty.call(patch, key));
      if (requiresReservationLeaseToken(from, to)) {
        transitionPatch.lease_owner = this.leaseOwner;
        transitionPatch.last_heartbeat_at = now;
        transitionPatch.lease_until = patch.lease_until || patch.leaseUntil || futureIso(now, this.leaseDurationMs);
      } else if (from === to && patchCarriesLeaseCredentials) {
        transitionPatch.lease_owner = this.leaseOwner;
      }
      for (const reservationID of reservationIDs || []) {
        const current = await this.getOwnedReservation(reservationID);
        assertLeaseTransitionAllowed(current, to, transitionPatch, now);
        assertReplanTransitionEvidence(current.status, to, patch);
        assertInactiveTransitionEvidence(current, to, patch);
        if (current.status !== from) {
          throw new Error(`reservation compare-and-set failed: expected ${from}, got ${current.status}`);
        }
        if (from !== to && !canTransitionReservation(from, to)) {
          throw new Error(`invalid reservation transition: ${from} -> ${to}`);
        }
        const reservationPatch = patch.metadata && typeof patch.metadata === "object" && !Array.isArray(patch.metadata)
          ? {
              ...transitionPatch,
              metadata: {
                ...(current.metadata || {}),
                ...patch.metadata
              }
            }
          : transitionPatch;
        transitions.push({
          reservationID,
          from,
          to,
          patch: reservationPatch
        });
      }
    }
    if (!transitions.length) return [];
    if (typeof this.store.compareAndSetReservationStatusBatch !== "function") {
      throw new Error("reservation store atomic batch compare-and-set is required");
    }
    return this.store.compareAndSetReservationStatusBatch(transitions);
  }

  async renewLease(reservationIDs = [], metadata = {}) {
    const now = this.timestamp();
    const leaseToken = metadata.leaseToken || metadata.lease_token || "";
    const requestedLeaseUntil = leaseUntilFromMetadata(metadata, now, this.leaseDurationMs);
    const transitions = [];
    for (const reservationID of reservationIDs || []) {
      const current = await this.getOwnedReservation(reservationID);
      if (!isActiveReservationStatus(current.status)) {
        throw new Error(`reservation lease cannot be renewed for inactive status: ${current.status}`);
      }
      assertCurrentLeaseToken(current, leaseToken, this.leaseOwner, now);
      const currentLeaseUntil = Date.parse(current.lease_until || "");
      const requestedLeaseUntilMs = Date.parse(requestedLeaseUntil);
      const leaseUntil = Number.isFinite(currentLeaseUntil) && currentLeaseUntil > requestedLeaseUntilMs
        ? current.lease_until
        : requestedLeaseUntil;
      transitions.push({
        reservationID,
        from: current.status,
        to: current.status,
        patch: {
          lease_owner: this.leaseOwner,
          lease_token: leaseToken,
          lease_until: leaseUntil,
          last_heartbeat_at: now,
          updated_at: now
        }
      });
    }
    if (!transitions.length) return [];
    if (typeof this.store.compareAndSetReservationStatusBatch !== "function") {
      throw new Error("reservation store atomic batch compare-and-set is required");
    }
    return this.store.compareAndSetReservationStatusBatch(transitions);
  }

  async recordRelayHandoff(reservationIDs = [], metadata = {}) {
    const now = this.timestamp();
    const leaseToken = metadata.leaseToken || metadata.lease_token || "";
    const payloadHash = String(metadata.payloadHash || metadata.payload_hash || "").trim();
    if (!payloadHash) {
      throw new Error("relay handoff requires the prepared payload hash");
    }
    const transitions = [];
    for (const reservationID of reservationIDs || []) {
      const current = await this.getOwnedReservation(reservationID);
      if (current.status !== reservationStatuses.ProofReady) {
        throw new Error(`relay handoff requires ProofReady reservation: ${current.status}`);
      }
      assertCurrentLeaseToken(current, leaseToken, this.leaseOwner, now);
      if (!current.payload_hash || current.payload_hash !== payloadHash) {
        throw new Error("relay handoff payload hash does not match the ProofReady reservation");
      }
      const patch = {
        lease_owner: this.leaseOwner,
        lease_token: leaseToken,
        lease_until: current.lease_until,
        last_heartbeat_at: now,
        updated_at: now,
        payload_hash: payloadHash,
        metadata: {
          ...(current.metadata || {}),
          ...(metadata.metadata || {}),
          relay_handed_off: true,
          relay_handed_off_at: String(
            current.metadata?.relay_handed_off_at ||
            current.metadata?.relayHandedOffAt ||
            metadata.handedOffAt ||
            metadata.handed_off_at ||
            now
          ),
          no_broadcast_attempt: false
        }
      };
      Object.defineProperty(patch, managedReservationEvidenceMutation, {
        value: "relay_handoff",
        enumerable: true
      });
      transitions.push({
        reservationID,
        from: reservationStatuses.ProofReady,
        to: reservationStatuses.ProofReady,
        patch
      });
    }
    if (!transitions.length) return [];
    if (typeof this.store.compareAndSetReservationStatusBatch !== "function") {
      throw new Error("reservation store atomic batch compare-and-set is required");
    }
    return this.store.compareAndSetReservationStatusBatch(transitions);
  }

  async heartbeatLease(reservationIDs = [], metadata = {}) {
    return this.renewLease(reservationIDs, metadata);
  }

  async markProving(reservationIDs = [], metadata = {}) {
    return this.transitionBatch(reservationIDs, reservationStatuses.Reserved, reservationStatuses.Proving, {
      lease_token: metadata.leaseToken || metadata.lease_token || ""
    });
  }

  async markProofReady(reservationIDs = [], metadata = {}) {
    return this.transitionBatch(
      reservationIDs,
      reservationStatuses.Proving,
      reservationStatuses.ProofReady,
      proofReadyTransitionPatch(metadata),
    );
  }

  async markProofReadyBatch(entries = []) {
    return this._transitionBatchEntries((entries || []).map(entry => ({
      reservationIDs: entry?.reservationIDs || entry?.reservation_ids || [],
      from: reservationStatuses.Proving,
      to: reservationStatuses.ProofReady,
      patch: proofReadyTransitionPatch(entry?.metadata || {})
    })));
  }

  async markBroadcastAttempting(reservationIDs = [], metadata = {}) {
    const now = this.timestamp();
    const leaseToken = metadata.leaseToken || metadata.lease_token || "";
    const transitions = [];
    for (const reservationID of reservationIDs || []) {
      const current = await this.getOwnedReservation(reservationID);
      if (current.status !== reservationStatuses.ProofReady) {
        throw new Error(`broadcast attempt requires ProofReady reservation: ${current.status}`);
      }
      assertCurrentLeaseToken(current, leaseToken, this.leaseOwner, now);
      const patch = {
        lease_owner: this.leaseOwner,
        lease_token: leaseToken,
        lease_until: current.lease_until,
        last_heartbeat_at: now,
        updated_at: now,
        broadcast_in_flight: true,
        broadcast_attempt_count: Number(current.broadcast_attempt_count || 0) + 1,
        metadata: {
          ...(current.metadata || {}),
          ...(metadata.metadata || {}),
          broadcast_attempt_started_at: now,
          broadcast_attempt_reason: String(metadata.reason || "external_broadcast_boundary_crossed"),
          no_broadcast_attempt: false
        }
      };
      Object.defineProperty(patch, managedReservationEvidenceMutation, {
        value: "broadcast_attempt",
        enumerable: true
      });
      transitions.push({
        reservationID,
        from: reservationStatuses.ProofReady,
        to: reservationStatuses.ProofReady,
        patch
      });
    }
    if (!transitions.length) return [];
    if (typeof this.store.compareAndSetReservationStatusBatch !== "function") {
      throw new Error("reservation store atomic batch compare-and-set is required");
    }
    return this.store.compareAndSetReservationStatusBatch(transitions);
  }

  async markBroadcastRejected(reservationIDs = [], metadata = {}) {
    const now = this.timestamp();
    const leaseToken = metadata.leaseToken || metadata.lease_token || "";
    const transitions = [];
    for (const reservationID of reservationIDs || []) {
      const current = await this.getOwnedReservation(reservationID);
      if (current.status !== reservationStatuses.ProofReady) {
        throw new Error(`wallet rejection resolution requires ProofReady reservation: ${current.status}`);
      }
      assertCurrentLeaseToken(current, leaseToken, this.leaseOwner, now);
      const patch = {
        lease_owner: this.leaseOwner,
        lease_token: leaseToken,
        broadcast_in_flight: false,
        broadcast_attempt_count: Number(current.broadcast_attempt_count || 0),
        last_broadcast_error: String(metadata.error || metadata.lastBroadcastError || metadata.last_broadcast_error || "wallet request rejected"),
        updated_at: now,
        metadata: {
          ...(current.metadata || {}),
          ...(metadata.metadata || {}),
          wallet_rejected_before_broadcast: true,
          provider_rejection_code: String(metadata.providerCode || metadata.provider_code || "4001"),
          no_broadcast_attempt: true,
          proof_discarded: true,
          reconcile_reason: "wallet_rejected_before_broadcast"
        }
      };
      Object.defineProperty(patch, managedReservationEvidenceMutation, {
        value: "broadcast_rejected",
        enumerable: true
      });
      transitions.push({
        reservationID,
        from: reservationStatuses.ProofReady,
        to: reservationStatuses.ReplanRequired,
        patch
      });
    }
    if (!transitions.length) return [];
    if (typeof this.store.compareAndSetReservationStatusBatch !== "function") {
      throw new Error("reservation store atomic batch compare-and-set is required");
    }
    return this.store.compareAndSetReservationStatusBatch(transitions);
  }

  async markSubmitted(reservationIDs = [], metadata = {}) {
    assertSubmittedBroadcastAttemptMetadata(metadata, "markSubmitted");
    const attempt = broadcastAttemptMetadata(metadata);
    return this.transitionBatch(reservationIDs, reservationStatuses.ProofReady, reservationStatuses.Submitted, {
      lease_token: metadata.leaseToken || metadata.lease_token || "",
      submitted_tx_hash: attempt.txHash,
      tx_bytes_hash: attempt.txBytesHash,
      sign_doc_hash: attempt.signDocHash,
      broadcast_attempt_count: Number(metadata.broadcastAttemptCount || metadata.broadcast_attempt_count || 0) || 1,
      metadata: {
        ...(metadata.metadata || {}),
        no_broadcast_attempt: false
      }
    });
  }

  async markUnknown(reservationIDs = [], metadata = {}) {
    assertBroadcastAttemptMetadata(metadata, "markUnknown");
    const attempt = broadcastAttemptMetadata(metadata);
    const from = metadata.fromStatus || metadata.from_status || reservationStatuses.ProofReady;
    if (![reservationStatuses.ProofReady, reservationStatuses.Submitted].includes(from)) {
      throw new Error(`markUnknown requires ProofReady or Submitted status, got ${from}`);
    }
    return this.transitionBatch(reservationIDs, from, reservationStatuses.Unknown, {
      lease_token: metadata.leaseToken || metadata.lease_token || "",
      submitted_tx_hash: attempt.txHash,
      tx_bytes_hash: attempt.txBytesHash,
      sign_doc_hash: attempt.signDocHash,
      last_broadcast_error: metadata.error || metadata.lastBroadcastError || metadata.last_broadcast_error || "",
      broadcast_attempt_count: Number(metadata.broadcastAttemptCount || metadata.broadcast_attempt_count || 0) || 1,
      metadata: {
        ...(metadata.metadata || {}),
        no_broadcast_attempt: false
      }
    });
  }

  async markReplanRequired(reservationIDs = [], metadata = {}) {
    const from = metadata.fromStatus || metadata.from_status || reservationStatuses.Submitted;
    const patch = {};
    const evidence = postBroadcastReplanEvidence(metadata);
    const proofDiscarded = firstDefined(metadata.proofDiscarded, metadata.proof_discarded);
    const authoritativeExpiryConfirmed = firstDefined(
      metadata.authoritativeExpiryConfirmed,
      metadata.authoritative_expiry_confirmed
    );
    patchIfPresent(patch, "lease_token", metadata.leaseToken ?? metadata.lease_token);
    patch.lease_owner = this.leaseOwner;
    patchIfPresent(patch, "submitted_tx_hash", metadata.txHash ?? metadata.tx_hash);
    patchIfPresent(patch, "tx_bytes_hash", metadata.txBytesHash ?? metadata.tx_bytes_hash);
    patchIfPresent(patch, "sign_doc_hash", metadata.signDocHash ?? metadata.sign_doc_hash);
    patchIfPresent(patch, "last_broadcast_error", metadata.error ?? metadata.lastBroadcastError ?? metadata.last_broadcast_error);
    const nestedMetadata = metadataObject(metadata);
    if (
      Object.keys(nestedMetadata).length ||
      evidence.nullifierUnspentConfirmed !== undefined ||
      evidence.checkedHeight !== undefined ||
      evidence.txHashChecked !== undefined ||
      evidence.txAbsentOrFailedConfirmed !== undefined ||
      proofDiscarded !== undefined ||
      authoritativeExpiryConfirmed !== undefined
    ) {
      patch.metadata = { ...nestedMetadata };
      if (booleanEvidence(evidence.nullifierUnspentConfirmed)) {
        patch.metadata.nullifier_unspent_confirmed = true;
      }
      if (booleanEvidence(evidence.txAbsentOrFailedConfirmed)) {
        patch.metadata.tx_absent_or_failed_confirmed = true;
      }
      if (booleanEvidence(proofDiscarded)) {
        patch.metadata.proof_discarded = true;
      }
      if (booleanEvidence(authoritativeExpiryConfirmed)) {
        patch.metadata.authoritative_expiry_confirmed = true;
      }
      patchIfPresent(patch.metadata, "checked_height", evidence.checkedHeight);
      patchIfPresent(patch.metadata, "tx_hash_checked", evidence.txHashChecked);
    }
    if (metadata.fromStatus || metadata.from_status) {
      return this.transitionBatch(reservationIDs, from, reservationStatuses.ReplanRequired, patch);
    }
    assertPatchKeepsReservationIdentity(patch);
    const now = this.timestamp();
    const transitionPatch = {
      ...patch,
      updated_at: now
    };
    const transitions = [];
    for (const reservationID of reservationIDs || []) {
      const current = await this.getOwnedReservation(reservationID);
      assertLeaseTransitionAllowed(current, reservationStatuses.ReplanRequired, transitionPatch, now);
      assertReplanTransitionEvidence(current.status, reservationStatuses.ReplanRequired, patch);
      assertInactiveTransitionEvidence(current, reservationStatuses.ReplanRequired, patch);
      if (!canTransitionReservation(current.status, reservationStatuses.ReplanRequired)) {
        throw new Error(`invalid reservation transition: ${current.status} -> ${reservationStatuses.ReplanRequired}`);
      }
      transitions.push({
        reservationID,
        from: current.status,
        to: reservationStatuses.ReplanRequired,
        patch: patch.metadata && typeof patch.metadata === "object" && !Array.isArray(patch.metadata)
          ? {
              ...transitionPatch,
              metadata: {
                ...(current.metadata || {}),
                ...patch.metadata
              }
            }
          : transitionPatch
      });
    }
    if (!transitions.length) return [];
    if (typeof this.store.compareAndSetReservationStatusBatch !== "function") {
      throw new Error("reservation store atomic batch compare-and-set is required");
    }
    return this.store.compareAndSetReservationStatusBatch(transitions);
  }

  async releaseReservedOrProving(reservationIDs = [], metadata = {}) {
    const leaseToken = metadata.leaseToken || metadata.lease_token || "";
    for (const reservationID of reservationIDs || []) {
      const current = await this.getOwnedReservation(reservationID);
      if (current.status === reservationStatuses.Proving) {
        assertCurrentLeaseToken(current, leaseToken, this.leaseOwner, this.timestamp());
      } else if (current.status !== reservationStatuses.Reserved) {
        throw new Error(`reservation rollback requires Reserved or Proving status: ${current.status}`);
      }
    }
    if (typeof this.store.releaseReservationBatch !== "function") {
      throw new Error("reservation store atomic release batch is required");
    }
    return this.store.releaseReservationBatch({
      reservationIDs,
      ownerKeyId: this.ownerKeyId,
      leaseOwner: this.leaseOwner,
      leaseToken
    });
  }

  async markManualReview(reservationIDs = [], metadata = {}) {
    assertPatchKeepsReservationIdentity(metadata);
    const now = this.timestamp();
    const patch = {
      lease_token: metadata.leaseToken || metadata.lease_token || "",
      lease_owner: this.leaseOwner,
      last_broadcast_error: metadata.error || metadata.lastBroadcastError || metadata.last_broadcast_error || "",
      updated_at: now,
      metadata: {
        ...(metadata.metadata || {})
      }
    };
    const transitions = [];
    for (const reservationID of reservationIDs || []) {
      const current = await this.getOwnedReservation(reservationID);
      if (!canTransitionReservation(current.status, reservationStatuses.ManualReview)) {
        throw new Error(`invalid reservation transition: ${current.status} -> ${reservationStatuses.ManualReview}`);
      }
      transitions.push({
        reservationID,
        from: current.status,
        to: reservationStatuses.ManualReview,
        patch: {
          ...patch,
          metadata: {
            ...(current.metadata || {}),
            ...patch.metadata
          }
        }
      });
    }
    if (typeof this.store.compareAndSetReservationStatusBatch !== "function") {
      throw new Error("reservation store atomic batch compare-and-set is required");
    }
    return this.store.compareAndSetReservationStatusBatch(transitions);
  }

  async resolveManualReview(reservationIDs = [], resolution = {}) {
    const target = String(resolution.target || resolution.toStatus || resolution.to_status || "");
    if (![reservationStatuses.Released, reservationStatuses.ReplanRequired, reservationStatuses.Failed].includes(target)) {
      throw new Error("ManualReview resolution target must be Released, ReplanRequired, or Failed");
    }
    const operatorId = String(resolution.operatorId || resolution.operator_id || "").trim();
    const approvalReference = String(resolution.approvalReference || resolution.approval_reference || "").trim();
    if (!operatorId || !approvalReference) {
      throw new Error("ManualReview resolution requires operatorId and approvalReference");
    }
    return this.transitionBatch(reservationIDs, reservationStatuses.ManualReview, target, {
      metadata: {
        ...(resolution.metadata || {}),
        operator_approved: true,
        operator_id: operatorId,
        operator_approval_reference: approvalReference,
        manual_review_resolution_reason: String(resolution.reason || "")
      }
    });
  }

  async reconcileSpentNotes(notes = []) {
    const seenLookupKeys = new Set();
    const spentNotes = [];
    for (const note of notes || []) {
      const spent = ["spent", "isSpent", "is_spent"].some((field) =>
        Object.prototype.hasOwnProperty.call(note || {}, field) && note[field] === true,
      );
      if (!spent) continue;
      const lookupKey = await this.lookupKeyForNote(note);
      if (seenLookupKeys.has(lookupKey)) continue;
      seenLookupKeys.add(lookupKey);
      spentNotes.push({ lookupKey, note });
    }
    if (!spentNotes.length) return [];
    if (typeof this.store.reconcileSpentByLookupKeys !== "function") {
      throw new Error("reservation store atomic spent reconciliation is required");
    }
    return this.store.reconcileSpentByLookupKeys(
      this.ownerKeyId,
      spentNotes,
      { now: this.timestamp() }
    );
  }
}

export function createNoteReservationManager(options = {}) {
  return new NoteReservationManager(options);
}

export async function preparePlanReservation(reservationManager, {
  plan,
  kind = "transfer",
  metadata = {}
} = {}) {
  if (!reservationManager) return null;
  const batch = await reservationManager.reservePlan({ plan, kind, metadata });
  if (!batch.reservation_ids.length) return null;
  try {
    const reservations = await reservationManager.markProving(batch.reservation_ids, {
      leaseToken: batch.lease_token,
      leaseUntil: batch.lease_until
    });
    return {
      ...batch,
      lease_owner: reservations[0]?.lease_owner || batch.lease_owner,
      lease_token: reservations[0]?.lease_token || batch.lease_token,
      lease_until: reservations[0]?.lease_until || batch.lease_until,
      reservations
    };
  } catch (error) {
    await rollbackPlanReservationPreservingError(reservationManager, batch, error);
    throw error;
  }
}

export async function rollbackPlanReservation(reservationManager, batch) {
  if (!reservationManager || !batch?.reservation_ids?.length) return;
  try {
    await reservationManager.releaseReservedOrProving(batch.reservation_ids, {
      leaseToken: batch.lease_token || batch.leaseToken || batch.reservations?.[0]?.lease_token || ""
    });
  } catch (error) {
    if (!isLeaseExpiredError(error)) {
      throw error;
    }
    try {
      await reservationManager.markManualReview(batch.reservation_ids, {
        error: error?.message || "rollback failed because reservation lease expired",
        metadata: {
          reconcile_reason: "rollback_lease_expired",
          rollback_error: error?.message || "reservation lease expired"
        }
      });
    } catch {
      // Rollback is best-effort in error paths; preserve the original prepare/prover error.
    }
  }
}

export async function rollbackPlanReservationPreservingError(reservationManager, batch, error) {
  try {
    await rollbackPlanReservation(reservationManager, batch);
  } catch (cleanupError) {
    if (error && typeof error === "object") {
      const existing = Array.isArray(error.reservationCleanupErrors)
        ? error.reservationCleanupErrors
        : [];
      error.reservationCleanupErrors = [...existing, cleanupError];
    }
  }
}
