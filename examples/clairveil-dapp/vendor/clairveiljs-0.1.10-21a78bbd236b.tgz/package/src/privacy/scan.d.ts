import type { BytesLike, Hex } from "../core/crypto.js";
import type { FoundNote } from "../core/note.js";

export interface ScanResult {
  notes: Array<{
    index: number;
    status: "spendable" | "spent" | "unverified";
    nullifier_status: "spent" | "unspent" | "unknown" | "unverified";
    amount: string;
    nullifier: Hex;
    tx_hash: Hex;
    height: number;
    sequence: number;
  }>;
  summary: {
    total_spendable: string;
    spendable_count: number;
    spent_count: number;
    total_count: number;
  };
  diagnostics: {
    scanned_events: number;
    new_notes_found: number;
    pages_scanned?: number;
    max_pages?: number;
    unverified_nullifier_count?: number;
  };
  foundNotes?: FoundNote[];
}

export function parseNoteBytes(bytes: BytesLike): object;
export function parseNullifierUsage(value: unknown): boolean | null;
export function processPrivacyEvent(event: object, input: { rootSeed?: BytesLike; spendScalar?: bigint; viewScalar?: bigint }): FoundNote[];
export function normalizeFoundNotes(notes: Array<object | FoundNote>): FoundNote[];
export function scanNotes(input: {
  rootSeed?: BytesLike;
  events?: object[];
  checkNullifier?: (nullifier: Hex) => Promise<object | boolean> | object | boolean;
  checkNullifiers?: (nullifiers: Hex[]) => Promise<Map<Hex, boolean> | Record<Hex, boolean> | { statuses?: Array<{ nullifier: Hex; used: boolean }> }>;
  includeFoundNotes?: boolean;
}): Promise<ScanResult>;
