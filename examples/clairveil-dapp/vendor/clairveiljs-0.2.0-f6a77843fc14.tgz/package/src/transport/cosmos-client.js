import { toBech32 } from "@cosmjs/encoding";
import { Registry, encodePubkey, makeAuthInfoBytes, makeSignDoc } from "@cosmjs/proto-signing";
import { defaultRegistryTypes, StargateClient } from "@cosmjs/stargate";
import { TxBody, TxRaw } from "cosmjs-types/cosmos/tx/v1beta1/tx";
import {
  MsgBatchTransfer as GeneratedMsgBatchTransfer,
  MsgDeposit as GeneratedMsgDeposit,
  MsgTransfer as GeneratedMsgTransfer,
  MsgWithdraw as GeneratedMsgWithdraw,
  UserDisclosureMode
} from "../generated/clairveil/privacy/v1/tx.js";
import {
  bytesFromHex,
  bytesToBigIntBE,
  decodeShieldedAddress,
  defaultAccountPrefix,
  deriveDisclosureKeys,
  derivePrivacyMaterial,
  deriveSpendKeys,
  deriveViewKeys,
  FIELD_MODULUS,
  normalizeBech32Prefix
} from "../core/crypto.js";
import {
  decodeAuditDisclosureFromEvent,
  decodeBatchAuditDisclosureFromScanOutput,
  decodeBatchSelfViewDisclosureFromScanOutput,
  decodeBatchUserDisclosureFromScanOutput,
  decodeSelfViewDisclosureFromEvent,
  decodeUserDisclosureFromEvent,
  disclosureScalarFromHex
} from "../core/disclosure.js";
import {
  buildDepositMaterial as buildDepositMaterialCore,
  defaultAssetDenom,
  createNote,
  createSpendNoteHashSigner,
  parseCoin
} from "../core/note.js";
import {
  buildPreparedTransferPayload as buildPreparedTransferPayloadCore,
  buildTransferMessage as buildTransferMessageCore,
  buildPreparedWithdrawProverPayload as buildPreparedWithdrawProverPayloadCore,
  buildRelayWithdrawMsgFromPayload as buildRelayWithdrawMsgFromPayloadCore,
  buildRelayWithdrawPayload as buildRelayWithdrawPayloadCore,
  buildWithdrawMessage as buildWithdrawMessageCore,
  validateRelayWithdrawPayload
} from "../privacy/payload.js";
import {
  canonicalAssetDenomV1,
  canonicalAssetIDHexV1,
  normalizeAssetRegistryQueryResponseV1
} from "../privacy/asset-registry.js";
import {
  batchTransferProofSize,
  batchTransferProofResponseVersion,
  buildMsgBatchTransferFromPrepared,
  buildPreparedBatchTransferPayload,
  normalizePreparedBatchTransferProof,
  preparedBatchTransferEffectHex,
  validatePreparedBatchTransferPayloadEnvelope
} from "../privacy/batch-transfer.js";
import {
  normalizeAuditConfigV1,
  normalizeDisclosureConfigV1,
  normalizeReserveResponseV1
} from "../privacy/network-config.js";
import {
  validateCircuitConfigV1,
  validateExpectedCircuitIdentityV1
} from "../privacy/circuit-config.js";
import {
  computeAssetIdV1,
  computeNoteCommitmentV1,
  fieldHexV1,
  validateBatchTransferEffectsV1
} from "../privacy/protocol-v1.js";
import {
  assertPlanCanBuildTx,
  planTransferBatchNotes,
  planTransferNotes,
  planWithdrawNotes
} from "../privacy/planner.js";
import {
  hashAmount,
  hashRecipient,
  preparePlanReservation,
  reservationHeartbeatIntervalMs,
  reservationStatuses,
  rollbackPlanReservation,
  rollbackPlanReservationPreservingError
} from "../privacy/reservation.js";
import {
  createPrivacyScanValidationStateV2,
  parseNullifierUsage,
  processPrivacyScanPageV2,
  restorePrivacyScanValidationStateV2,
  scanNotes as scanNotesCore,
  serializePrivacyScanValidationStateV2,
  validatePrivacyScanPageV2
} from "../privacy/scan.js";
import {
  createCommitmentPathSnapshotProvider,
  normalizeCommitmentPathsAtRootRequest,
  normalizeCommitmentPathsAtRootResponse
} from "../privacy/merkle-path.js";
import {
  createWalletAdapter,
  derivePrivacyMaterialFromWallet
} from "../wallet/adapter.js";
import {
  base64FromBytes,
  bytesFromBase64,
  bytesFromHex as rawBytesFromHex,
  hash160,
  randomBytes,
  hexFromBytes,
  sha256Hex
} from "../core/browser-crypto.js";

export * from "../core/crypto.js";
export * from "../core/disclosure.js";
export * from "../core/errors.js";
export * from "../core/note.js";
export * from "../privacy/payload.js";
export * from "../privacy/circuit-config.js";
export * from "../privacy/network-config.js";
export * from "../privacy/planner.js";
export * from "../privacy/prover.js";

function appendReservationCleanupErrors(error, cleanupErrors = []) {
  if (!cleanupErrors.length || !error || typeof error !== "object") return;
  try {
    const existing = Array.isArray(error.reservationCleanupErrors)
      ? error.reservationCleanupErrors
      : [];
    error.reservationCleanupErrors = [...existing, ...cleanupErrors];
  } catch {
    // Cleanup annotations are best-effort and must never replace the original error.
  }
}
export * from "../privacy/reservation.js";
export * from "../privacy/scan.js";
export * from "../privacy/merkle-path.js";
export * from "../privacy/note-store.js";
export * from "../core/schemas.js";
export * from "../wallet/adapter.js";
export {
  userDisclosureModeFromJSON,
  userDisclosureModeToJSON
} from "../generated/clairveil/privacy/v1/tx.js";

export const msgDepositTypeUrl = GeneratedMsgDeposit.typeUrl;
export const msgBatchTransferTypeUrl = GeneratedMsgBatchTransfer.typeUrl;
export const msgTransferTypeUrl = GeneratedMsgTransfer.typeUrl;
export const msgWithdrawTypeUrl = GeneratedMsgWithdraw.typeUrl;
const defaultPrepareScanMaxPages = 1000;
const cosmosSignDocMetadataField = "__clairveilCosmosSignDoc";
const cosmosReservationRequiredMemoMarker = "[clairveil-reservation-required:v1]";
const maxBatchTransferMessageBytesV1 = 128 << 10;
const defaultFetchTimeoutMs = 30000;
const maxUint64 = (1n << 64n) - 1n;
const defaultRetryStatuses = Object.freeze([408, 429, 502, 503, 504]);
const defaultQueryRetry = Object.freeze({
  retries: 2,
  baseDelayMs: 250,
  maxDelayMs: 1500,
  jitter: true,
  retryStatuses: defaultRetryStatuses
});
const transferPrivacyPolicyNames = Object.freeze([
  "all-private",
  "amount",
  "to",
  "amount-to",
  "from",
  "amount-from",
  "from-to",
  "amount-from-to"
]);
const transferPrivacyPolicyAliases = Object.freeze({
  "to-from": "from-to",
  "amount-to-from": "amount-from-to"
});
const transferDisclosureModeNames = Object.freeze([
  "none",
  "public",
  "recipient-encrypted"
]);
const transferDisclosureModeAliases = Object.freeze({
  USER_DISCLOSURE_MODE_NONE: "none",
  USER_DISCLOSURE_MODE_PUBLIC: "public",
  USER_DISCLOSURE_MODE_RECIPIENT_ENCRYPTED: "recipient-encrypted"
});
export const batchTransferOperationEvidenceVersion = "batch-transfer-operation-evidence-v1";

function canonicalTransferPrivacyPolicyName(value) {
  let policy;
  if (typeof value === "number") policy = value;
  else if (typeof value === "bigint") policy = Number(value);
  else {
    const text = String(value ?? "all-private").trim() || "all-private";
    const alias = transferPrivacyPolicyAliases[text] || text;
    policy = /^[0-7]$/.test(alias) ? Number(alias) : transferPrivacyPolicyNames.indexOf(alias);
  }
  if (!Number.isInteger(policy) || policy < 0 || policy >= transferPrivacyPolicyNames.length) {
    throw new Error("unsupported transfer privacy policy");
  }
  return transferPrivacyPolicyNames[policy];
}

function canonicalTransferDisclosureModeName(value, policy) {
  if (policy === "all-private") return "none";
  let mode;
  if (typeof value === "number") mode = value;
  else if (typeof value === "bigint") mode = Number(value);
  else {
    const text = String(value ?? "recipient-encrypted").trim() || "recipient-encrypted";
    const alias = transferDisclosureModeAliases[text] || text;
    mode = /^[0-2]$/.test(alias) ? Number(alias) : transferDisclosureModeNames.indexOf(alias);
  }
  if (!Number.isInteger(mode) || mode < 1 || mode >= transferDisclosureModeNames.length) {
    throw new Error("disclosure mode must be public or recipient-encrypted when disclosure is enabled");
  }
  return transferDisclosureModeNames[mode];
}

function randomBatchField({ nonZero = true } = {}) {
  while (true) {
    const candidate = bytesToBigIntBE(randomBytes(32));
    if (candidate < FIELD_MODULUS && (!nonZero || candidate !== 0n)) return candidate;
  }
}

function normalizedBatchNowUnix(value) {
  const nowUnix = Number(value);
  if (!Number.isSafeInteger(nowUnix) || nowUnix < 0) {
    throw new Error("batch transfer chainNowUnix must be a non-negative safe integer");
  }
  return nowUnix;
}

function normalizeBatchTransferOutputMode(value) {
  const mode = String(value ?? "compact").trim() || "compact";
  if (mode === "compact") return "compact";
  if (mode === "exact32" || mode === "exact-32") return "exact32";
  throw new Error("batch transfer outputMode must be compact, exact32, or exact-32");
}

function comparableBatchHex(value) {
  return String(value ?? "").trim().toLowerCase().replace(/^0x/, "");
}

function batchPaymentValue(payment, names, fallback) {
  const values = names
    .filter(name => payment?.[name] !== undefined && payment?.[name] !== null)
    .map(name => payment[name]);
  if (values.length > 1 && values.some(value => String(value) !== String(values[0]))) {
    throw new Error(`batch payment ${names[0]} aliases conflict`);
  }
  return values.length ? values[0] : fallback;
}

function normalizeBatchTransferPayments({
  payments,
  amounts,
  recipient,
  userPrivacyPolicy,
  userDisclosureMode,
  userDisclosureTargetPubKeyHex
} = {}) {
  if (payments != null) {
    if (!Array.isArray(payments) || payments.length < 1 || payments.length > 32) {
      throw new Error("batch transfer payments must contain 1..32 items");
    }
    if (amounts != null || recipient != null) {
      throw new Error("batch transfer payments cannot be combined with legacy amounts/recipient");
    }
  } else {
    if (!Array.isArray(amounts) || amounts.length < 1 || amounts.length > 32) {
      throw new Error("batch transfer amounts must contain 1..32 items");
    }
    if (!String(recipient || "").trim()) throw new Error("batch transfer recipient is required");
  }
  const source = payments ?? amounts.map(amount => ({ amount, recipient }));
  const normalized = source.map((payment, index) => {
    if (!payment || typeof payment !== "object" || Array.isArray(payment)) {
      throw new Error(`batch transfer payment ${index} must be an object`);
    }
    const amount = batchPaymentValue(payment, ["amount"], "");
    const paymentRecipient = String(batchPaymentValue(
      payment,
      ["recipient", "recipientAddress", "recipient_address"],
      ""
    ) || "").trim();
    if (!amount) throw new Error(`batch transfer payment ${index} amount is required`);
    if (!paymentRecipient) throw new Error(`batch transfer payment ${index} recipient is required`);
    const policy = batchPaymentValue(
      payment,
      ["userPrivacyPolicy", "user_privacy_policy", "privacyPolicy", "privacy_policy"],
      userPrivacyPolicy
    );
    const mode = batchPaymentValue(
      payment,
      ["userDisclosureMode", "user_disclosure_mode", "disclosureMode", "disclosure_mode"],
      userDisclosureMode
    );
    const disclosureTarget = String(batchPaymentValue(
      payment,
      [
        "userDisclosureTargetPubKeyHex",
        "user_disclosure_target_pubkey_hex",
        "disclosurePubKeyHex",
        "disclosure_pubkey_hex"
      ],
      userDisclosureTargetPubKeyHex
    ) || "").trim();
    return Object.freeze({
      itemId: String(batchPaymentValue(payment, ["itemId", "item_id"], `batch-item-${index}`) || "").trim() || `batch-item-${index}`,
      amount,
      recipient: paymentRecipient,
      userPrivacyPolicy: policy,
      userDisclosureMode: mode,
      userDisclosureTargetPubKeyHex: disclosureTarget,
      expectedRecipientHash: String(batchPaymentValue(payment, ["expectedRecipientHash", "expected_recipient_hash"], "") || "").trim(),
      expectedAmountHash: String(batchPaymentValue(payment, ["expectedAmountHash", "expected_amount_hash"], "") || "").trim(),
      expectedOutputCommitment: String(batchPaymentValue(payment, ["expectedOutputCommitment", "expected_output_commitment"], "") || "").trim(),
      expectedUserDisclosureDigest: String(batchPaymentValue(payment, ["expectedUserDisclosureDigest", "expected_user_disclosure_digest"], "") || "").trim(),
      expectedAuditDisclosureDigest: String(batchPaymentValue(payment, ["expectedAuditDisclosureDigest", "expected_audit_disclosure_digest", "expectedDisclosureDigest", "expected_disclosure_digest"], "") || "").trim(),
      expectedSelfViewDisclosureDigest: String(batchPaymentValue(payment, ["expectedSelfViewDisclosureDigest", "expected_self_view_disclosure_digest"], "") || "").trim(),
      memo: String(batchPaymentValue(payment, ["memo"], "Transfer") ?? "Transfer")
    });
  });
  if (new Set(normalized.map(payment => payment.itemId)).size !== normalized.length) {
    throw new Error("batch transfer payment item IDs must be unique");
  }
  return normalized;
}

function canonicalBatchEvidenceDigest(value, label, { optional = false } = {}) {
  const text = String(value || "").trim().toLowerCase().replace(/^0x/, "");
  if (optional && !text) return "";
  if (!/^[0-9a-f]{64}$/.test(text)) throw new Error(`${label} must be exactly 32 bytes of hex`);
  return text;
}

function assertExpectedBatchEvidence(expected, actual, label) {
  const normalized = canonicalBatchEvidenceDigest(expected, label, { optional: true });
  if (normalized && normalized !== actual) {
    throw new Error(`${label} does not match the final prepared batch payload`);
  }
}

function batchWireDigest(wire, field, label, { optional = false } = {}) {
  const encoded = String(wire?.[field] || "");
  if (!encoded && optional) return "";
  const bytes = bytesFromBase64(encoded, label);
  if (bytes.length === 0 && optional) return "";
  if (bytes.length !== 32) throw new Error(`${label} must be exactly 32 bytes`);
  return hexFromBytes(bytes);
}

function buildBatchTransferExpectedOutputEvidence({
  payload,
  payments,
  operationId,
  denom,
  shieldedPrefix,
  nowUnix
}) {
  validatePreparedBatchTransferPayloadEnvelope(payload, { nowUnix });
  if (!Array.isArray(payments) || !payments.length ||
      payload.outputs.length < payments.length ||
      payload.message_outputs.length !== payload.outputs.length) {
    throw new Error("batch transfer payment evidence does not match the prepared output shape");
  }
  const assetIDHex = BigInt(payload.asset_id).toString(16).padStart(64, "0");
  const resolvedOperationID = String(operationId || `batch:${payload.payload_hash}`);
  return Object.freeze(payments.map((payment, index) => {
    const output = payload.outputs[index];
    const wire = payload.message_outputs[index];
    if (output?.kind !== "payment" || String(output?.note?.am ?? "") !== String(payment.coin.amount)) {
      throw new Error(`prepared batch payment output ${index} does not match its payment`);
    }
    const recipient = decodeShieldedAddress(payment.recipient, { shieldedPrefix });
    if (
      String(output.note.rsx) !== String(recipient.spendPubKey.x) ||
      String(output.note.rsy) !== String(recipient.spendPubKey.y) ||
      String(output.note.rvx) !== String(recipient.viewPubKey.x) ||
      String(output.note.rvy) !== String(recipient.viewPubKey.y)
    ) {
      throw new Error(`prepared batch payment output ${index} recipient keys do not match its payment`);
    }
    if (
      Number(output.privacy_policy) !== Number(payment.privacyPolicy) ||
      Number(output.disclosure_mode) !== Number(payment.disclosureMode)
    ) {
      throw new Error(`prepared batch payment output ${index} disclosure policy does not match its payment`);
    }
    const commitment = batchWireDigest(wire, "commitment", `batch output ${index} commitment`);
    const userDigest = batchWireDigest(wire, "user_disclosure_digest", `batch output ${index} user disclosure digest`, { optional: true });
    const fullDigest = batchWireDigest(wire, "full_disclosure_digest", `batch output ${index} full disclosure digest`);
    const selfViewPayload = bytesFromBase64(
      String(wire?.self_view_disclosure_payload || ""),
      `batch output ${index} self-view disclosure payload`
    );
    const selfViewDigest = selfViewPayload.length ? fullDigest : "";
    const recipientHash = hashRecipient(payment.recipient, { shieldedPrefix });
    const amountHash = hashAmount(denom, payment.coin.amount);
    const assertedRecipientHash = canonicalBatchEvidenceDigest(payment.expectedRecipientHash, `batch payment ${index} expected recipient hash`, { optional: true });
    const assertedAmountHash = canonicalBatchEvidenceDigest(payment.expectedAmountHash, `batch payment ${index} expected amount hash`, { optional: true });
    if (assertedRecipientHash && assertedRecipientHash !== recipientHash) {
      throw new Error(`batch payment ${index} expected recipient hash does not match its recipient`);
    }
    if (assertedAmountHash && assertedAmountHash !== amountHash) {
      throw new Error(`batch payment ${index} expected amount hash does not match its amount`);
    }
    assertExpectedBatchEvidence(payment.expectedOutputCommitment, commitment, `batch payment ${index} expected output commitment`);
    assertExpectedBatchEvidence(payment.expectedUserDisclosureDigest, userDigest, `batch payment ${index} expected user disclosure digest`);
    assertExpectedBatchEvidence(payment.expectedAuditDisclosureDigest, fullDigest, `batch payment ${index} expected audit disclosure digest`);
    assertExpectedBatchEvidence(payment.expectedSelfViewDisclosureDigest, selfViewDigest, `batch payment ${index} expected self-view disclosure digest`);
    return Object.freeze({
      operation_id: resolvedOperationID,
      item_id: payment.itemId,
      batch_item_index: index,
      role: "payment",
      expected_output_commitment: commitment,
      expected_user_disclosure_digest: userDigest,
      expected_audit_disclosure_digest: fullDigest,
      expected_self_view_disclosure_digest: selfViewDigest,
      expected_recipient_hash: recipientHash,
      expected_amount: String(payment.coin.amount),
      expected_amount_hash: amountHash,
      expected_denom: denom,
      asset_id_hex: assetIDHex,
      user_privacy_policy: payment.privacyPolicy,
      user_disclosure_mode: payment.disclosureMode,
      audit_key_id: payload.audit_key_id,
      audit_key_epoch: String(payload.audit_key_epoch)
    });
  }));
}

function buildBatchTransferOperationEvidence({
  payload,
  proof,
  payments,
  expectedOutputs,
  operationId,
  denom,
  shieldedPrefix,
  nowUnix
}) {
  validatePreparedBatchTransferPayloadEnvelope(payload, { nowUnix });
  const resolvedExpectedOutputs = expectedOutputs || buildBatchTransferExpectedOutputEvidence({
    payload,
    payments,
    operationId,
    denom,
    shieldedPrefix,
    nowUnix
  });
  const resolvedOperationID = String(
    operationId || resolvedExpectedOutputs[0]?.operation_id || `batch:${payload.payload_hash}`
  );
  const effects = preparedBatchTransferEffectHex(payload);
  const evidence = Object.freeze({
    version: batchTransferOperationEvidenceVersion,
    operation_id: resolvedOperationID,
    circuit_set_id: payload.circuit_set_id,
    payload_hash: payload.payload_hash,
    proof_payload_hash: proof.request_payload_hash,
    proof_hash: sha256Hex(proof.proof_bytes),
    input_nullifier_hexes: Object.freeze([...effects.nullifier_hexes]),
    expected_outputs: Object.freeze([...resolvedExpectedOutputs])
  });
  return Object.freeze({
    evidence,
    evidenceHash: sha256Hex(JSON.stringify(evidence))
  });
}

/**
 * Bind a checkpointed batch payload to the same authoritative network
 * configuration used at preparation time. Reusing this at proof-resume and
 * finalization keeps an old checkpoint from becoming signable after an asset,
 * audit, or disclosure-policy change.
 */
function assertPreparedBatchTransferMatchesActiveConfig(payload, transferProtocolConfig, denom) {
  if (String(payload.asset_id) !== computeAssetIdV1(denom).toString()) {
    throw new Error("prepared batch transfer asset ID does not match the authoritative denom");
  }
  const activeAuditConfig = transferProtocolConfig.audit_config;
  if (String(payload.audit_key_id) !== String(activeAuditConfig.audit_key_id) ||
      String(payload.audit_key_epoch) !== String(activeAuditConfig.audit_key_epoch) ||
      hexFromBytes(bytesFromBase64(
        payload.audit_disclosure_target_pubkey,
        "prepared batch transfer audit disclosure target"
      )) !== String(activeAuditConfig.audit_master_pubkey_hex).toLowerCase()) {
    throw new Error("prepared batch transfer audit identity does not match the active chain config");
  }
  for (const [index, output] of payload.outputs.entries()) {
    try {
      assertTransferDisclosureCapabilities(transferProtocolConfig.disclosure_config, {
        userPrivacyPolicy: output.privacy_policy,
        userDisclosureMode: output.disclosure_mode
      });
    } catch (error) {
      throw new Error(`prepared batch transfer output ${index} is incompatible with the active disclosure config`, {
        cause: error
      });
    }
  }
}

function batchTransferNullifiersUnspent(statuses, nullifiers) {
  const statusFor = nullifier => statuses instanceof Map
    ? statuses.get(nullifier) ?? statuses.get(`0x${nullifier}`)
    : statuses?.[nullifier] ?? statuses?.[`0x${nullifier}`];
  for (const [index, nullifier] of nullifiers.entries()) {
    if (statusFor(nullifier) !== false) {
      throw new Error(`batch transfer input nullifier at index ${index} is spent, missing, or has an invalid status`);
    }
  }
}

export function assertTransferDisclosureCapabilities(disclosureConfig, {
  userPrivacyPolicy,
  userDisclosureMode
} = {}) {
  const policy = canonicalTransferPrivacyPolicyName(userPrivacyPolicy);
  const mode = canonicalTransferDisclosureModeName(userDisclosureMode, policy);
  if (!disclosureConfig.supported_user_policies.includes(policy)) {
    throw new Error(`disclosure config does not support transfer privacy policy ${policy}`);
  }
  if (!disclosureConfig.supported_user_modes.includes(mode)) {
    throw new Error(`disclosure config does not support user disclosure mode ${mode}`);
  }
  return Object.freeze({ policy, mode });
}

function bindRawTransferBuilderProtocolConfig(input, transferProtocolConfig) {
  const camelAuditTarget = input?.auditDisclosureTargetPubKeyHex;
  const snakeAuditTarget = input?.audit_disclosure_target_pubkey_hex;
  if (camelAuditTarget != null && snakeAuditTarget != null &&
      String(camelAuditTarget).trim().toLowerCase() !== String(snakeAuditTarget).trim().toLowerCase()) {
    throw new Error("auditDisclosureTargetPubKeyHex aliases conflict");
  }
  const requestedAuditTarget = String(camelAuditTarget ?? snakeAuditTarget ?? "").trim().toLowerCase();
  const activeAuditTarget = String(
    transferProtocolConfig.audit_config.audit_master_pubkey_hex || ""
  ).trim().toLowerCase();
  if (requestedAuditTarget && requestedAuditTarget !== activeAuditTarget) {
    throw new Error("transfer audit disclosure target must exactly match the active chain audit config");
  }
  assertTransferDisclosureCapabilities(transferProtocolConfig.disclosure_config, {
    userPrivacyPolicy: input?.userPrivacyPolicy ?? input?.user_privacy_policy ?? "all-private",
    userDisclosureMode: input?.userDisclosureMode ?? input?.user_disclosure_mode ?? "none"
  });
  return {
    ...input,
    auditDisclosureTargetPubKeyHex: transferProtocolConfig.audit_config.audit_master_pubkey_hex
  };
}

function normalizeTimeoutMs(value, label = "timeoutMs") {
  const timeoutMs = Number(value);
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) {
    throw new Error(`${label} must be positive`);
  }
  return timeoutMs;
}

function normalizeNonNegativeInteger(value, label) {
  const number = Number(value);
  if (!Number.isSafeInteger(number) || number < 0) {
    throw new Error(`${label} must be a non-negative integer`);
  }
  return number;
}

function uint64CursorBigInt(value, label) {
  if (typeof value === "number") {
    if (!Number.isSafeInteger(value) || value < 0) {
      throw new Error(`${label} must be a non-negative safe integer, bigint, or canonical uint64 string`);
    }
    return BigInt(value);
  }
  if (typeof value === "bigint") {
    if (value < 0n || value > maxUint64) {
      throw new Error(`${label} must be within uint64 range`);
    }
    return value;
  }
  const text = String(value ?? "").trim();
  if (!/^(0|[1-9][0-9]*)$/.test(text)) {
    throw new Error(`${label} must be a canonical uint64 decimal string`);
  }
  const parsed = BigInt(text);
  if (parsed > maxUint64) {
    throw new Error(`${label} must be within uint64 range`);
  }
  return parsed;
}

function uint64CursorValue(value, label) {
  const parsed = uint64CursorBigInt(value, label);
  return parsed <= BigInt(Number.MAX_SAFE_INTEGER) ? Number(parsed) : parsed.toString();
}

function compareUint64Cursor(left, right, label) {
  const leftValue = uint64CursorBigInt(left, `${label} left value`);
  const rightValue = uint64CursorBigInt(right, `${label} right value`);
  return leftValue < rightValue ? -1 : leftValue > rightValue ? 1 : 0;
}

function maxUint64Cursor(values, label) {
  let maximum = 0n;
  for (const value of values) {
    const parsed = uint64CursorBigInt(value ?? 0, label);
    if (parsed > maximum) maximum = parsed;
  }
  return maximum <= BigInt(Number.MAX_SAFE_INTEGER) ? Number(maximum) : maximum.toString();
}

function decrementUint64Cursor(value, label) {
  const parsed = uint64CursorBigInt(value ?? 0, label);
  const decremented = parsed > 0n ? parsed - 1n : 0n;
  return decremented <= BigInt(Number.MAX_SAFE_INTEGER) ? Number(decremented) : decremented.toString();
}

function normalizeDelayMs(value, label) {
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0) {
    throw new Error(`${label} must be non-negative`);
  }
  return number;
}

function normalizeQueryRetry(value = {}) {
  if (value === false) {
    return {
      retries: 0,
      baseDelayMs: defaultQueryRetry.baseDelayMs,
      maxDelayMs: defaultQueryRetry.maxDelayMs,
      jitter: false,
      retryStatuses: new Set(defaultRetryStatuses)
    };
  }
  const retry = value || {};
  return {
    retries: normalizeNonNegativeInteger(retry.retries ?? defaultQueryRetry.retries, "queryRetry.retries"),
    baseDelayMs: normalizeDelayMs(retry.baseDelayMs ?? defaultQueryRetry.baseDelayMs, "queryRetry.baseDelayMs"),
    maxDelayMs: normalizeDelayMs(retry.maxDelayMs ?? defaultQueryRetry.maxDelayMs, "queryRetry.maxDelayMs"),
    jitter: retry.jitter ?? defaultQueryRetry.jitter,
    retryStatuses: new Set(retry.retryStatuses ?? defaultRetryStatuses)
  };
}

function retryDelayMs(attemptNumber, retry) {
  const base = retry.baseDelayMs * (attemptNumber <= 1 ? 1 : 3 ** (attemptNumber - 1));
  const capped = Math.min(retry.maxDelayMs, base);
  if (!retry.jitter || capped <= 0) return capped;
  return Math.round(capped + (Math.random() * capped * 0.2));
}

function sleep(ms) {
  return ms > 0 ? new Promise(resolve => setTimeout(resolve, ms)) : Promise.resolve();
}

function isRetryableFetchError(error, retry) {
  if (error?.name === "AbortError" || error?.code === "FETCH_TIMEOUT") return true;
  if (error?.status != null) return retry.retryStatuses.has(Number(error.status));
  return true;
}

function normalizeRestEndpoints(primary, restEndpoints = []) {
  const endpoints = [];
  for (const endpoint of [primary, ...(Array.isArray(restEndpoints) ? restEndpoints : [])]) {
    const normalized = normalizeRestEndpoint(String(endpoint || ""));
    if (normalized && !endpoints.includes(normalized)) {
      endpoints.push(normalized);
    }
  }
  if (!endpoints.length) {
    throw new Error("rest endpoint is required");
  }
  return endpoints;
}

function requiredDepositProof(input = {}) {
  if (input?.proof != null) {
    const proof = typeof input.proof === "string"
      ? bytesFromHex(input.proof, "deposit proof")
      : Uint8Array.from(input.proof);
    if (proof.length) return proof;
  }
  const proofHex = input?.proofHex ?? input?.proof_hex;
  if (proofHex != null && String(proofHex).trim()) {
    const proof = bytesFromHex(proofHex, "deposit proof");
    if (proof.length) return proof;
  }
  throw new Error("deposit proof is required; provide proof or proofHex");
}

export const MsgDeposit = GeneratedMsgDeposit;
export const MsgBatchTransfer = GeneratedMsgBatchTransfer;
export const MsgTransfer = GeneratedMsgTransfer;
export const MsgWithdraw = GeneratedMsgWithdraw;
export { UserDisclosureMode };

export function createClairveilRegistry(extraTypes = []) {
  return new Registry([
    ...defaultRegistryTypes,
    [msgDepositTypeUrl, MsgDeposit],
    [msgBatchTransferTypeUrl, MsgBatchTransfer],
    [msgTransferTypeUrl, MsgTransfer],
    [msgWithdrawTypeUrl, MsgWithdraw],
    ...extraTypes
  ]);
}

export function normalizeRpcEndpoint(rpc) {
  return rpc.replace(/^tcp:\/\//, "http://").replace(/\/$/, "");
}

export function normalizeRestEndpoint(rest) {
  return rest.replace(/\/$/, "");
}

export function buildRootSigningMessage(address, pubKeyHex) {
  return [
    "clairveil-root-v1",
    `address:${address}`,
    `pubkey:${pubKeyHex}`
  ].join("\n");
}

export function cosmosAddressFromPubKey(pubKeyHex, prefix = "clair") {
  return toBech32(prefix, hash160(rawBytesFromHex(pubKeyHex, "pubKeyHex")));
}

export function verifySignerPubKey(address, pubKeyHex, prefix = defaultAccountPrefix) {
  const expectedAddress = cosmosAddressFromPubKey(pubKeyHex, prefix);
  return {
    address,
    expectedAddress,
    matches: address === expectedAddress
  };
}

export function assertSignerPubKey(address, pubKeyHex, prefix = defaultAccountPrefix) {
  const signerCheck = verifySignerPubKey(address, pubKeyHex, prefix);
  if (!signerCheck.matches) {
    throw new Error(`signer address/pubKey mismatch. ${address} maps to ${signerCheck.expectedAddress}`);
  }
  return signerCheck;
}

export function eventAttribute(event, key) {
  return (event?.attributes || []).find(attribute => attribute.key === key)?.value || "";
}

function transactionEvents(tx) {
  return [
    ...(Array.isArray(tx?.events) ? tx.events : []),
    ...(Array.isArray(tx?.tx_result?.events) ? tx.tx_result.events : []),
    ...(Array.isArray(tx?.tx?.events) ? tx.tx.events : [])
  ];
}

function transactionEventType(event) {
  return String(event?.type ?? event?.event_type ?? event?.eventType ?? "").trim().toLowerCase();
}

function transactionEventAttribute(event, key) {
  const attributes = Array.isArray(event?.attributes)
    ? event.attributes
    : Array.isArray(event?.Attributes)
      ? event.Attributes
      : [];
  return attributes.find(attribute => String(attribute?.key ?? attribute?.Key ?? "") === key)?.value ??
    attributes.find(attribute => String(attribute?.key ?? attribute?.Key ?? "") === key)?.Value ??
    "";
}

function normalizedDepositHex(value, label) {
  const raw = value instanceof Uint8Array
    ? hexFromBytes(value)
    : String(value ?? "").trim().replace(/^"|"$/g, "").replace(/^0x/i, "");
  if (!raw || !/^[0-9a-f]+$/i.test(raw) || raw.length % 2 !== 0) {
    throw new Error(`${label} must be non-empty hex`);
  }
  return raw.toLowerCase();
}

function depositExpectedMaterial({ prepared, material, depositMaterial, deposit_material, message, expectedCommitment, expected_commitment, expectedEncryptedNote, expected_encrypted_note } = {}) {
  const resolvedMaterial = depositMaterial ?? deposit_material ?? material ?? prepared?.material ?? null;
  const resolvedMessage = message ?? prepared?.message ?? null;
  const commitment = expectedCommitment ?? expected_commitment ??
    resolvedMaterial?.note_commitment_hex ?? resolvedMaterial?.noteCommitmentHex ??
    resolvedMaterial?.note_commitment ?? resolvedMaterial?.noteCommitment ??
    resolvedMessage?.noteCommitment ?? resolvedMessage?.note_commitment;
  const encryptedNote = expectedEncryptedNote ?? expected_encrypted_note ??
    resolvedMaterial?.encrypted_note_hex ?? resolvedMaterial?.encryptedNoteHex ??
    resolvedMaterial?.encrypted_note ?? resolvedMaterial?.encryptedNote ??
    resolvedMessage?.encryptedNote ?? resolvedMessage?.encrypted_note;
  return {
    commitment: normalizedDepositHex(commitment, "expected deposit commitment"),
    encryptedNote: normalizedDepositHex(encryptedNote, "expected deposit encrypted note")
  };
}

function explicitTransactionCode(tx) {
  const raw = tx?.code ?? tx?.tx_result?.code;
  if (typeof raw === "number" && Number.isSafeInteger(raw) && raw >= 0) return raw;
  if (typeof raw === "string" && /^(0|[1-9][0-9]*)$/.test(raw.trim())) return Number(raw);
  return null;
}

export function isAuditableTransfer(event) {
  return event?.event_type === "shielded_transfer" && Boolean(eventAttribute(event, "audit_disclosure_payload"));
}

function toBase64(bytes) {
  return base64FromBytes(bytes);
}

function fromBase64(value, label = "base64") {
  return bytesFromBase64(value, label);
}

function attachBroadcastEvidence(error, { txHash = "", txBytesHash = "" } = {}) {
  const original = error && typeof error === "object"
    ? error
    : new Error(String(error || "broadcast failed"));
  try {
    if (txHash && !original.txHash && !original.txhash) {
      original.txHash = txHash;
    }
    if (txBytesHash && !original.txBytesHash && !original.tx_bytes_hash) {
      original.txBytesHash = txBytesHash;
    }
    return original;
  } catch {
    const wrapped = new Error(
      String(original?.message || error || "broadcast failed"),
      { cause: original }
    );
    if (typeof original?.name === "string" && original.name) {
      wrapped.name = original.name;
    }
    if (txHash) wrapped.txHash = txHash;
    if (txBytesHash) wrapped.txBytesHash = txBytesHash;
    return wrapped;
  }
}

function directSignDocFromBase64(signDoc) {
  return {
    bodyBytes: fromBase64(signDoc.bodyBytes, "bodyBytes"),
    authInfoBytes: fromBase64(signDoc.authInfoBytes, "authInfoBytes"),
    chainId: signDoc.chainId,
    accountNumber: BigInt(signDoc.accountNumber)
  };
}

function markCosmosSignDocReservationRequired(
  signDoc,
  reservationBatch
) {
  if (
    !signDoc ||
    typeof signDoc !== "object" ||
    !reservationBatch?.reservation_ids?.length
  ) {
    return signDoc;
  }
  const current = signDoc[cosmosSignDocMetadataField] || {};
  const bindingHash = cosmosSignDocBindingHash(signDoc);
  Object.defineProperty(signDoc, cosmosSignDocMetadataField, {
    value: Object.freeze({
      ...current,
      reservationRequired: true,
      bindingHash
    }),
    enumerable: true,
    configurable: true
  });
  return signDoc;
}

function cosmosSignDocMetadata(signDoc) {
  return signDoc?.[cosmosSignDocMetadataField] || {};
}

function reservationRequiredCosmosMemo(memo = "") {
  return [String(memo || "").trim(), cosmosReservationRequiredMemoMarker]
    .filter(Boolean)
    .join("\n");
}

function cosmosTxBodyRequiresReservation(signDoc) {
  try {
    const body = TxBody.decode(fromBase64(signDoc?.bodyBytes, "bodyBytes"));
    return String(body.memo || "")
      .split("\n")
      .some(line => line.trim() === cosmosReservationRequiredMemoMarker);
  } catch {
    return false;
  }
}

function externalCosmosSignDoc(signDoc) {
  if (!signDoc || typeof signDoc !== "object") return signDoc;
  const external = { ...signDoc };
  delete external[cosmosSignDocMetadataField];
  return external;
}

function directBroadcastContext(input = {}) {
  const {
    wallet,
    signDoc,
    waitOptions,
    attempts,
    intervalMs,
    reservationManager,
    reservation_manager,
    reservation,
    reservationBatch,
    reservation_batch
  } = input;
  if (attempts !== undefined && waitOptions?.attempts !== undefined && attempts !== waitOptions.attempts) {
    throw new Error("attempts conflicts with waitOptions.attempts");
  }
  if (intervalMs !== undefined && waitOptions?.intervalMs !== undefined && intervalMs !== waitOptions.intervalMs) {
    throw new Error("intervalMs conflicts with waitOptions.intervalMs");
  }
  const resolvedWaitOptions = {
    ...(waitOptions || {}),
    ...(attempts !== undefined ? { attempts } : {}),
    ...(intervalMs !== undefined ? { intervalMs } : {})
  };
  const resolvedReservation = reservation ?? reservationBatch ?? reservation_batch;
  const reservationContext = broadcastReservationContext({
    ...resolvedWaitOptions,
    reservationManager: reservationManager ?? reservation_manager ?? null,
    reservation: resolvedReservation
  });
  const walletSignDoc = externalCosmosSignDoc(signDoc);
  const broadcastOptions = {
    ...resolvedWaitOptions,
    reservationManager: reservationManager ?? reservation_manager ?? null,
    reservation: resolvedReservation,
    relayPayload: input.relayPayload ?? input.relay_payload,
    getChainNowUnix: input.getChainNowUnix ?? input.get_chain_now_unix,
    chainNowUnix: input.chainNowUnix ?? input.chain_now_unix,
    expectedChainId: input.expectedChainId ?? input.expected_chain_id,
    expectedRecipient: input.expectedRecipient ?? input.expected_recipient,
    accountPrefix: input.accountPrefix ?? input.account_prefix
  };
  return {
    wallet,
    signDoc,
    walletSignDoc,
    reservationContext,
    signDocHash: cosmosSignDocBindingHash(signDoc),
    broadcastOptions
  };
}

function fromHex(value, label = "hex") {
  return rawBytesFromHex(value, label);
}

async function fetchJson(url, {
  timeoutMs = defaultFetchTimeoutMs,
  fetchImpl = globalThis.fetch,
  method = "GET",
  body,
  headers
} = {}) {
  const resolvedTimeoutMs = normalizeTimeoutMs(timeoutMs, "fetch timeoutMs");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), resolvedTimeoutMs);
  const requestHeaders = {
    accept: "application/json",
    ...(body != null ? { "content-type": "application/json" } : {}),
    ...(headers || {})
  };
  try {
    const response = await fetchImpl(url, {
      method,
      headers: requestHeaders,
      body,
      signal: controller.signal
    });
    if (!response.ok) {
      const error = new Error(`${response.status} ${response.statusText}`);
      error.status = response.status;
      error.statusText = response.statusText;
      throw error;
    }
    return response.json();
  } catch (error) {
    if (error?.name === "AbortError") {
      const timeoutError = new Error(`fetch request timed out after ${resolvedTimeoutMs}ms: ${url}`);
      timeoutError.code = "FETCH_TIMEOUT";
      throw timeoutError;
    }
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

async function fetchJsonWithRetry(urlForEndpoint, endpoints, { timeoutMs, retry, fetchImpl, method, body, headers } = {}) {
  const normalizedRetry = normalizeQueryRetry(retry);
  let lastError = null;
  for (const endpoint of endpoints) {
    for (let attempt = 0; attempt <= normalizedRetry.retries; attempt += 1) {
      try {
        return {
          data: await fetchJson(urlForEndpoint(endpoint), { timeoutMs, fetchImpl, method, body, headers }),
          endpoint
        };
      } catch (error) {
        lastError = error;
        const retryable = isRetryableFetchError(error, normalizedRetry);
        if (!retryable) {
          throw error;
        }
        const canRetry = attempt < normalizedRetry.retries && retryable;
        if (!canRetry) break;
        await sleep(retryDelayMs(attempt + 1, normalizedRetry));
      }
    }
  }
  throw lastError;
}

function unwrapBaseAccount(value) {
  let current = value;
  const seen = new Set();
  // Auth QueryAccount returns BaseAccount fields directly for common accounts,
  // but vesting/module account Any values wrap those fields one or two levels
  // below base_vesting_account/base_account. Keep this bounded and accept only
  // the exact account-number/sequence pair needed by direct signing.
  for (let depth = 0; depth < 8 && current && typeof current === "object"; depth += 1) {
    if (seen.has(current)) return null;
    seen.add(current);
    if (current.account_number != null && current.sequence != null) return current;
    current = current.base_account ?? current.baseAccount ??
      current.base_vesting_account ?? current.baseVestingAccount ?? null;
  }
  return null;
}

function privacyEventsQuery({
  afterHeight,
  after_height,
  page,
  limit,
  eventTypes,
  event_types
} = {}) {
  const params = new URLSearchParams();
  const resolvedAfterHeight = afterHeight ?? after_height;
  if (resolvedAfterHeight != null) {
    params.set("after_height", String(resolvedAfterHeight));
  }
  if (page != null) {
    params.set("page", String(page));
  }
  if (limit != null) {
    params.set("limit", String(limit));
  }
  const resolvedEventTypes = eventTypes ?? event_types;
  if (Array.isArray(resolvedEventTypes)) {
    for (const eventType of resolvedEventTypes) {
      if (String(eventType || "").trim()) {
        params.append("event_types", String(eventType).trim());
      }
    }
  } else if (resolvedEventTypes != null && String(resolvedEventTypes).trim()) {
    params.set("event_types", String(resolvedEventTypes).trim());
  }
  const query = params.toString();
  return query ? `?${query}` : "";
}

function scanEventsQuery({
  afterHeight,
  after_height,
  afterSequence,
  after_sequence,
  limit,
  eventTypes,
  event_types
} = {}) {
  const params = new URLSearchParams();
  const resolvedAfterHeight = afterHeight ?? after_height;
  if (resolvedAfterHeight != null) {
    params.set("after_height", String(resolvedAfterHeight));
  }
  const resolvedAfterSequence = afterSequence ?? after_sequence;
  if (resolvedAfterSequence != null) {
    params.set("after_sequence", String(resolvedAfterSequence));
  }
  if (limit != null) {
    params.set("limit", String(limit));
  }
  const resolvedEventTypes = eventTypes ?? event_types;
  if (Array.isArray(resolvedEventTypes)) {
    for (const eventType of resolvedEventTypes) {
      if (String(eventType || "").trim()) {
        params.append("event_types", String(eventType).trim());
      }
    }
  } else if (resolvedEventTypes != null && String(resolvedEventTypes).trim()) {
    params.set("event_types", String(resolvedEventTypes).trim());
  }
  const query = params.toString();
  return query ? `?${query}` : "";
}

function jsonRequestBody(value) {
  return JSON.stringify(value, (_key, item) => typeof item === "bigint" ? item.toString() : item);
}

function privacyScanRequestBody({
  after,
  outputLimit,
  output_limit,
  eventLimit,
  event_limit,
  maxEncodedBytes,
  max_encoded_bytes,
  eventTypes,
  event_types
} = {}) {
  const cursor = after && typeof after === "object"
    ? {
      height: after.height ?? 0,
      globalSequence: after.globalSequence ?? after.global_sequence ?? 0,
      outputIndex: after.outputIndex ?? after.output_index ?? 0
    }
    : undefined;
  return {
    ...(cursor ? { after: cursor } : {}),
    ...(outputLimit ?? output_limit) != null ? { outputLimit: outputLimit ?? output_limit } : {},
    ...(eventLimit ?? event_limit) != null ? { eventLimit: eventLimit ?? event_limit } : {},
    ...(maxEncodedBytes ?? max_encoded_bytes) != null ? { maxEncodedBytes: maxEncodedBytes ?? max_encoded_bytes } : {},
    ...(eventTypes ?? event_types) != null ? { eventTypes: eventTypes ?? event_types } : {}
  };
}

function commitmentPathsAtRootRequestBody({
  commitmentHexes,
  commitment_hexes,
  rootHex,
  root_hex,
  snapshotHeight,
  snapshot_height
} = {}) {
  const commitments = commitmentHexes ?? commitment_hexes;
  if (!Array.isArray(commitments) || commitments.length === 0 || commitments.length > 16) {
    throw new Error("commitmentHexes must contain 1..16 commitments");
  }
  const normalizedRoot = String(rootHex ?? root_hex ?? "").trim();
  if (!normalizedRoot) throw new Error("rootHex is required");
  const height = snapshotHeight ?? snapshot_height;
  return {
    commitmentHexes: commitments.map(value => String(value || "").trim()),
    rootHex: normalizedRoot,
    ...(height == null || String(height).trim() === "" ? {} : { snapshotHeight: height })
  };
}

function privacyEventsCursor(data, request = {}) {
  const events = data?.events || [];
  let latestHeight = 0;
  let latestTxHash = "";
  for (const event of events) {
    const height = uint64CursorValue(event?.height ?? 0, "privacy event height");
    if (compareUint64Cursor(height, latestHeight, "privacy event height") >= 0) {
      latestHeight = height;
      latestTxHash = String(event?.tx_hash_hex || "").toUpperCase();
    }
  }
  return {
    source: "privacy_events",
    after_height: uint64CursorValue(request.afterHeight ?? request.after_height ?? 0, "privacy events after height"),
    page: Number(data?.page ?? request.page ?? 1),
    limit: Number(data?.limit ?? request.limit ?? events.length),
    event_types: request.eventTypes ?? request.event_types ?? [],
    has_more: Boolean(data?.has_more),
    latest_height: latestHeight,
    latest_tx_hash: latestTxHash
  };
}

function scanEventsCursor(data, request = {}) {
  const events = data?.events || [];
  let latestHeight = 0;
  let latestSequence = 0;
  let latestTxHash = "";
  for (const event of events) {
    const height = uint64CursorValue(event?.height ?? 0, "scan event height");
    const sequence = uint64CursorValue(event?.sequence ?? 0, "scan event sequence");
    const heightComparison = compareUint64Cursor(height, latestHeight, "scan event height");
    if (heightComparison > 0 || (
      heightComparison === 0 &&
      compareUint64Cursor(sequence, latestSequence, "scan event sequence") >= 0
    )) {
      latestHeight = height;
      latestSequence = sequence;
      latestTxHash = String(event?.tx_hash_hex ?? event?.txHashHex ?? "").toUpperCase();
    }
  }
  return {
    source: "scan_events",
    after_height: uint64CursorValue(request.afterHeight ?? request.after_height ?? 0, "scan events after height"),
    after_sequence: uint64CursorValue(request.afterSequence ?? request.after_sequence ?? 0, "scan events after sequence"),
    limit: Number(data?.limit ?? request.limit ?? events.length),
    event_types: request.eventTypes ?? request.event_types ?? [],
    has_more: Boolean(data?.has_more),
    next_height: uint64CursorValue(data?.next_height ?? data?.nextHeight ?? request.afterHeight ?? request.after_height ?? 0, "scan events next height"),
    next_sequence: uint64CursorValue(data?.next_sequence ?? data?.nextSequence ?? request.afterSequence ?? request.after_sequence ?? 0, "scan events next sequence"),
    latest_height: latestHeight,
    latest_sequence: latestSequence,
    latest_tx_hash: latestTxHash,
    scan_format_version: Number(data?.scan_format_version ?? data?.scanFormatVersion ?? 0),
    view_tag_version: Number(data?.view_tag_version ?? data?.viewTagVersion ?? 0)
  };
}

function assertScanEventsVersions(data) {
  const scanFormatVersion = Number(data?.scan_format_version ?? data?.scanFormatVersion ?? 0);
  const viewTagVersion = Number(data?.view_tag_version ?? data?.viewTagVersion ?? 0);
  if (scanFormatVersion !== 1) {
    const error = new Error(`unsupported scan_format_version ${scanFormatVersion}; expected 1`);
    error.code = "UNSUPPORTED_SCAN_EVENTS_VERSION";
    throw error;
  }
  if (viewTagVersion !== 1) {
    const error = new Error(`unsupported view_tag_version ${viewTagVersion}; expected 1`);
    error.code = "UNSUPPORTED_SCAN_EVENTS_VERSION";
    throw error;
  }
}

export function nextPrivacyScanOptions(scanOrCursor = {}, defaults = {}) {
  const cursor = scanOrCursor?.scanCursor || scanOrCursor || {};
  if (cursor.source === "privacy_scan" || cursor.next_cursor != null || cursor.nextCursor != null) {
    const hasMore = Boolean(cursor.has_more ?? cursor.hasMore);
    const nextCursor = cursor.next_cursor ?? cursor.nextCursor ?? cursor.after ?? cursor.afterCursor ?? {
      height: 0,
      global_sequence: 0,
      output_index: 0
    };
    const normalized = validatePrivacyScanPageV2({
      scanSchemaVersion: "privacy-scan-v2",
      summaries: [],
      outputs: [],
      nextCursor,
      hasMore: false
    }, { after: nextCursor }).next_cursor;
    const next = {
      after: {
        height: normalized.height,
        globalSequence: normalized.global_sequence,
        outputIndex: normalized.output_index
      },
      limit: Number(cursor.output_limit ?? cursor.outputLimit ?? defaults.limit ?? 200),
      outputLimit: Number(cursor.output_limit ?? cursor.outputLimit ?? defaults.outputLimit ?? defaults.output_limit ?? 200),
      eventLimit: cursor.event_limit ?? cursor.eventLimit ?? defaults.eventLimit ?? defaults.event_limit,
      maxEncodedBytes: cursor.max_encoded_bytes ?? cursor.maxEncodedBytes ?? defaults.maxEncodedBytes ?? defaults.max_encoded_bytes,
      eventTypes: [],
      scanSource: "privacy_scan",
      hasMore,
      completed: !hasMore
    };
    const validationState = cursor.validation_state ?? cursor.validationState;
    if (validationState != null) {
      // Parse before returning it so a corrupt durable cursor cannot silently
      // downgrade the cross-page all-or-none batch disclosure guarantee.
      next.validationStateSnapshot = serializePrivacyScanValidationStateV2(
        restorePrivacyScanValidationStateV2(validationState)
      );
    }
    const maxPages = defaults.maxPages ?? defaults.max_pages;
    if (maxPages != null) next.maxPages = maxPages;
    const includeFoundNotes = defaults.includeFoundNotes ?? defaults.include_found_notes;
    if (includeFoundNotes != null) next.includeFoundNotes = Boolean(includeFoundNotes);
    return next;
  }
  if (cursor.source === "scan_events" || cursor.next_sequence != null || cursor.nextSequence != null) {
    const hasMore = Boolean(cursor.has_more ?? cursor.hasMore);
    const next = {
      afterHeight: uint64CursorValue(
        hasMore
          ? cursor.next_height ?? cursor.nextHeight ?? cursor.after_height ?? cursor.afterHeight ?? 0
          : cursor.next_height ?? cursor.nextHeight ?? cursor.latest_height ?? cursor.latestHeight ?? cursor.after_height ?? cursor.afterHeight ?? 0,
        "scan resume height"
      ),
      afterSequence: uint64CursorValue(
        hasMore
          ? cursor.next_sequence ?? cursor.nextSequence ?? cursor.after_sequence ?? cursor.afterSequence ?? 0
          : cursor.next_sequence ?? cursor.nextSequence ?? cursor.latest_sequence ?? cursor.latestSequence ?? cursor.after_sequence ?? cursor.afterSequence ?? 0,
        "scan resume sequence"
      ),
      limit: Number(cursor.limit ?? defaults.limit ?? 200),
      eventTypes: cursor.event_types ?? cursor.eventTypes ?? defaults.eventTypes ?? defaults.event_types ?? [],
      hasMore,
      completed: !hasMore
    };
    next.scanSource = "scan_events";
    const maxPages = defaults.maxPages ?? defaults.max_pages;
    if (maxPages != null) next.maxPages = maxPages;
    const includeFoundNotes = defaults.includeFoundNotes ?? defaults.include_found_notes;
    if (includeFoundNotes != null) next.includeFoundNotes = Boolean(includeFoundNotes);
    return next;
  }
  const afterHeight = uint64CursorValue(cursor.after_height ?? cursor.afterHeight ?? defaults.afterHeight ?? defaults.after_height ?? 0, "privacy events after height");
  const latestHeight = uint64CursorValue(cursor.latest_height ?? cursor.latestHeight ?? 0, "privacy events latest height");
  const hasMore = Boolean(cursor.has_more ?? cursor.hasMore);
  const nextPage = hasMore
    ? Number(cursor.next_page ?? cursor.nextPage ?? (Number(cursor.page || 1) + 1))
    : 1;
  const nextAfterHeight = hasMore
    ? afterHeight
    : maxUint64Cursor([afterHeight, latestHeight], "privacy events resume height");
  const next = {
    afterHeight: nextAfterHeight,
    page: nextPage,
    limit: Number(cursor.limit ?? defaults.limit ?? 200),
    eventTypes: cursor.event_types ?? cursor.eventTypes ?? defaults.eventTypes ?? defaults.event_types ?? [],
    scanSource: cursor.source === "privacy_events" ? "privacy_events" : defaults.scanSource ?? defaults.scan_source ?? "privacy_events"
  };
  const maxPages = defaults.maxPages ?? defaults.max_pages;
  if (maxPages != null) next.maxPages = maxPages;
  const includeFoundNotes = defaults.includeFoundNotes ?? defaults.include_found_notes;
  if (includeFoundNotes != null) next.includeFoundNotes = Boolean(includeFoundNotes);
  next.hasMore = hasMore;
  next.completed = !hasMore;
  return next;
}

function resolveScanOptions({
  scan,
  after,
  afterHeight,
  after_height,
  afterSequence,
  after_sequence,
  page,
  limit,
  maxPages,
  max_pages,
  eventTypes,
  event_types,
  outputLimit,
  output_limit,
  eventLimit,
  event_limit,
  maxEncodedBytes,
  max_encoded_bytes,
  validationStateSnapshot,
  validation_state_snapshot,
  scanSource,
  scan_source
} = {}) {
  return {
    after: scan?.after ?? after,
    afterHeight: scan?.afterHeight ?? scan?.after_height ?? afterHeight ?? after_height,
    afterSequence: scan?.afterSequence ?? scan?.after_sequence ?? afterSequence ?? after_sequence,
    page: scan?.page ?? page,
    limit: scan?.limit ?? limit,
    maxPages: scan?.maxPages ?? scan?.max_pages ?? maxPages ?? max_pages,
    eventTypes: scan?.eventTypes ?? scan?.event_types ?? eventTypes ?? event_types,
    outputLimit: scan?.outputLimit ?? scan?.output_limit ?? outputLimit ?? output_limit,
    eventLimit: scan?.eventLimit ?? scan?.event_limit ?? eventLimit ?? event_limit,
    maxEncodedBytes: scan?.maxEncodedBytes ?? scan?.max_encoded_bytes ?? maxEncodedBytes ?? max_encoded_bytes,
    validationStateSnapshot: scan?.validationStateSnapshot ?? scan?.validation_state_snapshot ?? validationStateSnapshot ?? validation_state_snapshot,
    scanSource: scan?.scanSource ?? scan?.scan_source ?? scanSource ?? scan_source
  };
}

function indexedTxToRestish(tx) {
  if (!tx) return null;
  return {
    height: String(tx.height),
    txhash: tx.hash,
    code: tx.code,
    raw_log: tx.rawLog,
    events: tx.events || [],
    tx: tx.tx
  };
}

function publicPrivacyAccount(material) {
  return {
    address: material.address,
    pubKeyHex: material.pubKeyHex,
    signing_message: material.signingMessage,
    shielded_address: material.shieldedAddress,
    disclosure_pubkey_hex: material.disclosurePubKeyHex,
    root_signature_hash: material.rootSignatureHash
  };
}

async function reservationAvailableNotes(reservationManager, notes) {
  if (!reservationManager) return notes;
  if (typeof reservationManager.filterAvailableNotes !== "function") {
    throw new Error("reservationManager.filterAvailableNotes is required");
  }
  return reservationManager.filterAvailableNotes(notes);
}

function reservationBatchSummary(batch) {
  if (!batch) return null;
  return {
    operation_id: batch.operation_id,
    lease_owner: batch.lease_owner || batch.reservations?.[0]?.lease_owner || "",
    lease_token: batch.lease_token || batch.reservations?.[0]?.lease_token || "",
    lease_until: batch.lease_until || batch.reservations?.[0]?.lease_until || "",
    reservation_ids: [...(batch.reservation_ids || [])],
    reservations: [...(batch.reservations || [])]
  };
}

function broadcastReservationContext(options = {}) {
  const reservationManager = options.reservationManager ?? options.reservation_manager ?? null;
  const reservation = options.reservation ?? options.reservationBatch ?? options.reservation_batch ?? null;
  const reservationIDs = [...(reservation?.reservation_ids || [])].filter(Boolean).map(String);
  if (!reservationManager && !reservation) return null;
  if (!reservationIDs.length) {
    throw new Error("reserved-note broadcast requires reservation ids");
  }
  if (!reservationManager || typeof reservationManager.markBroadcastAttempting !== "function") {
    throw new Error("reservationManager.markBroadcastAttempting is required for reserved-note broadcast");
  }
  const leaseToken = String(
    reservation?.lease_token || reservation?.reservations?.[0]?.lease_token || ""
  );
  if (!leaseToken) {
    throw new Error("reserved-note broadcast requires the current lease token");
  }
  return { reservationManager, reservationIDs, leaseToken };
}

function signedWithdrawMessage(signedTx) {
  const body = TxBody.decode(fromBase64(signedTx?.bodyBytes, "bodyBytes"));
  const withdrawals = body.messages.filter(message => message.typeUrl === msgWithdrawTypeUrl);
  if (!withdrawals.length) return null;
  if (body.messages.length !== 1 || withdrawals.length !== 1) {
    throw new Error("withdraw broadcast must contain exactly one MsgWithdraw");
  }
  return GeneratedMsgWithdraw.decode(withdrawals[0].value);
}

function normalizedTxRawBytes(value) {
  if (!(value instanceof Uint8Array)) {
    throw new Error("signed TxRaw bytes must be a Uint8Array");
  }
  if (!value.length) {
    throw new Error("signed TxRaw bytes must not be empty");
  }
  const txBytes = Uint8Array.from(value);
  try {
    TxRaw.decode(txBytes);
  } catch (error) {
    throw new Error(`signed TxRaw bytes are invalid: ${error.message}`);
  }
  return txBytes;
}

function signedTxFromRawBytes(txBytes) {
  const txRaw = TxRaw.decode(txBytes);
  return {
    bodyBytes: toBase64(txRaw.bodyBytes),
    authInfoBytes: toBase64(txRaw.authInfoBytes),
    // Relay/reservation validation only binds TxBody and AuthInfo. Keep this
    // field for the familiar SignedTxBase64 shape without rewriting TxRaw.
    signature: toBase64(txRaw.signatures[0] || new Uint8Array())
  };
}

export function cosmosSignDocBindingHash({ bodyBytes, authInfoBytes } = {}) {
  const txRaw = TxRaw.fromPartial({
    bodyBytes: fromBase64(bodyBytes, "bodyBytes"),
    authInfoBytes: fromBase64(authInfoBytes, "authInfoBytes"),
    signatures: []
  });
  return sha256Hex(TxRaw.encode(txRaw).finish());
}

async function authoritativeReservationRecords(context) {
  if (!context) return [];
  if (typeof context.reservationManager.getReservation !== "function") {
    throw new Error("reservationManager.getReservation is required for reserved-note broadcast validation");
  }
  return Promise.all(context.reservationIDs.map(id => context.reservationManager.getReservation(id)));
}

function batchTransferNullifierHexesFromReservationRecords(records) {
  const values = records.map(record => record?.metadata?.batch_transfer_nullifier_hexes);
  if (!values.some(value => value != null)) return [];
  if (values.some(value => !Array.isArray(value))) {
    throw new Error("batch transfer reservation is missing its persisted input nullifiers");
  }
  const normalized = values.map(value => value.map((nullifier, index) => {
    const hex = String(nullifier ?? "").trim().replace(/^0x/i, "").toLowerCase();
    if (!/^[0-9a-f]{64}$/.test(hex)) {
      throw new Error(`batch transfer reservation nullifier at index ${index} is invalid`);
    }
    return hex;
  }));
  if (!normalized[0]?.length || normalized.some(value =>
    value.length !== normalized[0].length || value.some((nullifier, index) => nullifier !== normalized[0][index])
  )) {
    throw new Error("batch transfer reservations disagree on their persisted input nullifiers");
  }
  return normalized[0];
}

async function recheckReservedBatchTransferNullifiers(context, checkNullifiers) {
  if (!context) return;
  const nullifiers = batchTransferNullifierHexesFromReservationRecords(
    await authoritativeReservationRecords(context)
  );
  if (!nullifiers.length) return;
  batchTransferNullifiersUnspent(await checkNullifiers(nullifiers), nullifiers);
}

function assertReservationPayloadMatches(records, payload) {
  if (!records.length) return;
  const payloadHash = String(payload?.payload_hash || "").trim();
  const storedHashes = records.map(record => String(record?.payload_hash ?? record?.payloadHash ?? "").trim());
  if (!payloadHash || storedHashes.some(hash => !hash || hash !== payloadHash)) {
    throw new Error("relay payload does not match the reserved payload hash");
  }
}

function assertReservationSignDocMatches(records, signDocHash, { allowPayloadBinding = false } = {}) {
  if (!records.length) return;
  const mismatched = records.some(record => {
    const storedHash = String(record?.sign_doc_hash ?? record?.signDocHash ?? "").trim();
    if (storedHash) return storedHash !== signDocHash;
    return !(allowPayloadBinding && String(record?.payload_hash ?? record?.payloadHash ?? "").trim());
  });
  if (!signDocHash || mismatched) {
    throw new Error("Cosmos sign doc does not match the reservation ProofReady artifact");
  }
}

function assertSignedWithdrawMatchesPayload(message, payload) {
  const normalizedPayloadHex = value => String(value || "").trim().replace(/^0x/i, "").toLowerCase();
  const matches =
    hexFromBytes(message.proof) === normalizedPayloadHex(payload.proof_hex) &&
    hexFromBytes(message.root) === normalizedPayloadHex(payload.root_hex) &&
    hexFromBytes(message.nullifier) === normalizedPayloadHex(payload.nullifier_hex) &&
    String(message.amount) === String(payload.amount) &&
    String(message.recipient) === String(payload.recipient) &&
    String(message.chainId) === String(payload.chain_id) &&
    BigInt(message.expiresAtUnix) === BigInt(payload.expires_at_unix);
  if (!matches) {
    throw new Error("relay payload does not match the Cosmos signed transaction being broadcast");
  }
}

async function validateRelayBroadcastContext(options, {
  expectedChainId,
  accountPrefix,
  signedTx,
  reservationContext,
  signDocHash
} = {}) {
  const payload = options?.relayPayload ?? options?.relay_payload ?? null;
  const reservationRecords = await authoritativeReservationRecords(reservationContext);
  assertReservationSignDocMatches(reservationRecords, signDocHash, { allowPayloadBinding: Boolean(payload) });
  const chainTimeProvider = options?.getChainNowUnix ?? options?.get_chain_now_unix;
  const withdrawMessage = signedWithdrawMessage(signedTx);
  if (!payload) {
    if (withdrawMessage) {
      throw new Error("withdraw broadcast requires relayPayload and authoritative chain time");
    }
    if (
      options?.chainNowUnix != null ||
      options?.chain_now_unix != null ||
      chainTimeProvider != null
    ) {
      throw new Error("relayPayload is required when relay broadcast chain time is provided");
    }
    return;
  }
  if (chainTimeProvider != null && typeof chainTimeProvider !== "function") {
    throw new Error("getChainNowUnix must be a function");
  }
  const chainNowUnix = chainTimeProvider
    ? await chainTimeProvider()
    : options.chainNowUnix ?? options.chain_now_unix;
  validateRelayWithdrawPayload(payload, {
    chainNowUnix,
    expectedChainId: options.expectedChainId ?? options.expected_chain_id ?? expectedChainId,
    expectedRecipient: options.expectedRecipient ?? options.expected_recipient,
    accountPrefix: options.accountPrefix ?? options.account_prefix ?? accountPrefix
  });
  assertReservationPayloadMatches(reservationRecords, payload);
  if (!withdrawMessage) {
    throw new Error("relayPayload does not match a Cosmos MsgWithdraw transaction");
  }
  assertSignedWithdrawMatchesPayload(withdrawMessage, payload);
}

function attachReservationBookkeepingError(error, bookkeepingError) {
  const original = error && typeof error === "object"
    ? error
    : new Error(String(error || "broadcast failed"));
  try {
    original.reservationBookkeepingError = bookkeepingError;
    original.reservationReconciliationRequired = true;
    return original;
  } catch {
    const wrapped = new Error(
      String(original?.message || error || "broadcast failed"),
      { cause: original }
    );
    if (typeof original?.name === "string" && original.name) {
      wrapped.name = original.name;
    }
    wrapped.reservationBookkeepingError = bookkeepingError;
    wrapped.reservationReconciliationRequired = true;
    return wrapped;
  }
}

async function beginBroadcastReservation(context, reason, evidence = {}) {
  if (!context) return;
  await context.reservationManager.markBroadcastAttempting(context.reservationIDs, {
    leaseToken: context.leaseToken,
    reason,
    txHash: evidence.txHash || "",
    txBytesHash: evidence.txBytesHash || "",
    signDocHash: evidence.signDocHash || ""
  });
}

async function markBroadcastReservationUnknown(context, error, evidence = {}) {
  if (!context) return;
  try {
    await context.reservationManager.markUnknown(context.reservationIDs, {
      leaseToken: context.leaseToken,
      txHash: evidence.txHash || "",
      txBytesHash: evidence.txBytesHash || "",
      signDocHash: evidence.signDocHash || "",
      error: "sdk_broadcast_result_unknown",
      metadata: { reconcile_reason: "sdk_broadcast_result_unknown" }
    });
  } catch (bookkeepingError) {
    throw attachReservationBookkeepingError(error, bookkeepingError);
  }
}

async function markBroadcastReservationSubmitted(context, evidence = {}) {
  if (!context) return;
  try {
    await context.reservationManager.markSubmitted(context.reservationIDs, {
      leaseToken: context.leaseToken,
      txHash: evidence.txHash || "",
      txBytesHash: evidence.txBytesHash || "",
      signDocHash: evidence.signDocHash || ""
    });
  } catch (bookkeepingError) {
    const error = new Error("transaction was broadcast but reservation submission could not be recorded");
    error.txHash = evidence.txHash || "";
    error.txBytesHash = evidence.txBytesHash || "";
    throw attachReservationBookkeepingError(error, bookkeepingError);
  }
}

function isExplicitWalletRejection(error) {
  return String(error?.code ?? error?.data?.code ?? "") === "4001";
}

async function markSigningReservationRejected(context, error) {
  if (!context) return;
  try {
    if (typeof context.reservationManager.markBroadcastRejected !== "function") {
      throw new Error("reservationManager.markBroadcastRejected is required for pre-broadcast wallet rejection");
    }
    await context.reservationManager.markBroadcastRejected(context.reservationIDs, {
      leaseToken: context.leaseToken,
      error: "wallet_rejected_before_broadcast",
      providerCode: "4001",
      metadata: {
        wallet_rejected_before_broadcast: true,
        provider_rejection_code: "4001",
        reconcile_reason: "wallet_rejected_before_broadcast"
      }
    });
  } catch (bookkeepingError) {
    throw attachReservationBookkeepingError(error, bookkeepingError);
  }
}

function transferProofReadyMetadata(built, context = {}) {
  const output = built?.payload?.outputs?.[0] || {};
  const coin = context.amount ? parseCoin(context.amount, context.denom || "") : null;
  const batchItemIndex = context.batchItemIndex ?? context.batch_item_index;
  const batchItemIndexKnown = context.batchItemIndexKnown ?? context.batch_item_index_known;
  const expectedOutputCommitment = built?.payload?.outputs?.[0]?.commitment_hex || "";
  const expectedDisclosureDigest = built?.payload?.audit_disclosure_digest_hex || "";
  const expectedRecipientHash = context.expectedRecipientHash ?? context.expected_recipient_hash ?? "";
  const expectedAmount = output.amount || coin?.amount || "";
  const expectedAmountHash = context.expectedAmountHash ?? context.expected_amount_hash ?? "";
  const expectedDenom = context.expectedDenom ?? context.expected_denom ?? coin?.denom ?? context.denom ?? "";
  const operationSuccessEvidenceRequired = Boolean(
    expectedOutputCommitment &&
    expectedDisclosureDigest &&
    expectedRecipientHash &&
    expectedAmount &&
    expectedAmountHash &&
    expectedDenom
  );
  return {
    payloadHash: built?.payload?.payload_hash || "",
    signDocHash: context.signDocHash ?? context.sign_doc_hash ?? "",
    expectedOutputCommitment,
    expectedDisclosureDigest,
    expectedRecipientHash,
    expectedAmount,
    expectedAmountHash,
    expectedDenom,
    batchItemIndex: batchItemIndex ?? 0,
    batchItemIndexKnown: batchItemIndexKnown ?? (operationSuccessEvidenceRequired || (batchItemIndex !== undefined && batchItemIndex !== null)),
    operationSuccessEvidenceRequired
  };
}

function resolveDirectOperationEvidenceHashes({
  expectedRecipientHash,
  expected_recipient_hash,
  expectedAmountHash,
  expected_amount_hash
} = {}) {
  const recipientProvided = operationEvidenceAliasProvided(
    expectedRecipientHash,
    expected_recipient_hash
  );
  const amountProvided = operationEvidenceAliasProvided(
    expectedAmountHash,
    expected_amount_hash
  );
  const recipientHash = resolveOperationEvidenceAlias(
    expectedRecipientHash,
    expected_recipient_hash,
    "expectedRecipientHash"
  );
  const amountHash = resolveOperationEvidenceAlias(
    expectedAmountHash,
    expected_amount_hash,
    "expectedAmountHash"
  );
  if (recipientProvided !== amountProvided) {
    throw new Error("expected recipient hash and expected amount hash must be provided together");
  }
  if (recipientProvided && !recipientHash.trim()) {
    throw new Error("expectedRecipientHash must not be empty");
  }
  if (amountProvided && !amountHash.trim()) {
    throw new Error("expectedAmountHash must not be empty");
  }
  return {
    provided: recipientProvided,
    expectedRecipientHash: recipientHash,
    expectedAmountHash: amountHash
  };
}

function operationEvidenceAliasProvided(camelValue, snakeValue) {
  return (camelValue !== undefined && camelValue !== null) ||
    (snakeValue !== undefined && snakeValue !== null);
}

function resolveOperationEvidenceAlias(camelValue, snakeValue, name) {
  const camelProvided = camelValue !== undefined && camelValue !== null;
  const snakeProvided = snakeValue !== undefined && snakeValue !== null;
  if (camelProvided && snakeProvided && String(camelValue) !== String(snakeValue)) {
    throw new Error(`${name} aliases conflict`);
  }
  return String(camelProvided ? camelValue : snakeProvided ? snakeValue : "");
}

function resolveDisclosureAssetDenom(assetDenom, asset_denom, defaultDenom) {
  return resolveOperationEvidenceAlias(assetDenom, asset_denom, "assetDenom") || defaultDenom;
}

function resolveOperationEvidenceArrayAlias(camelValue, snakeValue, name) {
  const camelProvided = camelValue !== undefined && camelValue !== null;
  const snakeProvided = snakeValue !== undefined && snakeValue !== null;
  if (camelProvided && !Array.isArray(camelValue)) {
    throw new Error(`${name} must be an array`);
  }
  if (snakeProvided && !Array.isArray(snakeValue)) {
    throw new Error(`${name} must be an array`);
  }
  if (camelProvided && snakeProvided) {
    const camelItems = camelValue.map(String);
    const snakeItems = snakeValue.map(String);
    if (camelItems.length !== snakeItems.length ||
        camelItems.some((value, index) => value !== snakeItems[index])) {
      throw new Error(`${name} aliases conflict`);
    }
  }
  return camelProvided ? camelValue : snakeProvided ? snakeValue : [];
}

function resolveBatchOperationEvidence({
  amounts = [],
  expectedRecipientHash,
  expected_recipient_hash,
  expectedRecipientHashes,
  expected_recipient_hashes,
  expectedAmountHashes,
  expected_amount_hashes
} = {}) {
  const recipientHashScalarProvided = operationEvidenceAliasProvided(
    expectedRecipientHash,
    expected_recipient_hash
  );
  const recipientHashArrayProvided = operationEvidenceAliasProvided(
    expectedRecipientHashes,
    expected_recipient_hashes
  );
  const amountHashArrayProvided = operationEvidenceAliasProvided(
    expectedAmountHashes,
    expected_amount_hashes
  );
  const recipientHashScalar = resolveOperationEvidenceAlias(
    expectedRecipientHash,
    expected_recipient_hash,
    "expectedRecipientHash"
  );
  const recipientHashArray = resolveOperationEvidenceArrayAlias(
    expectedRecipientHashes,
    expected_recipient_hashes,
    "expectedRecipientHashes"
  );
  const amountHashArray = resolveOperationEvidenceArrayAlias(
    expectedAmountHashes,
    expected_amount_hashes,
    "expectedAmountHashes"
  );
  const evidenceProvided = recipientHashScalarProvided ||
    recipientHashArrayProvided || amountHashArrayProvided;
  if (!evidenceProvided) {
    return {
      enabled: false,
      recipientHashes: [],
      amountHashes: []
    };
  }
  if (recipientHashArrayProvided && recipientHashArray.length !== amounts.length) {
    throw new Error("expectedRecipientHashes length must match batch amounts length");
  }
  if (amountHashArray.length !== amounts.length) {
    throw new Error("expectedAmountHashes length must match batch amounts length when batch operation evidence is provided");
  }
  const recipientHashes = amounts.map((_, index) =>
    String(recipientHashArray[index] || recipientHashScalar || "").trim()
  );
  const amountHashes = amounts.map((_, index) => String(amountHashArray[index] || "").trim());
  const missingRecipientIndex = recipientHashes.findIndex(value => !value);
  if (missingRecipientIndex >= 0) {
    throw new Error(`expected recipient hash is required for batch item ${missingRecipientIndex}`);
  }
  const missingAmountIndex = amountHashes.findIndex(value => !value);
  if (missingAmountIndex >= 0) {
    throw new Error(`expected amount hash is required for batch item ${missingAmountIndex}`);
  }
  return {
    enabled: true,
    recipientHashes,
    amountHashes
  };
}

function withdrawProofReadyMetadata(built, context = {}) {
  const expiresAtUnix = String(
    built?.payload?.expires_at_unix ||
    built?.payload?.expiresAtUnix ||
    built?.proverPayload?.expires_at_unix ||
    built?.proverPayload?.expiresAtUnix ||
    ""
  );
  return {
    payloadHash: built?.payload?.payload_hash || built?.proverPayload?.payload_hash || "",
    signDocHash: context.signDocHash ?? context.sign_doc_hash ?? "",
    expectedOutputCommitment: "",
    expectedDisclosureDigest: "",
    metadata: expiresAtUnix ? { payload_expires_at_unix: expiresAtUnix } : {}
  };
}

async function markReservationProofReady(reservationManager, batch, metadata) {
  if (!reservationManager || !batch?.reservation_ids?.length) return [];
  if (typeof reservationManager.markProofReady !== "function") {
    throw new Error("reservationManager.markProofReady is required");
  }
  const reservations = await reservationManager.markProofReady(batch.reservation_ids, {
    ...metadata,
    leaseToken: batch.lease_token || batch.reservations?.[0]?.lease_token || ""
  });
  batch.reservations = reservations;
  batch.lease_until = reservations[0]?.lease_until || batch.lease_until;
  return reservations;
}

async function reservationIDsForNotes(reservationManager, batch, notes) {
  if (!reservationManager || !batch?.reservation_ids?.length) return [];
  if (typeof reservationManager.lookupKeyForNote !== "function") {
    throw new Error("reservationManager.lookupKeyForNote is required");
  }
  const lookupKeys = new Set();
  for (const note of notes || []) {
    lookupKeys.add(await reservationManager.lookupKeyForNote(note));
  }
  const reservationIDs = (batch.reservations || [])
    .filter(reservation => lookupKeys.has(reservation.nullifier_lookup_key))
    .map(reservation => reservation.reservation_id);
  return reservationIDs;
}

function mergeBatchReservations(batch, updated) {
  const updatedByID = new Map(updated.map(reservation => [reservation.reservation_id, reservation]));
  batch.reservations = (batch.reservations || []).map(reservation =>
    updatedByID.get(reservation.reservation_id) || reservation
  );
  batch.lease_until = updated[0]?.lease_until || batch.lease_until;
}

async function markReservationProofReadyForNotes(reservationManager, batch, notes, metadata) {
  const reservationIDs = await reservationIDsForNotes(reservationManager, batch, notes);
  if (!reservationIDs.length) return [];
  const updated = await reservationManager.markProofReady(reservationIDs, {
    ...metadata,
    leaseToken: batch.lease_token || batch.reservations?.[0]?.lease_token || ""
  });
  mergeBatchReservations(batch, updated);
  return updated;
}

async function markReservationProofReadyForBatchItems(reservationManager, batch, items) {
  if (!reservationManager || !batch?.reservation_ids?.length) return [];
  if (typeof reservationManager.markProofReadyBatch !== "function") {
    throw new Error("reservationManager.markProofReadyBatch is required for atomic batch transfer preparation");
  }
  const entries = [];
  for (const item of items || []) {
    const reservationIDs = await reservationIDsForNotes(reservationManager, batch, item?.notes);
    if (!reservationIDs.length) continue;
    entries.push({
      reservationIDs,
      metadata: {
        ...(item?.metadata || {}),
        leaseToken: batch.lease_token || batch.reservations?.[0]?.lease_token || ""
      }
    });
  }
  if (!entries.length) return [];
  const updated = await reservationManager.markProofReadyBatch(entries);
  mergeBatchReservations(batch, updated);
  return updated;
}

async function replanProofReadyReservations(reservationManager, batch, error, reason) {
  if (!reservationManager || !batch?.reservation_ids?.length) return [];
  if (typeof reservationManager.getReservation !== "function" || typeof reservationManager.markReplanRequired !== "function") {
    return [];
  }
  const proofReadyIDs = [];
  for (const reservationID of batch.reservation_ids || []) {
    try {
      const reservation = await reservationManager.getReservation(reservationID);
      if (reservation.status === reservationStatuses.ProofReady) {
        proofReadyIDs.push(reservationID);
      }
    } catch (_) {
      // Best-effort cleanup should not hide the original prepare failure.
    }
  }
  if (!proofReadyIDs.length) return [];
  return reservationManager.markReplanRequired(proofReadyIDs, {
    leaseToken: batch.lease_token || batch.reservations?.[0]?.lease_token || "",
    error: reason,
    metadata: {
      reconcile_reason: reason,
      no_broadcast_attempt: true,
      proof_discarded: true
    }
  });
}

async function renewReservationLease(reservationManager, batch) {
  if (!reservationManager || !batch?.reservation_ids?.length) return [];
  if (typeof reservationManager.renewLease !== "function") return [];
  const reservations = await reservationManager.renewLease(batch.reservation_ids, {
    leaseToken: batch.lease_token || batch.reservations?.[0]?.lease_token || ""
  });
  batch.reservations = reservations;
  batch.lease_until = reservations[0]?.lease_until || batch.lease_until;
  return reservations;
}

async function withReservationHeartbeat(reservationManager, batch, task) {
  if (!reservationManager || !batch?.reservation_ids?.length || typeof reservationManager.renewLease !== "function") {
    return task({
      assertHeartbeatHealthy() {},
      async heartbeatNow() {}
    });
  }
  await renewReservationLease(reservationManager, batch);
  const heartbeatIntervalMs = reservationHeartbeatIntervalMs({
    leaseDurationMs: reservationManager.leaseDurationMs,
    leaseUntil: batch.lease_until || batch.reservations?.[0]?.lease_until
  });
  let heartbeatError = null;
  let inFlightHeartbeat = null;
  const heartbeat = async () => {
    if (heartbeatError) return;
    try {
      await renewReservationLease(reservationManager, batch);
    } catch (error) {
      heartbeatError = error;
    }
  };
  const heartbeatNow = async () => {
    if (!inFlightHeartbeat) {
      inFlightHeartbeat = heartbeat().finally(() => {
        inFlightHeartbeat = null;
      });
    }
    await inFlightHeartbeat;
    assertHeartbeatHealthy();
  };
  const assertHeartbeatHealthy = () => {
    if (!heartbeatError) return;
    const error = new Error("note reservation lease heartbeat failed during proof generation");
    error.name = "ReservationHeartbeatError";
    error.cause = heartbeatError;
    throw error;
  };
  const timer = typeof globalThis.setInterval === "function"
    ? globalThis.setInterval(() => { void heartbeatNow().catch(() => {}); }, heartbeatIntervalMs)
    : null;
  let taskCompleted = false;
  let result;
  try {
    result = await task({ assertHeartbeatHealthy, heartbeatNow });
    taskCompleted = true;
  } finally {
    if (timer && typeof globalThis.clearInterval === "function") {
      globalThis.clearInterval(timer);
    }
    if (inFlightHeartbeat) await inFlightHeartbeat;
  }
  if (taskCompleted && heartbeatError) {
    return {
      ...result,
      reservationReconciliationRequired: true,
      reservationReconciliationWarning: {
        code: "reservation_heartbeat_failed_after_proof_ready",
        message: "The prepared artifact is durable, but reservation reconciliation is required before broadcast.",
        cause: heartbeatError?.message || String(heartbeatError)
      }
    };
  }
  return result;
}

function reservationReconciliationFields(result = {}) {
  return result.reservationReconciliationRequired === true
    ? {
        reservationReconciliationRequired: true,
        reservationReconciliationWarning: result.reservationReconciliationWarning
      }
    : {};
}

export class ClairveilJS {
  constructor({
    rpc,
    rest,
    restEndpoints,
    chainId,
    accountPrefix,
    bech32Prefix,
    shieldedPrefix,
    defaultDenom = defaultAssetDenom,
    assetDenom,
    registry = createClairveilRegistry(),
    queryTimeoutMs = defaultFetchTimeoutMs,
    fetchTimeoutMs,
    queryRetry,
    nullifierFailover = false,
    merklePathFailover = false,
    expectedCircuitIdentity,
    enableExperimentalBatchTransfer = false,
    enable_experimental_batch_transfer
  } = {}) {
    this.rpc = normalizeRpcEndpoint(rpc);
    this.restEndpoints = normalizeRestEndpoints(rest, restEndpoints);
    this.rest = this.restEndpoints[0];
    this.activeRestEndpoint = this.rest;
    this.chainId = chainId;
    this.accountPrefix = normalizeBech32Prefix(accountPrefix ?? bech32Prefix ?? defaultAccountPrefix, "accountPrefix");
    this.bech32Prefix = this.accountPrefix;
    this.shieldedPrefix = normalizeBech32Prefix(shieldedPrefix ?? `${this.accountPrefix}s`, "shieldedPrefix");
    this.defaultDenom = String(assetDenom ?? defaultDenom ?? defaultAssetDenom);
    this.registry = registry;
    this.queryTimeoutMs = normalizeTimeoutMs(fetchTimeoutMs ?? queryTimeoutMs, "queryTimeoutMs");
    this.queryRetry = normalizeQueryRetry(queryRetry);
    this.nullifierFailover = Boolean(nullifierFailover);
    this.merklePathFailover = Boolean(merklePathFailover);
    this.enableExperimentalBatchTransfer = Boolean(
      enable_experimental_batch_transfer ?? enableExperimentalBatchTransfer
    );
    this.expectedCircuitIdentity = expectedCircuitIdentity == null
      ? null
      : validateExpectedCircuitIdentityV1(expectedCircuitIdentity);
    this.clientPromise = null;
  }

  async connect() {
    if (!this.clientPromise) {
      this.clientPromise = StargateClient.connect(this.rpc);
    }
    return this.clientPromise;
  }

  async disconnect() {
    if (!this.clientPromise) return;
    const client = await this.clientPromise;
    client.disconnect();
    this.clientPromise = null;
  }

  restUrl(path, endpoint = this.activeRestEndpoint) {
    return `${endpoint}${path}`;
  }

  async fetchJson(pathOrUrl, {
    failover = false,
    retry = this.queryRetry,
    method,
    body,
    headers,
    endpoint,
    updateActiveEndpoint = endpoint == null
  } = {}) {
    const text = String(pathOrUrl || "");
    const isAbsolute = /^https?:\/\//i.test(text);
    if (isAbsolute) {
      const result = await fetchJsonWithRetry(
        url => url,
        [text],
        {
          timeoutMs: this.queryTimeoutMs,
          retry,
          method,
          body,
          headers
        }
      );
      return result.data;
    }
    const path = text;
    const initialEndpoint = endpoint || this.activeRestEndpoint;
    const endpoints = failover
      ? [initialEndpoint, ...this.restEndpoints.filter(candidate => candidate !== initialEndpoint)]
      : [initialEndpoint];
    const result = await fetchJsonWithRetry(
      endpoint => this.restUrl(path, endpoint),
      endpoints,
      {
        timeoutMs: this.queryTimeoutMs,
        retry,
        method,
        body,
        headers
      }
    );
    if (updateActiveEndpoint) this.activeRestEndpoint = result.endpoint;
    return result.data;
  }

  async fetchNullifierJson(path, options = {}) {
    return this.fetchJson(path, {
      ...options,
      failover: this.nullifierFailover,
      // Normal queries may fail over. Sensitive nullifier queries stay on the
      // configured endpoint unless the caller explicitly opted into failover.
      ...(this.nullifierFailover ? {} : {
        endpoint: this.rest,
        updateActiveEndpoint: false
      })
    });
  }

  async fetchMerklePathJson(path, options = {}) {
    return this.fetchJson(path, {
      ...options,
      failover: this.merklePathFailover,
      // Merkle witnesses reveal the commitments a wallet is attempting to
      // spend. Keep those requests on the configured endpoint unless the
      // application explicitly accepts cross-endpoint disclosure.
      ...(this.merklePathFailover ? {} : {
        endpoint: this.rest,
        updateActiveEndpoint: false
      })
    });
  }

  async getAccountInfo(address) {
    const data = await this.fetchJson(`/cosmos/auth/v1beta1/accounts/${address}`, { failover: true });
    const info = unwrapBaseAccount(data.account ?? data.info);
    if (info?.account_number == null || info.sequence == null) {
      throw new Error("account not found on-chain; fund it first");
    }
    return {
      accountNumber: BigInt(info.account_number),
      sequence: BigInt(info.sequence)
    };
  }

  async getBalances(address) {
    const client = await this.connect();
    const balances = await client.getAllBalances(address);
    return {
      balances: balances.map(balance => ({ denom: balance.denom, amount: balance.amount })),
      pagination: null
    };
  }

  async getTx(txHash) {
    const client = await this.connect();
    return indexedTxToRestish(await client.getTx(txHash));
  }

  async waitForTx(txHash, { attempts = 20, intervalMs = 1500 } = {}) {
    for (let i = 0; i < attempts; i += 1) {
      const tx = await this.getTx(txHash);
      if (tx) return tx;
      await new Promise(resolve => setTimeout(resolve, intervalMs));
    }
    return null;
  }

  async fetchPrivacyEvents(options = {}) {
    return this.fetchJson(`/clairveil/privacy/v1/events${privacyEventsQuery(options)}`, { failover: true });
  }

  async fetchScanEvents(options = {}) {
    const data = await this.fetchJson(`/clairveil/privacy/v1/scan_events${scanEventsQuery(options)}`, { failover: true });
    assertScanEventsVersions(data);
    return data;
  }

  async fetchPrivacyScan(options = {}) {
    return this.fetchJson("/clairveil/privacy/v1/privacy_scan", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: jsonRequestBody(privacyScanRequestBody(options)),
      failover: true
    });
  }

  /** Fetch a typed privacy-scan-v2 page and fail closed before it is consumed. */
  async queryPrivacyScan(options = {}) {
    const {
      validationState,
      validation_state,
      ...request
    } = options || {};
    return validatePrivacyScanPageV2(
      await this.fetchPrivacyScan(request),
      {
        ...request,
        ...(validationState ?? validation_state
          ? { validationState: validationState ?? validation_state }
          : {})
      }
    );
  }

  async fetchTreeState() {
    return this.fetchJson("/clairveil/privacy/v1/tree_state", { failover: true });
  }

  async fetchCommitmentInfo(commitmentHex) {
    return this.fetchJson(`/clairveil/privacy/v1/commitment/${commitmentHex}`, { failover: true });
  }

  async lookupMerklePath(commitmentHex) {
    return this.fetchMerklePathJson(`/clairveil/privacy/v1/merkle_path/${commitmentHex}`);
  }

  async fetchAuditConfig() {
    return this.fetchJson("/clairveil/privacy/v1/audit_config", { failover: true });
  }

  async fetchDisclosureConfig() {
    return this.fetchJson("/clairveil/privacy/v1/disclosure_config", { failover: true });
  }

  /** Fetch and fail-closed validate the active audit recipient identity. */
  async queryAuditConfig() {
    return normalizeAuditConfigV1(await this.fetchAuditConfig());
  }

  /** Fetch and fail-closed validate disclosure policy/mode compatibility. */
  async queryDisclosureConfig() {
    return normalizeDisclosureConfigV1(await this.fetchDisclosureConfig());
  }

  async fetchCircuitConfig({ expectedCircuitIdentity } = {}) {
    return validateCircuitConfigV1(
      await this.fetchJson("/clairveil/privacy/v1/circuit_config", { failover: true }),
      { expectedCircuitIdentity: expectedCircuitIdentity ?? this.expectedCircuitIdentity ?? undefined }
    );
  }

  /** Fetch and fail-closed validate the consensus identity used by every proof circuit. */
  async assertCircuitConfig(options) {
    return this.fetchCircuitConfig(options);
  }

  async fetchReserve(denom) {
    const normalizedDenom = String(denom || "").trim();
    if (!normalizedDenom) {
      throw new Error("reserve denom is required");
    }
    return this.fetchJson(`/clairveil/privacy/v1/reserve/${encodeURIComponent(normalizedDenom)}`, { failover: true });
  }

  /** Fetch and independently check reserve accounting before relying on it. */
  async queryReserve(denom) {
    const canonicalDenom = canonicalAssetDenomV1(denom);
    return normalizeReserveResponseV1(await this.fetchReserve(canonicalDenom), canonicalDenom);
  }

  async fetchAssetByDenom(denom) {
    const canonicalDenom = String(denom || "").trim();
    if (!canonicalDenom) throw new Error("asset denom is required");
    return this.fetchJson(
      `/clairveil/privacy/v1/assets/by_denom/${encodeURIComponent(canonicalDenom)}`,
      { failover: true }
    );
  }

  async fetchAssetByID(assetIdHex) {
    const canonicalAssetID = String(assetIdHex || "").trim();
    if (!canonicalAssetID) throw new Error("asset ID is required");
    return this.fetchJson(
      `/clairveil/privacy/v1/assets/by_id/${encodeURIComponent(canonicalAssetID)}`,
      { failover: true }
    );
  }

  /** Fetch and fail-closed validate an AssetRegistryV1 denom lookup. */
  async queryAssetByDenom(denom) {
    const canonicalDenom = canonicalAssetDenomV1(denom);
    return normalizeAssetRegistryQueryResponseV1(
      await this.fetchAssetByDenom(canonicalDenom),
      { canonical_denom: canonicalDenom }
    );
  }

  /** Fetch and fail-closed validate an AssetRegistryV1 reverse lookup. */
  async queryAssetByID(assetIdHex) {
    const canonicalAssetID = canonicalAssetIDHexV1(assetIdHex);
    return normalizeAssetRegistryQueryResponseV1(
      await this.fetchAssetByID(canonicalAssetID),
      { asset_id_hex: canonicalAssetID }
    );
  }

  /** Resolver shape consumed by one-proof payroll preparation. */
  async resolveAsset(denom) {
    return (await this.queryAssetByDenom(denom)).asset;
  }

  async resolveAssetByDenom(denom) {
    return this.resolveAsset(denom);
  }

  async resolveAssetByID(assetIdHex) {
    return (await this.queryAssetByID(assetIdHex)).asset;
  }

  /**
   * Fail closed before a proof is requested: the active consensus circuit set
   * and the authoritative denom/asset mapping must agree with this SDK.
   */
  async assertProtocolPreflight(denom) {
    const canonicalDenom = canonicalAssetDenomV1(denom);
    const [circuitConfig, asset] = await Promise.all([
      this.assertCircuitConfig(),
      this.resolveAsset(canonicalDenom)
    ]);
    return Object.freeze({ circuit_config: circuitConfig, asset });
  }

  /**
   * Bind a transfer operation to the active circuit/asset and typed
   * audit/disclosure configuration. Reserve accounting is exposed separately
   * through queryReserve because its value changes with operations.
   */
  async assertTransferProtocolConfig(denom) {
    const canonicalDenom = canonicalAssetDenomV1(denom);
    const [preflight, auditConfig, disclosureConfig] = await Promise.all([
      this.assertProtocolPreflight(canonicalDenom),
      this.queryAuditConfig(),
      this.queryDisclosureConfig()
    ]);
    return Object.freeze({
      ...preflight,
      audit_config: auditConfig,
      disclosure_config: disclosureConfig
    });
  }

  async fetchCommitmentPathsAtRoot(options = {}) {
    return this.fetchMerklePathJson("/clairveil/privacy/v1/commitment_paths_at_root", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: jsonRequestBody(commitmentPathsAtRootRequestBody(options))
    });
  }

  /** Fetch, validate, and root-recompute a single exact-root, optionally height-pinned Merkle snapshot. */
  async queryCommitmentPathsAtRoot(options = {}) {
    const request = normalizeCommitmentPathsAtRootRequest(options);
    const response = await this.fetchCommitmentPathsAtRoot(request);
    return normalizeCommitmentPathsAtRootResponse(response, request);
  }

  /** Build a lookupMerklePath provider pinned to one verified root/height snapshot. */
  async createCommitmentPathSnapshotProvider(options = {}) {
    return createCommitmentPathSnapshotProvider(await this.queryCommitmentPathsAtRoot(options));
  }

  /**
   * Build the default witness provider for a native 2x2 transfer. Both
   * selected commitments are resolved through one verified exact-root
   * snapshot rather than two mutable merkle_path reads.
   */
  async createTransferMerklePathSnapshotProvider(inputs) {
    if (!Array.isArray(inputs) || inputs.length !== 2) return this;
    const commitmentHexes = inputs.map(found => fieldHexV1(computeNoteCommitmentV1(found?.note)));
    const treeState = await this.fetchTreeState();
    const rootHex = String(treeState?.root ?? treeState?.root_hex ?? treeState?.rootHex ?? "").trim();
    if (!rootHex) throw new Error("transfer requires a verified current tree root");
    return this.createCommitmentPathSnapshotProvider({ commitmentHexes, rootHex });
  }

  async checkNullifier(nullifierHex) {
    return this.fetchNullifierJson(`/clairveil/privacy/v1/nullifier/${nullifierHex}`);
  }

  async checkNullifiers(nullifierHexes = []) {
    const normalized = [...new Set((nullifierHexes || []).map(value => String(value || "").trim().toLowerCase()).filter(Boolean))];
    const usedByNullifier = new Map();
    const invalidNullifiers = new Set();
    const addStatus = (nullifier, value) => {
      const key = String(nullifier || "").trim().toLowerCase();
      if (!key || invalidNullifiers.has(key)) return;
      const used = parseNullifierUsage(value);
      if (used === null || (usedByNullifier.has(key) && usedByNullifier.get(key) !== used)) {
        usedByNullifier.delete(key);
        invalidNullifiers.add(key);
        return;
      }
      usedByNullifier.set(key, used);
    };
    const chunkSize = 1000;
    for (let start = 0; start < normalized.length; start += chunkSize) {
      const chunk = normalized.slice(start, start + chunkSize);
      const response = await this.fetchNullifierJson("/clairveil/privacy/v1/nullifiers", {
        method: "POST",
        body: JSON.stringify({ nullifiers: chunk })
      });
      for (const status of response?.statuses || response?.Statuses || []) {
        const canonical = status?.nullifier;
        const alias = status?.Nullifier;
        if (canonical != null && alias != null &&
            String(canonical).trim().toLowerCase() !== String(alias).trim().toLowerCase()) {
          addStatus(canonical, null);
          addStatus(alias, null);
        } else {
          addStatus(canonical ?? alias, status);
        }
      }
    }
    return usedByNullifier;
  }

  async deriveWalletPrivacyMaterial(wallet) {
    return derivePrivacyMaterialFromWallet(wallet, {
      shieldedPrefix: this.shieldedPrefix
    });
  }

  async scanNotes({
    rootSeed,
    after,
    afterHeight,
    after_height,
    afterSequence,
    after_sequence,
    page = 1,
    limit = 200,
    maxPages = 1,
    outputLimit,
    output_limit,
    eventLimit,
    event_limit,
    maxEncodedBytes,
    max_encoded_bytes,
    validationStateSnapshot,
    validation_state_snapshot,
    eventTypes,
    event_types,
    includeFoundNotes = false,
    scanSource,
    scan_source
  } = {}) {
    const requestedEventTypes = event_types ?? eventTypes;
    const resolvedEventTypes = requestedEventTypes ?? ["deposit", "shielded_transfer"];
    const pageLimit = Math.max(1, Number(limit || 200));
    const pageBudget = Math.max(1, Number(maxPages || 1));
    // `privacy_scan` intentionally rejects event filters so its cursor proves
    // progress across zero-output events. Preserve the prior filtered
    // ScanEvents contract unless the caller explicitly selected a source.
    const source = scan_source ?? scanSource ?? (
      Array.isArray(requestedEventTypes) && requestedEventTypes.some(value => String(value || "").trim())
        ? "scan_events"
        : "privacy_scan"
    );
    if (source !== "privacy_scan" && resolvedEventTypes.some(value => String(value || "").trim() === "batch_transfer")) {
      throw new Error("batch_transfer outputs require the typed privacy-scan-v2 source");
    }

    if (source === "privacy_scan") {
      if ((event_types ?? eventTypes) != null && (event_types ?? eventTypes).some(value => String(value || "").trim())) {
        throw new Error("unified privacy scan must not filter event types; zero-output summaries are required for safe cursor advancement");
      }
      const legacyHeight = afterHeight ?? after_height;
      const requestedAfter = after ?? (legacyHeight == null
        ? { height: 0, globalSequence: 0, outputIndex: 0 }
        // The legacy cursors cannot prove an exact typed-output position.
        // Rewind a height and deduplicate locally rather than skipping a
        // partial typed event during migration.
        : { height: decrementUint64Cursor(legacyHeight, "unified scan migration height"), globalSequence: 0, outputIndex: 0 });
      const initialAfter = validatePrivacyScanPageV2({
        scanSchemaVersion: "privacy-scan-v2",
        summaries: [],
        outputs: [],
        nextCursor: requestedAfter,
        hasMore: false
      }, { after: requestedAfter }).next_cursor;
      let currentAfter = {
        height: initialAfter.height,
        globalSequence: initialAfter.global_sequence,
        outputIndex: initialAfter.output_index
      };
      let pagesScanned = 0;
      let scannedEvents = 0;
      let hasMore = false;
      let found = [];
      const requestedValidationState = validationStateSnapshot ?? validation_state_snapshot;
      const validationState = requestedValidationState == null
        ? createPrivacyScanValidationStateV2()
        : restorePrivacyScanValidationStateV2(requestedValidationState);
      try {
        for (; pagesScanned < pageBudget;) {
          const request = {
            after: currentAfter,
            outputLimit: outputLimit ?? output_limit ?? pageLimit,
            eventLimit: eventLimit ?? event_limit,
            maxEncodedBytes: maxEncodedBytes ?? max_encoded_bytes,
            // Deliberately request every event: zero-output summaries prove
            // cursor progress across withdraws and filtered wallet outputs.
            eventTypes: []
          };
          const pageResult = await this.queryPrivacyScan({ ...request, validationState });
          found.push(...processPrivacyScanPageV2(pageResult, { rootSeed }));
          currentAfter = {
            height: pageResult.next_cursor.height,
            globalSequence: pageResult.next_cursor.global_sequence,
            outputIndex: pageResult.next_cursor.output_index
          };
          scannedEvents += pageResult.scanned_event_count;
          pagesScanned += 1;
          hasMore = pageResult.has_more;
          if (!hasMore) break;
        }
      } catch (error) {
        const canFallback = error?.status === 404 || error?.status === 405 || error?.status === 501 || error?.code === "UNSUPPORTED_PRIVACY_SCAN_VERSION";
        if (!canFallback) throw error;
        if (this.enableExperimentalBatchTransfer) {
          throw new Error("typed privacy-scan-v2 is required while one-proof batch transfer support is enabled", { cause: error });
        }
        // Only an absent typed endpoint may fall back. A malformed or failed
        // privacy-scan-v2 response is terminal because it may contain batch
        // ciphertexts unavailable from a legacy feed.
        return this.scanNotes({
          rootSeed,
          afterHeight: decrementUint64Cursor(initialAfter.height ?? 0, "unified scan fallback height"),
          afterSequence: 0,
          page: 1,
          limit: pageLimit,
          maxPages: pageBudget,
          eventTypes: resolvedEventTypes,
          includeFoundNotes,
          scanSource: "scan_events"
        });
      }
      const result = await scanNotesCore({
        rootSeed,
        preprocessedFoundNotes: found,
        checkNullifiers: nullifiers => this.checkNullifiers(nullifiers),
        checkNullifier: nullifierHex => this.checkNullifier(nullifierHex),
        includeFoundNotes
      });
      const cursor = {
        source: "privacy_scan",
        after: initialAfter,
        output_limit: Number(outputLimit ?? output_limit ?? pageLimit),
        event_limit: eventLimit ?? event_limit ?? 0,
        max_encoded_bytes: maxEncodedBytes ?? max_encoded_bytes ?? 0,
        event_types: [],
        has_more: hasMore,
        next_cursor: {
          height: currentAfter.height,
          global_sequence: currentAfter.globalSequence,
          output_index: currentAfter.outputIndex
        },
        latest_height: currentAfter.height,
        latest_sequence: currentAfter.globalSequence,
        latest_output_index: currentAfter.outputIndex,
        pages_scanned: pagesScanned,
        completed: !hasMore,
        ...(validationState.batch_self_view_by_event.size
          ? { validation_state: serializePrivacyScanValidationStateV2(validationState) }
          : {})
      };
      return {
        ...result,
        diagnostics: {
          ...result.diagnostics,
          scanned_events: scannedEvents,
          pages_scanned: pagesScanned,
          max_pages: pageBudget
        },
        scanCursor: cursor,
        nextScanOptions: nextPrivacyScanOptions(cursor, {
          maxPages: pageBudget,
          includeFoundNotes
        })
      };
    }

    let legacyAfterHeight = afterHeight;
    let legacyAfterHeightAlias = after_height;
    let legacyPage = page;
    if (source !== "privacy_events") {
      const startAfterHeight = uint64CursorValue(afterHeight ?? after_height ?? 0, "scan after height");
      const startAfterSequence = uint64CursorValue(afterSequence ?? after_sequence ?? 0, "scan after sequence");
      const events = [];
      let currentAfterHeight = startAfterHeight;
      let currentAfterSequence = startAfterSequence;
      let pagesScanned = 0;
      let hasMore = false;
      let lastData = null;
      try {
        for (; pagesScanned < pageBudget;) {
          const request = {
            afterHeight: currentAfterHeight,
            afterSequence: currentAfterSequence,
            limit: pageLimit,
            eventTypes: resolvedEventTypes
          };
          const data = await this.fetchScanEvents(request);
          lastData = data;
          events.push(...(data.events || []));
          pagesScanned += 1;
          hasMore = Boolean(data.has_more ?? data.hasMore);
          const nextHeight = uint64CursorValue(data.next_height ?? data.nextHeight ?? currentAfterHeight, "scan next height");
          const nextSequence = uint64CursorValue(data.next_sequence ?? data.nextSequence ?? currentAfterSequence, "scan next sequence");
          if (
            hasMore &&
            compareUint64Cursor(nextHeight, currentAfterHeight, "scan height") === 0 &&
            compareUint64Cursor(nextSequence, currentAfterSequence, "scan sequence") === 0
          ) {
            throw new Error("scan events cursor did not advance");
          }
          currentAfterHeight = nextHeight;
          currentAfterSequence = nextSequence;
          if (!hasMore) break;
        }

        const result = await scanNotesCore({
          rootSeed,
          events,
          checkNullifiers: nullifiers => this.checkNullifiers(nullifiers),
          checkNullifier: nullifierHex => this.checkNullifier(nullifierHex),
          includeFoundNotes
        });
        const cursor = scanEventsCursor(lastData || {
          events,
          limit: pageLimit,
          has_more: hasMore,
          next_height: currentAfterHeight,
          next_sequence: currentAfterSequence,
          scan_format_version: 1,
          view_tag_version: 1
        }, {
          afterHeight: startAfterHeight,
          afterSequence: startAfterSequence,
          limit: pageLimit,
          eventTypes: resolvedEventTypes
        });
        return {
          ...result,
          diagnostics: {
            ...result.diagnostics,
            pages_scanned: pagesScanned,
            max_pages: pageBudget
          },
          scanCursor: {
            ...cursor,
            pages_scanned: pagesScanned,
            completed: !hasMore
          },
          nextScanOptions: nextPrivacyScanOptions({
            ...cursor,
            pages_scanned: pagesScanned,
            completed: !hasMore
          }, {
            maxPages: pageBudget,
            includeFoundNotes,
            eventTypes: resolvedEventTypes
          })
        };
      } catch (error) {
        const canFallback = error?.status === 404 || error?.status === 501 || error?.status === 503 || error?.code === "UNSUPPORTED_SCAN_EVENTS_VERSION";
        if (!canFallback) throw error;
        // The legacy endpoint begins at after_height + 1 and has no sequence
        // cursor. Rewind one block so a mid-block scan_events cursor cannot
        // skip the remaining events at that height.
        const rewindHeight = decrementUint64Cursor(startAfterHeight, "scan fallback height");
        legacyAfterHeight = rewindHeight;
        legacyAfterHeightAlias = rewindHeight;
        legacyPage = 1;
      }
    }

    const startPage = Math.max(1, Number(legacyPage || 1));
    const baseRequest = {
      afterHeight: legacyAfterHeight,
      after_height: legacyAfterHeightAlias,
      limit: pageLimit,
      eventTypes: resolvedEventTypes
    };
    const events = [];
    let currentPage = startPage;
    let pagesScanned = 0;
    let hasMore = false;
    let lastData = null;

    for (; pagesScanned < pageBudget;) {
      const request = { ...baseRequest, page: currentPage };
      const data = await this.fetchPrivacyEvents(request);
      lastData = data;
      events.push(...(data.events || []));
      pagesScanned += 1;
      hasMore = Boolean(data.has_more);
      if (!hasMore) break;
      currentPage = Number(data.page || currentPage) + 1;
    }

    const result = await scanNotesCore({
      rootSeed,
      events,
      checkNullifiers: nullifiers => this.checkNullifiers(nullifiers),
      checkNullifier: nullifierHex => this.checkNullifier(nullifierHex),
      includeFoundNotes
    });
    const cursor = privacyEventsCursor({
      ...(lastData || {}),
      events,
      has_more: hasMore
    }, { ...baseRequest, page: lastData?.page ?? currentPage });
    return {
      ...result,
      diagnostics: {
        ...result.diagnostics,
        pages_scanned: pagesScanned,
        max_pages: pageBudget
      },
      scanCursor: {
        ...cursor,
        pages_scanned: pagesScanned,
        next_page: hasMore ? currentPage : 1,
        completed: !hasMore
      },
      nextScanOptions: nextPrivacyScanOptions({
        ...cursor,
        pages_scanned: pagesScanned,
        next_page: hasMore ? currentPage : 1,
        completed: !hasMore
      }, {
        maxPages: pageBudget,
        includeFoundNotes,
        eventTypes: resolvedEventTypes
      })
    };
  }

  async fetchAuditableTransfers(options = {}) {
    const data = await this.fetchPrivacyEvents(options);
    return {
      ...data,
      events: (data.events || []).filter(isAuditableTransfer)
    };
  }

  async fetchAuditableBatchTransfers(options = {}) {
    const requestedTypes = options.eventTypes ?? options.event_types;
    if (requestedTypes != null && (
      !Array.isArray(requestedTypes) ||
      requestedTypes.some(value => String(value || "").trim() !== "batch_transfer")
    )) {
      throw new Error("auditable batch transfer query only accepts the batch_transfer event type");
    }
    const request = { ...options, eventTypes: ["batch_transfer"] };
    delete request.event_types;
    // Preserve the existing auditable query request shape, including the
    // caller-owned validation state used by downstream pagination adapters.
    const page = validatePrivacyScanPageV2(
      await this.fetchPrivacyScan(request),
      request
    );
    if (page.summaries.some(summary => summary.event_type !== "batch_transfer") ||
        page.outputs.some(output => output.event_type !== "batch_transfer")) {
      throw new Error("auditable batch transfer response contains a non-batch event");
    }
    return page;
  }

  async findPrivacyEventByTxHash(txHash, {
    afterHeight,
    after_height,
    afterSequence,
    after_sequence,
    page = 1,
    limit = 200,
    maxPages = defaultPrepareScanMaxPages,
    max_pages,
    eventTypes = ["shielded_transfer"],
    event_types,
    scanSource,
    scan_source
  } = {}) {
    const normalizedTxHash = String(txHash || "").trim().toUpperCase();
    if (!normalizedTxHash) {
      throw new Error("txHash is required");
    }
    const pageBudget = Math.max(1, Number(max_pages ?? maxPages ?? defaultPrepareScanMaxPages));
    const pageLimit = Math.max(1, Number(limit || 200));
    const resolvedEventTypes = event_types ?? eventTypes;
    const source = scan_source ?? scanSource ?? "privacy_events";
    if (source !== "privacy_events") {
      let currentAfterHeight = uint64CursorValue(afterHeight ?? after_height ?? 0, "event lookup after height");
      let currentAfterSequence = uint64CursorValue(afterSequence ?? after_sequence ?? 0, "event lookup after sequence");
      for (let pagesScanned = 0; pagesScanned < pageBudget; pagesScanned += 1) {
        const data = await this.fetchScanEvents({
          afterHeight: currentAfterHeight,
          afterSequence: currentAfterSequence,
          limit: pageLimit,
          eventTypes: resolvedEventTypes
        });
        const event = (data.events || []).find(item =>
          String(item.tx_hash_hex || "").toUpperCase() === normalizedTxHash
        );
        if (event) return event;
        if (!Boolean(data.has_more ?? data.hasMore)) break;
        const nextHeight = uint64CursorValue(data.next_height ?? data.nextHeight ?? currentAfterHeight, "event lookup next height");
        const nextSequence = uint64CursorValue(data.next_sequence ?? data.nextSequence ?? currentAfterSequence, "event lookup next sequence");
        if (
          compareUint64Cursor(nextHeight, currentAfterHeight, "event lookup height") === 0 &&
          compareUint64Cursor(nextSequence, currentAfterSequence, "event lookup sequence") === 0
        ) {
          throw new Error("scan events cursor did not advance");
        }
        currentAfterHeight = nextHeight;
        currentAfterSequence = nextSequence;
      }
      throw new Error(`transfer event not found for tx ${normalizedTxHash}`);
    }
    let currentPage = Math.max(1, Number(page || 1));

    for (let pagesScanned = 0; pagesScanned < pageBudget; pagesScanned += 1) {
      const data = await this.fetchPrivacyEvents({
        afterHeight,
        after_height,
        page: currentPage,
        limit: pageLimit,
        eventTypes: resolvedEventTypes
      });
      const event = (data.events || []).find(item => String(item.tx_hash_hex || "").toUpperCase() === normalizedTxHash);
      if (event) {
        return event;
      }
      if (!data.has_more) break;
      currentPage = Number(data.page || currentPage) + 1;
    }
    throw new Error(`transfer event not found for tx ${normalizedTxHash}`);
  }

  derivePrivacyAccount({ address, pubKeyHex, pub_key_hex, signatureBase64, signature_base64 }) {
    const material = derivePrivacyMaterial({
      address,
      pubKeyHex: pubKeyHex ?? pub_key_hex,
      signatureBase64: signatureBase64 ?? signature_base64,
      shieldedPrefix: this.shieldedPrefix
    });
    return {
      signing_message: material.signingMessage,
      shielded_address: material.shieldedAddress,
      disclosure_pubkey_hex: material.disclosurePubKeyHex,
      root_signature_hash: material.rootSignatureHash
    };
  }

  buildDepositMaterial(input) {
    return buildDepositMaterialCore({
      shieldedPrefix: this.shieldedPrefix,
      assetDenom: input?.assetDenom ?? input?.denom ?? this.defaultDenom,
      ...input
    });
  }

  buildDepositMessage(input) {
    const material = input?.depositMaterial ?? input?.deposit_material ?? (
      input?.material?.note_commitment && input?.material?.encrypted_note
        ? input.material
        : buildDepositMaterialCore({
          shieldedPrefix: this.shieldedPrefix,
          assetDenom: input?.assetDenom ?? input?.denom ?? this.defaultDenom,
          ...input
        })
    );
    const expectedCreator = String(input?.creator || "").trim();
    if (expectedCreator && String(material.creator || "").trim() !== expectedCreator) {
      throw new Error(`deposit material creator mismatch: expected ${expectedCreator}, got ${material.creator || ""}`);
    }
    const expectedAmount = input?.amount == null
      ? ""
      : parseCoin(input.amount, input?.assetDenom ?? input?.denom ?? this.defaultDenom).raw;
    if (expectedAmount && String(material.amount || "").trim() !== expectedAmount) {
      throw new Error(`deposit material amount mismatch: expected ${expectedAmount}, got ${material.amount || ""}`);
    }
    const proof = requiredDepositProof(input);
    return {
      material,
      message: {
        creator: material.creator,
        amount: material.amount,
        noteCommitment: material.note_commitment,
        encryptedNote: material.encrypted_note,
        proof
      }
    };
  }

  async scanWalletNotes({
    wallet,
    material,
    after,
    limit = 200,
    maxPages = 1,
    max_pages,
    noteStore,
    includeFoundNotes = false,
    afterHeight,
    after_height,
    afterSequence,
    after_sequence,
    page,
    eventTypes,
    event_types,
    outputLimit,
    output_limit,
    eventLimit,
    event_limit,
    maxEncodedBytes,
    max_encoded_bytes,
    validationStateSnapshot,
    validation_state_snapshot,
    scanSource,
    scan_source
  } = {}) {
    const privacy = material || await this.deriveWalletPrivacyMaterial(wallet);
    let resolvedAfter = after;
    let resolvedAfterHeight = afterHeight ?? after_height;
    let resolvedAfterSequence = afterSequence ?? after_sequence;
    let resolvedPage = page;
    let resolvedScanSource = scan_source ?? scanSource;
    let resolvedValidationStateSnapshot = validationStateSnapshot ?? validation_state_snapshot;
    if (resolvedAfter == null && resolvedAfterHeight == null && noteStore) {
      const cached = await noteStore.load();
      const cachedCursor = cached.scanCursor || {};
      if (cachedCursor.source === "privacy_scan") {
        const next = nextPrivacyScanOptions(cachedCursor, { limit, maxPages });
        const requestedSource = resolvedScanSource;
        const sourceChanged = Boolean(requestedSource && requestedSource !== "privacy_scan");
        if (sourceChanged) {
          resolvedAfterHeight = decrementUint64Cursor(next.after?.height ?? 0, "scan source switch height");
          resolvedAfterSequence = 0;
          resolvedPage = 1;
        } else {
          resolvedAfter = next.after;
          resolvedScanSource = "privacy_scan";
          resolvedValidationStateSnapshot = resolvedValidationStateSnapshot ?? next.validationStateSnapshot;
        }
      } else if (cachedCursor.source === "scan_events" || cachedCursor.source === "privacy_events") {
        const next = nextPrivacyScanOptions(cachedCursor, { limit, maxPages });
        const requestedSource = resolvedScanSource;
        const sourceChanged = Boolean(requestedSource && requestedSource !== cachedCursor.source);
        if (sourceChanged) {
          // ScanEvents resumes after an exact (height, sequence), while the legacy
          // endpoint starts at after_height + 1. Rewind one height when translating
          // either cursor so a source switch may duplicate events but cannot skip one.
          resolvedAfterHeight = decrementUint64Cursor(next.afterHeight ?? 0, "scan source switch height");
          resolvedAfterSequence = 0;
          resolvedPage = 1;
        } else {
          resolvedAfterHeight = next.afterHeight;
          resolvedAfterSequence = next.afterSequence ?? 0;
          resolvedPage = resolvedPage ?? next.page;
          resolvedScanSource = next.scanSource ?? cachedCursor.source;
        }
      } else if (cachedCursor.has_more && (cachedCursor.next_sequence != null || cachedCursor.nextSequence != null)) {
        resolvedAfterHeight = cachedCursor.next_height ?? cachedCursor.nextHeight ?? cached.lastScannedHeight ?? 0;
        resolvedAfterSequence = cachedCursor.next_sequence ?? cachedCursor.nextSequence ?? cached.lastScannedSequence ?? 0;
      } else if (cachedCursor.has_more && (cachedCursor.next_page || cachedCursor.nextPage)) {
        resolvedAfterHeight = cachedCursor.after_height ?? cachedCursor.afterHeight ?? cached.lastScannedHeight ?? 0;
        resolvedAfterSequence = cachedCursor.after_sequence ?? cachedCursor.afterSequence ?? cached.lastScannedSequence ?? 0;
        resolvedPage = resolvedPage ?? cachedCursor.next_page ?? cachedCursor.nextPage;
      } else {
        resolvedAfterHeight = cached.lastScannedHeight || 0;
        resolvedAfterSequence = cached.lastScannedSequence || 0;
      }
    }
    const scan = await this.scanNotes({
      rootSeed: privacy.rootSeed,
      after: resolvedAfter,
      limit,
      maxPages: max_pages ?? maxPages,
      afterHeight: resolvedAfterHeight,
      afterSequence: resolvedAfterSequence,
      page: resolvedPage,
      scanSource: resolvedScanSource,
      eventTypes: event_types ?? eventTypes,
      outputLimit: output_limit ?? outputLimit,
      eventLimit: event_limit ?? eventLimit,
      maxEncodedBytes: max_encoded_bytes ?? maxEncodedBytes,
      validationStateSnapshot: resolvedValidationStateSnapshot,
      includeFoundNotes: true
    });
    if (noteStore) {
      await noteStore.mergeScanResult(scan, { owner: privacy.address });
      await this.refreshNoteStoreSpentStatuses(noteStore);
    }
    if (includeFoundNotes) {
      return {
        ...scan,
        privacyAccount: publicPrivacyAccount(privacy)
      };
    }
    const { foundNotes: _foundNotes, ...safeScan } = scan;
    return {
      ...safeScan,
      privacyAccount: publicPrivacyAccount(privacy)
    };
  }

  async refreshNoteStoreSpentStatuses(noteStore) {
    if (!noteStore) return null;
    let current = await noteStore.load();
    const nullifiers = [];
    for (const note of current.notes || []) {
      const nullifier = String(note?.nullifier || "").trim().toLowerCase();
      if (!nullifier) continue;
      nullifiers.push(nullifier);
    }
    if (!nullifiers.length) return current;
    const nullifierStatuses = new Map();
    try {
      const statuses = await this.checkNullifiers(nullifiers);
      for (const nullifier of nullifiers) {
        if (statuses.has(nullifier)) {
          const used = parseNullifierUsage(statuses.get(nullifier));
          if (used !== null) {
            nullifierStatuses.set(nullifier, used ? "spent" : "unspent");
          }
        }
      }
      const missing = nullifiers.filter(nullifier => !nullifierStatuses.has(nullifier));
      if (!missing.length) {
        return typeof noteStore.setNullifierStatuses === "function"
          ? noteStore.setNullifierStatuses(nullifierStatuses)
          : current;
      }
      nullifiers.length = 0;
      nullifiers.push(...missing);
    } catch {
      // Check every note individually before marking a cached nullifier as unknown.
    }
    for (const nullifier of nullifiers) {
      try {
        const result = await this.checkNullifier(nullifier);
        const used = parseNullifierUsage(result);
        nullifierStatuses.set(nullifier, used === null ? "unknown" : used ? "spent" : "unspent");
      } catch {
        nullifierStatuses.set(nullifier, "unknown");
      }
    }
    return typeof noteStore.setNullifierStatuses === "function"
      ? noteStore.setNullifierStatuses(nullifierStatuses)
      : current;
  }

  async planWalletTransfer({ wallet, material, amount, denom, limit = 200, maxPages = defaultPrepareScanMaxPages, scan: scanOptions, scanSource, scan_source } = {}) {
    const resolvedScanOptions = resolveScanOptions({ scan: scanOptions, limit, maxPages, scanSource, scan_source });
    const scan = await this.scanWalletNotes({
      wallet,
      material,
      ...resolvedScanOptions,
      limit: resolvedScanOptions.limit ?? 200,
      maxPages: resolvedScanOptions.maxPages ?? defaultPrepareScanMaxPages,
      includeFoundNotes: true
    });
    return {
      plan: planTransferNotes({
        notes: scan.foundNotes,
        amount,
        denom: denom ?? this.defaultDenom
      }),
      scan
    };
  }

  async planWalletWithdraw({ wallet, material, amount, denom, limit = 200, maxPages = defaultPrepareScanMaxPages, scan: scanOptions, scanSource, scan_source } = {}) {
    const resolvedScanOptions = resolveScanOptions({ scan: scanOptions, limit, maxPages, scanSource, scan_source });
    const scan = await this.scanWalletNotes({
      wallet,
      material,
      ...resolvedScanOptions,
      limit: resolvedScanOptions.limit ?? 200,
      maxPages: resolvedScanOptions.maxPages ?? defaultPrepareScanMaxPages,
      includeFoundNotes: true
    });
    return {
      plan: planWithdrawNotes({
        notes: scan.foundNotes,
        amount,
        denom: denom ?? this.defaultDenom
      }),
      scan
    };
  }

  async prepareDeposit({ wallet, material, depositMaterial, deposit_material, amount, memo = "Clairveil deposit", gasLimit = 2500000, denom, assetDenom, proof, proofHex, proof_hex } = {}) {
    const privacy = material || await this.deriveWalletPrivacyMaterial(wallet);
    const prepared = this.buildDepositMessage({
      depositMaterial: depositMaterial ?? deposit_material,
      creator: privacy.address,
      rootSeed: privacy.rootSeed,
      amount,
      assetDenom: assetDenom ?? denom ?? this.defaultDenom,
      memo,
      proof,
      proofHex: proofHex ?? proof_hex
    });
    await this.assertProtocolPreflight(assetDenom ?? denom ?? this.defaultDenom);
    const signDoc = await this.buildDirectSignDoc({
      signer: privacy.address,
      pubKeyHex: privacy.pubKeyHex,
      gasLimit,
      messages: [
        {
          typeUrl: msgDepositTypeUrl,
          value: prepared.message
        }
      ],
      memo
    });

    return {
      status: "ready",
      signDoc,
      message: prepared.message,
      material: prepared.material,
      privacyAccount: publicPrivacyAccount(privacy)
    };
  }

  /**
   * Wait for a prepared deposit transaction and fail closed unless its
   * successful tx result contains the exact commitment and encrypted note
   * that were prepared for the wallet.
   */
  async confirmDeposit({
    txHash,
    tx_hash,
    prepared,
    material,
    depositMaterial,
    deposit_material,
    message,
    expectedCommitment,
    expected_commitment,
    expectedEncryptedNote,
    expected_encrypted_note,
    waitOptions,
    attempts,
    intervalMs
  } = {}) {
    const normalizedTxHash = String(txHash ?? tx_hash ?? "").trim().toUpperCase();
    if (!normalizedTxHash) throw new Error("txHash is required");
    const expected = depositExpectedMaterial({
      prepared,
      material,
      depositMaterial,
      deposit_material,
      message,
      expectedCommitment,
      expected_commitment,
      expectedEncryptedNote,
      expected_encrypted_note
    });
    const tx = await this.waitForTx(normalizedTxHash, {
      ...(waitOptions || {}),
      ...(attempts == null ? {} : { attempts }),
      ...(intervalMs == null ? {} : { intervalMs })
    });
    if (!tx) throw new Error(`deposit transaction was not found: ${normalizedTxHash}`);
    const code = explicitTransactionCode(tx);
    if (code !== 0) {
      throw new Error(`deposit transaction did not succeed: ${code == null ? "missing or malformed code" : `code ${code}`}`);
    }

    const event = transactionEvents(tx).find(candidate => {
      const type = transactionEventType(candidate);
      if (type !== "deposit" && type !== "shielded_deposit") return false;
      const commitment = String(transactionEventAttribute(candidate, "commitment"))
        .trim().replace(/^"|"$/g, "").replace(/^0x/i, "").toLowerCase();
      const encryptedNote = String(transactionEventAttribute(candidate, "encrypted_note"))
        .trim().replace(/^"|"$/g, "").replace(/^0x/i, "").toLowerCase();
      return commitment === expected.commitment && encryptedNote === expected.encryptedNote;
    });
    if (!event) {
      throw new Error("deposit tx result does not contain the prepared commitment and encrypted note");
    }
    return {
      status: "confirmed",
      txHash: normalizedTxHash,
      tx,
      event,
      commitment: expected.commitment,
      encryptedNote: expected.encryptedNote
    };
  }

  async prepareTransfer({
    wallet,
    material,
    amount,
    recipient,
    proverAdapter,
    signal,
    userPrivacyPolicy = "all-private",
    userDisclosureMode,
    userDisclosureTargetPubKeyHex = "",
    auditDisclosureTargetPubKeyHex,
    expectedRecipientHash,
    expected_recipient_hash,
    expectedAmountHash,
    expected_amount_hash,
    denom,
    allowPlanStep = false,
    scan,
    after,
    afterHeight,
    after_height,
    afterSequence,
    after_sequence,
    page,
    limit = 200,
    maxPages = defaultPrepareScanMaxPages,
    max_pages,
    eventTypes,
    event_types,
    outputLimit,
    output_limit,
    eventLimit,
    event_limit,
    maxEncodedBytes,
    max_encoded_bytes,
    scanSource,
    scan_source,
    gasLimit = 8000000,
    reservationManager,
    reservation_manager
  } = {}) {
    const resolvedReservationManager = reservationManager ?? reservation_manager ?? null;
    const operationEvidence = resolveDirectOperationEvidenceHashes({
      expectedRecipientHash,
      expected_recipient_hash,
      expectedAmountHash,
      expected_amount_hash
    });
    const privacy = material || await this.deriveWalletPrivacyMaterial(wallet);
    const scanOptions = resolveScanOptions({
      scan,
      after,
      afterHeight,
      after_height,
      afterSequence,
      after_sequence,
      page,
      limit,
      maxPages,
      max_pages,
      eventTypes,
      event_types,
      outputLimit,
      output_limit,
      eventLimit,
      event_limit,
      maxEncodedBytes,
      max_encoded_bytes,
      scanSource,
      scan_source
    });
    const scanResult = await this.scanNotes({
      rootSeed: privacy.rootSeed,
      ...scanOptions,
      limit: scanOptions.limit ?? 200,
      maxPages: scanOptions.maxPages ?? defaultPrepareScanMaxPages,
      includeFoundNotes: true
    });
    const availableFoundNotes = await reservationAvailableNotes(resolvedReservationManager, scanResult.foundNotes);
    const plan = planTransferNotes({
      notes: availableFoundNotes,
      amount,
      denom: denom ?? this.defaultDenom
    });
    if (plan.status === "self_merge_required" && !allowPlanStep) {
      return {
        status: plan.status,
        plan,
        scan: scanResult,
        privacyAccount: publicPrivacyAccount(privacy)
      };
    }
    if (!plan.canBuildTx) {
      return {
        status: plan.status,
        plan,
        scan: scanResult,
        privacyAccount: publicPrivacyAccount(privacy)
      };
    }
    const isFinal = plan.status === "final_transfer_ready";
    assertPlanCanBuildTx(plan);
    const transferProtocolConfig = await this.assertTransferProtocolConfig(denom ?? this.defaultDenom);
    assertTransferDisclosureCapabilities(transferProtocolConfig.disclosure_config, {
      userPrivacyPolicy: isFinal ? userPrivacyPolicy : "all-private",
      userDisclosureMode: isFinal ? userDisclosureMode : "none"
    });

    const requestedAuditPubKeyHex = String(auditDisclosureTargetPubKeyHex ?? "").trim().toLowerCase();
    const configuredAuditPubKeyHex = String(
      transferProtocolConfig.audit_config.audit_master_pubkey_hex || ""
    ).toLowerCase();
    if (requestedAuditPubKeyHex && requestedAuditPubKeyHex !== configuredAuditPubKeyHex) {
      throw new Error("transfer audit disclosure target must exactly match the active chain audit config");
    }
    const auditPubKeyHex = transferProtocolConfig.audit_config.audit_master_pubkey_hex;
    const stepRecipient = isFinal ? recipient : privacy.shieldedAddress;
    const stepAmount = isFinal ? amount : plan.nextAmount;
    let reservationBatch = null;
    try {
      reservationBatch = await preparePlanReservation(resolvedReservationManager, {
        plan,
        kind: isFinal ? "transfer" : "self_merge",
        metadata: {
          amount: stepAmount,
          recipient: stepRecipient,
          finalAmount: amount,
          finalRecipient: recipient
        }
      });
      const heartbeatResult = await withReservationHeartbeat(resolvedReservationManager, reservationBatch, async ({ assertHeartbeatHealthy, heartbeatNow }) => {
        const built = await this.buildTransferMessage({
          proverAdapter,
          creator: privacy.address,
          inputs: plan.selection.inputs,
          recipient: stepRecipient,
          amount: stepAmount,
          transferDenom: denom ?? this.defaultDenom,
          rootSeed: privacy.rootSeed,
          shieldedPrefix: this.shieldedPrefix,
          userPrivacyPolicy: isFinal ? userPrivacyPolicy : "all-private",
          userDisclosureMode: isFinal ? userDisclosureMode : "none",
          userDisclosureTargetPubKeyHex: isFinal ? userDisclosureTargetPubKeyHex : "",
          auditDisclosureTargetPubKeyHex: auditPubKeyHex,
          signal
        });
        assertHeartbeatHealthy();
        const signDoc = await this.buildDirectSignDoc({
          signer: privacy.address,
          pubKeyHex: privacy.pubKeyHex,
          gasLimit,
          messages: [
            {
              typeUrl: msgTransferTypeUrl,
              value: built.message
            }
          ],
          memo: reservationBatch
            ? reservationRequiredCosmosMemo("Clairveil veiled transfer")
            : "Clairveil veiled transfer"
        });
        const signDocHash = cosmosSignDocBindingHash(signDoc);
        await heartbeatNow();
        await markReservationProofReady(resolvedReservationManager, reservationBatch, transferProofReadyMetadata(built, {
          amount: stepAmount,
          denom: denom ?? this.defaultDenom,
          expectedRecipientHash: isFinal ? operationEvidence.expectedRecipientHash : "",
          expectedAmountHash: isFinal ? operationEvidence.expectedAmountHash : "",
          signDocHash
        }));
        return {
          built,
          signDoc: markCosmosSignDocReservationRequired(
            signDoc,
            reservationBatch
          )
        };
      });
      const { built, signDoc } = heartbeatResult;

      return {
        ...reservationReconciliationFields(heartbeatResult),
        status: "ready",
        plan,
        scan: scanResult,
        signDoc,
        payload: built.payload,
        proof: built.proof,
        message: built.message,
        reservation: reservationBatchSummary(reservationBatch),
        prepared: {
          planAction: isFinal ? "final_transfer" : "self_merge",
          isFinal,
          amount: stepAmount,
          recipient: stepRecipient,
          finalAmount: amount,
          finalRecipient: recipient,
          selectedInputTotal: plan.selection.total.toString(),
          reservation: reservationBatchSummary(reservationBatch)
        },
        privacyAccount: publicPrivacyAccount(privacy)
      };
    } catch (error) {
      await rollbackPlanReservationPreservingError(resolvedReservationManager, reservationBatch, error);
      throw error;
    }
  }

  async prepareTransferBatch({
    wallet,
    material,
    payments,
    amounts,
    recipient,
    proverAdapter,
    signal,
    userPrivacyPolicy = "all-private",
    userDisclosureMode = "none",
    userDisclosureTargetPubKeyHex = "",
    auditDisclosureTargetPubKeyHex,
    audit_disclosure_target_pubkey_hex,
    expectedRecipientHash,
    expected_recipient_hash,
    expectedRecipientHashes,
    expected_recipient_hashes,
    expectedAmountHashes,
    expected_amount_hashes,
    outputMode,
    output_mode,
    onPreparedPayload,
    on_prepared_payload,
    onPreparedProof,
    on_prepared_proof,
    denom,
    scan,
    after,
    afterHeight,
    after_height,
    afterSequence,
    after_sequence,
    page,
    limit = 200,
    maxPages = defaultPrepareScanMaxPages,
    max_pages,
    eventTypes,
    event_types,
    outputLimit,
    output_limit,
    eventLimit,
    event_limit,
    maxEncodedBytes,
    max_encoded_bytes,
    scanSource,
    scan_source,
    gasLimit = 25000000,
    expiresAtUnix,
    expires_at_unix,
    chainNowUnix,
    chain_now_unix,
    rootHex,
    root_hex,
    snapshotHeight,
    snapshot_height,
    disableSelfViewDisclosure,
    disable_self_view_disclosure,
    selfViewDisclosureTargetPubKeyHex,
    self_view_disclosure_target_pubkey,
    reservationManager,
    reservation_manager
  } = {}) {
    if (!this.enableExperimentalBatchTransfer) {
      throw new Error("one-proof batch transfer is feature-gated; construct the client with enableExperimentalBatchTransfer: true after completing downstream conformance and localnet validation");
    }
    if (outputMode != null && output_mode != null &&
        normalizeBatchTransferOutputMode(outputMode) !== normalizeBatchTransferOutputMode(output_mode)) {
      throw new Error("outputMode aliases conflict");
    }
    if (chainNowUnix != null && chain_now_unix != null &&
        normalizedBatchNowUnix(chainNowUnix) !== normalizedBatchNowUnix(chain_now_unix)) {
      throw new Error("chainNowUnix aliases conflict");
    }
    if (expiresAtUnix != null && expires_at_unix != null &&
        normalizedBatchNowUnix(expiresAtUnix) !== normalizedBatchNowUnix(expires_at_unix)) {
      throw new Error("expiresAtUnix aliases conflict");
    }
    if (rootHex != null && root_hex != null &&
        comparableBatchHex(rootHex) !== comparableBatchHex(root_hex)) {
      throw new Error("rootHex aliases conflict");
    }
    if (snapshotHeight != null && snapshot_height != null &&
        String(uint64CursorValue(snapshotHeight, "snapshotHeight")) !==
          String(uint64CursorValue(snapshot_height, "snapshot_height"))) {
      throw new Error("snapshotHeight aliases conflict");
    }
    const suppliedRootHex = rootHex ?? root_hex;
    const suppliedSnapshotHeight = snapshotHeight ?? snapshot_height;
    const hasPinnedRoot = suppliedRootHex != null && String(suppliedRootHex).trim() !== "";
    const hasPinnedSnapshotHeight = suppliedSnapshotHeight != null &&
      String(suppliedSnapshotHeight).trim() !== "";
    if (hasPinnedRoot !== hasPinnedSnapshotHeight) {
      throw new Error("rootHex and snapshotHeight must be supplied together for an exact Merkle snapshot");
    }
    for (const [value, label] of [
      [disableSelfViewDisclosure, "disableSelfViewDisclosure"],
      [disable_self_view_disclosure, "disable_self_view_disclosure"]
    ]) {
      if (value != null && typeof value !== "boolean") {
        throw new Error(`${label} must be a boolean`);
      }
    }
    if (disableSelfViewDisclosure != null && disable_self_view_disclosure != null &&
        disableSelfViewDisclosure !== disable_self_view_disclosure) {
      throw new Error("disableSelfViewDisclosure aliases conflict");
    }
    if (selfViewDisclosureTargetPubKeyHex != null &&
        self_view_disclosure_target_pubkey != null &&
        comparableBatchHex(selfViewDisclosureTargetPubKeyHex) !==
          comparableBatchHex(self_view_disclosure_target_pubkey)) {
      throw new Error("selfViewDisclosureTargetPubKeyHex aliases conflict");
    }
    if (reservationManager != null && reservation_manager != null &&
        reservationManager !== reservation_manager) {
      throw new Error("reservationManager aliases conflict");
    }
    const resolvedReservationManager = reservationManager ?? reservation_manager ?? null;
    const normalizedPayments = normalizeBatchTransferPayments({
      payments,
      amounts,
      recipient,
      userPrivacyPolicy,
      userDisclosureMode,
      userDisclosureTargetPubKeyHex
    });
    const normalizedAmounts = normalizedPayments.map(payment => payment.amount);
    const legacyOperationEvidence = resolveBatchOperationEvidence({
      amounts: normalizedAmounts,
      expectedRecipientHash,
      expected_recipient_hash,
      expectedRecipientHashes,
      expected_recipient_hashes,
      expectedAmountHashes,
      expected_amount_hashes
    });
    const resolvedPayments = normalizedPayments.map((payment, index) => {
      const legacyRecipientHash = legacyOperationEvidence.recipientHashes[index] || "";
      const legacyAmountHash = legacyOperationEvidence.amountHashes[index] || "";
      if (payment.expectedRecipientHash && legacyRecipientHash &&
          canonicalBatchEvidenceDigest(payment.expectedRecipientHash, `batch payment ${index} expected recipient hash`) !==
          canonicalBatchEvidenceDigest(legacyRecipientHash, `batch payment ${index} legacy expected recipient hash`)) {
        throw new Error(`batch payment ${index} expected recipient hash conflicts with the top-level evidence`);
      }
      if (payment.expectedAmountHash && legacyAmountHash &&
          canonicalBatchEvidenceDigest(payment.expectedAmountHash, `batch payment ${index} expected amount hash`) !==
          canonicalBatchEvidenceDigest(legacyAmountHash, `batch payment ${index} legacy expected amount hash`)) {
        throw new Error(`batch payment ${index} expected amount hash conflicts with the top-level evidence`);
      }
      return Object.freeze({
        ...payment,
        expectedRecipientHash: payment.expectedRecipientHash || legacyRecipientHash,
        expectedAmountHash: payment.expectedAmountHash || legacyAmountHash
      });
    });
    const resolvedOutputMode = normalizeBatchTransferOutputMode(outputMode ?? output_mode);
    if (onPreparedPayload != null && on_prepared_payload != null &&
        onPreparedPayload !== on_prepared_payload) {
      throw new Error("onPreparedPayload aliases conflict");
    }
    if (onPreparedProof != null && on_prepared_proof != null &&
        onPreparedProof !== on_prepared_proof) {
      throw new Error("onPreparedProof aliases conflict");
    }
    const persistPreparedPayload = onPreparedPayload ?? on_prepared_payload;
    const persistPreparedProof = onPreparedProof ?? on_prepared_proof;
    if (persistPreparedPayload != null && typeof persistPreparedPayload !== "function") {
      throw new Error("onPreparedPayload must be a function");
    }
    if (persistPreparedProof != null && typeof persistPreparedProof !== "function") {
      throw new Error("onPreparedProof must be a function");
    }
    if (!resolvedReservationManager) {
      throw new Error("one-proof batch transfer requires a reservationManager for atomic input reservation");
    }
    if (typeof persistPreparedPayload !== "function") {
      throw new Error("one-proof batch transfer requires onPreparedPayload to durably persist the private payload before proving");
    }
    if (typeof persistPreparedProof !== "function") {
      throw new Error("one-proof batch transfer requires onPreparedProof to durably persist the private proof before signing");
    }
    const privacy = material || await this.deriveWalletPrivacyMaterial(wallet);
    const scanOptions = resolveScanOptions({
      scan,
      after,
      afterHeight,
      after_height,
      afterSequence,
      after_sequence,
      page,
      limit,
      maxPages,
      max_pages,
      eventTypes,
      event_types,
      outputLimit,
      output_limit,
      eventLimit,
      event_limit,
      maxEncodedBytes,
      max_encoded_bytes,
      scanSource,
      scan_source
    });
    if (scanOptions.scanSource != null &&
        String(scanOptions.scanSource).trim() !== "privacy_scan") {
      throw new Error("one-proof batch transfer only supports the typed privacy_scan source");
    }
    const scanResult = await this.scanNotes({
      rootSeed: privacy.rootSeed,
      ...scanOptions,
      scanSource: "privacy_scan",
      limit: scanOptions.limit ?? 200,
      maxPages: scanOptions.maxPages ?? defaultPrepareScanMaxPages,
      includeFoundNotes: true
    });
    if (scanResult.scanCursor?.source !== "privacy_scan") {
      throw new Error("one-proof batch transfer requires the typed privacy-scan-v2 source; legacy scan fallback cannot recover batch outputs safely");
    }
    const availableFoundNotes = await reservationAvailableNotes(resolvedReservationManager, scanResult.foundNotes);
    const plan = planTransferBatchNotes({
      notes: availableFoundNotes,
      amounts: normalizedAmounts,
      denom: denom ?? this.defaultDenom
    });
    if (!plan.canBuildTx) {
      return {
        status: plan.status,
        plan,
        scan: scanResult,
        privacyAccount: publicPrivacyAccount(privacy)
      };
    }
    assertPlanCanBuildTx(plan);
    const transferProtocolConfig = await this.assertTransferProtocolConfig(denom ?? this.defaultDenom);
    const paymentPolicies = resolvedPayments.map((payment, index) => {
      const capabilities = assertTransferDisclosureCapabilities(transferProtocolConfig.disclosure_config, {
        userPrivacyPolicy: payment.userPrivacyPolicy,
        userDisclosureMode: payment.userDisclosureMode
      });
      const policy = transferPrivacyPolicyNames.indexOf(capabilities.policy);
      const disclosureMode = transferDisclosureModeNames.indexOf(capabilities.mode);
      if (policy !== 0 && disclosureMode === 2 && !payment.userDisclosureTargetPubKeyHex) {
        throw new Error(`batch transfer payment ${index} recipient-encrypted disclosure requires a disclosure target public key`);
      }
      return Object.freeze({ ...payment, policyName: capabilities.policy, modeName: capabilities.mode, privacyPolicy: policy, disclosureMode });
    });

    if (!proverAdapter || typeof proverAdapter.proveBatchTransfer !== "function") {
      throw new Error("prepareTransferBatch requires a proverAdapter with proveBatchTransfer(payload)");
    }
    const batchDenom = denom ?? this.defaultDenom;
    const resolvedDisableSelfViewDisclosure = disableSelfViewDisclosure ?? disable_self_view_disclosure ?? false;
    const coins = paymentPolicies.map((payment, index) => {
      const coin = parseCoin(payment.amount, batchDenom);
      if (coin.denom !== batchDenom) {
        throw new Error(`batch transfer payment ${index} denom must equal ${batchDenom}`);
      }
      return coin;
    });
    const preparedPayments = paymentPolicies.map((payment, index) => Object.freeze({
      ...payment,
      coin: coins[index]
    }));
    const requestedTotal = coins.reduce((sum, coin) => sum + BigInt(coin.amount), 0n);
    const selectedInputs = plan.selection?.inputs || plan.selections?.[0]?.inputs || [];
    if (selectedInputs.length < 1 || selectedInputs.length > 16) {
      throw new Error("one-proof batch transfer requires 1..16 selected input notes");
    }
    const selectedTotal = selectedInputs.reduce((sum, found) => sum + found.note.amount, 0n);
    const change = selectedTotal - requestedTotal;
    if (change < 0n) throw new Error("one-proof batch transfer selected input total is insufficient");
    const compactOutputCount = coins.length + (change > 0n ? 1 : 0);
    if (compactOutputCount < 1 || compactOutputCount > 32) {
      throw new Error("one-proof batch transfer requires 1..32 outputs including change");
    }
    const outputCount = resolvedOutputMode === "exact32" ? 32 : compactOutputCount;

    const auditConfig = transferProtocolConfig.audit_config;
    if (auditDisclosureTargetPubKeyHex != null &&
        audit_disclosure_target_pubkey_hex != null &&
        String(auditDisclosureTargetPubKeyHex).trim().toLowerCase() !==
          String(audit_disclosure_target_pubkey_hex).trim().toLowerCase()) {
      throw new Error("auditDisclosureTargetPubKeyHex aliases conflict");
    }
    const requestedAuditPubKeyHex = String(
      auditDisclosureTargetPubKeyHex ?? audit_disclosure_target_pubkey_hex ?? ""
    ).trim().toLowerCase();
    if (requestedAuditPubKeyHex &&
        requestedAuditPubKeyHex !== String(auditConfig.audit_master_pubkey_hex || "").toLowerCase()) {
      throw new Error("batch transfer audit disclosure target must exactly match the active chain audit config");
    }
    const auditPubKeyHex = auditConfig.audit_master_pubkey_hex;
    const resolvedNowUnix = normalizedBatchNowUnix(
      chainNowUnix ?? chain_now_unix ?? Math.floor(Date.now() / 1000)
    );
    const resolvedExpiresAtUnix = expiresAtUnix ?? expires_at_unix ?? resolvedNowUnix + 1800;
    const expiry = normalizedBatchNowUnix(resolvedExpiresAtUnix);
    if (expiry <= resolvedNowUnix) throw new Error("batch transfer expiresAtUnix must be later than chainNowUnix");
    let reservationBatch = null;
    let payloadCheckpointStarted = false;
    let proofCheckpointStarted = false;
    let checkpointedPayloadHash = "";
    try {
      reservationBatch = await preparePlanReservation(resolvedReservationManager, {
        plan,
        kind: "batch_transfer",
        metadata: {
          batch_transfer_payment_count: preparedPayments.length,
          batch_transfer_output_mode: resolvedOutputMode,
          // CircuitConfig v1 exposes the active identity as a structured
          // `circuit_set_identity`.  Reservation metadata is deliberately
          // JSON-only, so never persist the absent legacy shorthand here:
          // `undefined` causes the reservation to fail before the prover is
          // called and hides an otherwise valid batch behind a generic UI
          // preparation error.
          circuit_set_id:
            transferProtocolConfig.circuit_config.circuit_set_identity
              .circuit_set_id,
          max_inputs: 16,
          max_outputs: 32
        }
      });
      const heartbeatResult = await withReservationHeartbeat(resolvedReservationManager, reservationBatch, async ({ assertHeartbeatHealthy, heartbeatNow }) => {
        const commitmentHexes = selectedInputs.map(found => fieldHexV1(computeNoteCommitmentV1(found.note)));
        const treeState = hasPinnedRoot ? null : await this.fetchTreeState();
        const resolvedRootHex = String(suppliedRootHex || treeState?.root || treeState?.root_hex || treeState?.rootHex || "").trim();
        if (!resolvedRootHex) throw new Error("one-proof batch transfer requires a verified current tree root");
        const pathProvider = await this.createCommitmentPathSnapshotProvider({
          commitmentHexes,
          rootHex: resolvedRootHex,
          ...(hasPinnedSnapshotHeight ? { snapshotHeight: suppliedSnapshotHeight } : {})
        });
        const preparedInputs = await Promise.all(selectedInputs.map(async found => {
          const path = await pathProvider.lookupMerklePath(fieldHexV1(computeNoteCommitmentV1(found.note)));
          return {
            note: found.note,
            merklePath: path.path,
            merklePathHelper: path.path_helper
          };
        }));
        const ownerSpend = deriveSpendKeys(privacy.rootSeed).pubKey;
        const ownerView = deriveViewKeys(privacy.rootSeed).pubKey;
        const assetID = computeAssetIdV1(batchDenom);
        const outputs = preparedPayments.map(payment => {
          const recipientKeys = decodeShieldedAddress(payment.recipient, { shieldedPrefix: this.shieldedPrefix });
          return {
            kind: "payment",
            note: createNote({
              spendPubKey: recipientKeys.spendPubKey,
              viewPubKey: recipientKeys.viewPubKey,
              amount: payment.coin.amount,
              assetId: assetID,
              randomness: randomBatchField(),
              memo: payment.memo
            }),
            privacyPolicy: payment.privacyPolicy,
            disclosureMode: payment.disclosureMode,
            ...(payment.privacyPolicy !== 0 && payment.disclosureMode === 2
              ? { disclosureTargetPubKey: payment.userDisclosureTargetPubKeyHex }
              : {}),
            userDisclosureBlinding: payment.privacyPolicy === 0 ? 0n : randomBatchField(),
            fullDisclosureBlinding: randomBatchField()
          };
        });
        if (change > 0n) {
          outputs.push({
            kind: "change",
            note: createNote({
              spendPubKey: ownerSpend,
              viewPubKey: ownerView,
              amount: change,
              assetId: assetID,
              randomness: randomBatchField(),
              memo: "Change"
            }),
            privacyPolicy: 0,
            disclosureMode: 0,
            userDisclosureBlinding: 0n,
            fullDisclosureBlinding: randomBatchField()
          });
        }
        while (outputs.length < outputCount) {
          outputs.push({
            kind: "padding",
            note: createNote({
              spendPubKey: ownerSpend,
              viewPubKey: ownerView,
              amount: 0n,
              assetId: assetID,
              randomness: randomBatchField(),
              memo: "Padding"
            }),
            privacyPolicy: 0,
            disclosureMode: 0,
            userDisclosureBlinding: 0n,
            fullDisclosureBlinding: randomBatchField()
          });
        }
        const spendSigner = createSpendNoteHashSigner(privacy.rootSeed);
        const selfViewTarget = selfViewDisclosureTargetPubKeyHex
          || self_view_disclosure_target_pubkey
          || deriveDisclosureKeys(privacy.rootSeed).pubKey;
        const payload = await buildPreparedBatchTransferPayload({
          creator: privacy.address,
          chainId: this.chainId,
          expiresAtUnix: expiry,
          root: resolvedRootHex,
          inputs: preparedInputs,
          outputs,
          auditKeyId: auditConfig.audit_key_id,
          auditKeyEpoch: auditConfig.audit_key_epoch,
          auditDisclosureTargetPubKey: auditPubKeyHex,
          selfViewDisclosureTargetPubKey: selfViewTarget,
          disableSelfViewDisclosure: resolvedDisableSelfViewDisclosure,
          signer: {
            signBatchTransfer: request => spendSigner.signNoteHash(request.expectedIntent)
          }
        });
        validatePreparedBatchTransferPayloadEnvelope(payload, { nowUnix: resolvedNowUnix });
        const operationId = reservationBatch?.operation_id || `batch:${payload.payload_hash}`;
        const expectedOutputs = buildBatchTransferExpectedOutputEvidence({
          payload,
          payments: preparedPayments,
          operationId,
          denom: batchDenom,
          shieldedPrefix: this.shieldedPrefix,
          nowUnix: resolvedNowUnix
        });
        if (persistPreparedPayload) {
          payloadCheckpointStarted = true;
          checkpointedPayloadHash = payload.payload_hash;
          await persistPreparedPayload(payload, {
            operationId,
            reservation: reservationBatchSummary(reservationBatch)
          });
        }
        const {
          proof,
          message,
          effects
        } = await this.provePreparedBatchTransfer({
          payload,
          proverAdapter,
          creator: privacy.address,
          denom: batchDenom,
          operationId,
          reservation: reservationBatchSummary(reservationBatch),
          nowUnix: resolvedNowUnix,
          signal,
          onPreparedProof: persistPreparedProof
            ? preparedProof => {
                proofCheckpointStarted = true;
                checkpointedPayloadHash = payload.payload_hash;
                return persistPreparedProof(preparedProof, {
                  payload,
                  operationId,
                  reservation: reservationBatchSummary(reservationBatch)
                });
              }
            : undefined
        });
        assertHeartbeatHealthy();
        const signDoc = await this.buildDirectSignDoc({
          signer: privacy.address,
          pubKeyHex: privacy.pubKeyHex,
          gasLimit,
          messages: [{
            typeUrl: msgBatchTransferTypeUrl,
            value: MsgBatchTransfer.fromPartial(message)
          }],
          memo: reservationBatch
            ? reservationRequiredCosmosMemo("Clairveil batch veiled transfer")
            : "Clairveil batch veiled transfer"
        });
        const signDocHash = cosmosSignDocBindingHash(signDoc);
        const operationEvidence = buildBatchTransferOperationEvidence({
          payload,
          proof,
          payments: preparedPayments,
          expectedOutputs,
          operationId,
          denom: batchDenom,
          shieldedPrefix: this.shieldedPrefix,
          nowUnix: resolvedNowUnix
        });
        await heartbeatNow();
        await markReservationProofReadyForBatchItems(resolvedReservationManager, reservationBatch, [{
          notes: selectedInputs,
          metadata: {
            payloadHash: payload.payload_hash,
            signDocHash,
            expectedOperationEvidenceHash: operationEvidence.evidenceHash,
            operationSuccessEvidenceRequired: true,
            metadata: {
              payload_expires_at_unix: String(payload.expires_at_unix),
              batch_transfer_input_count: selectedInputs.length,
              batch_transfer_output_count: payload.outputs.length,
              batch_transfer_output_mode: resolvedOutputMode,
              batch_transfer_nullifier_hexes: effects.nullifier_hexes,
              batch_transfer_output_commitment_hexes: effects.output_commitment_hexes,
              batch_transfer_operation_evidence: operationEvidence.evidence,
              batch_transfer_operation_evidence_hash: operationEvidence.evidenceHash
            }
          }
        }]);
        return {
          payload,
          proof,
          message,
          operationEvidence: operationEvidence.evidence,
          operationEvidenceHash: operationEvidence.evidenceHash,
          signDoc: markCosmosSignDocReservationRequired(
            signDoc,
            reservationBatch
          )
        };
      });
      const {
        payload,
        proof,
        message,
        signDoc,
        operationEvidence,
        operationEvidenceHash
      } = heartbeatResult;

      return {
        ...reservationReconciliationFields(heartbeatResult),
        status: "ready",
        plan,
        scan: scanResult,
        signDoc,
        payload,
        proof,
        message,
        operationEvidence,
        operationEvidenceHash,
        reservation: reservationBatchSummary(reservationBatch),
        prepared: {
          planAction: "batch_transfer",
          payments: preparedPayments.map(payment => ({
            itemId: payment.itemId,
            amount: payment.coin.raw,
            recipient: payment.recipient,
            privacyPolicy: payment.policyName,
            disclosureMode: payment.modeName
          })),
          amounts: preparedPayments.map(payment => payment.coin.raw),
          ...(preparedPayments.every(payment => payment.recipient === preparedPayments[0].recipient)
            ? { recipient: preparedPayments[0].recipient }
            : {}),
          outputMode: resolvedOutputMode,
          selectedInputTotal: selectedTotal.toString(),
          inputCount: selectedInputs.length,
          outputCount: payload.outputs.length,
          reservation: reservationBatchSummary(reservationBatch)
        },
        privacyAccount: publicPrivacyAccount(privacy)
      };
    } catch (error) {
      const cleanupErrors = [];
      if ((payloadCheckpointStarted || proofCheckpointStarted) && reservationBatch?.reservation_ids?.length) {
        try {
          if (typeof resolvedReservationManager?.markManualReview !== "function") {
            throw new Error("reservationManager.markManualReview is required after a batch artifact checkpoint starts");
          }
          await resolvedReservationManager.markManualReview(reservationBatch.reservation_ids, {
            leaseToken: reservationBatch.lease_token || reservationBatch.reservations?.[0]?.lease_token || "",
            error: "batch_checkpointed_artifact_requires_recovery",
            metadata: {
              reconcile_reason: "batch_checkpointed_artifact_requires_recovery",
              batch_payload_checkpoint_started: payloadCheckpointStarted,
              batch_proof_checkpoint_started: proofCheckpointStarted,
              ...(checkpointedPayloadHash ? { batch_transfer_payload_hash: checkpointedPayloadHash } : {})
            }
          });
        } catch (cleanupError) {
          cleanupErrors.push(cleanupError);
        }
        appendReservationCleanupErrors(error, cleanupErrors);
        throw error;
      }
      try {
        await replanProofReadyReservations(resolvedReservationManager, reservationBatch, error, "batch_prepare_failed_after_partial_proof_ready");
      } catch (cleanupError) {
        cleanupErrors.push(cleanupError);
      }
      try {
        await rollbackPlanReservation(resolvedReservationManager, reservationBatch);
      } catch (cleanupError) {
        cleanupErrors.push(cleanupError);
      }
      appendReservationCleanupErrors(error, cleanupErrors);
      throw error;
    }
  }

  /**
   * Resume only the proof stage of a durably checkpointed batch payload without
   * rebuilding or re-signing its owner intent. The caller must restore the
   * original operation/reservations and complete ProofReady finalization before
   * signing or broadcasting. The same selected prover is called once.
   */
  async provePreparedBatchTransfer({
    payload,
    proverAdapter,
    creator,
    denom,
    operationId,
    operation_id,
    reservation,
    reservationBatch,
    reservation_batch,
    nowUnix,
    chainNowUnix,
    chain_now_unix,
    signal,
    onPreparedProof,
    on_prepared_proof
  } = {}) {
    if (!this.enableExperimentalBatchTransfer) {
      throw new Error("one-proof batch transfer is feature-gated; construct the client with enableExperimentalBatchTransfer: true after completing downstream conformance and localnet validation");
    }
    if (!proverAdapter || typeof proverAdapter.proveBatchTransfer !== "function") {
      throw new Error("provePreparedBatchTransfer requires a proverAdapter with proveBatchTransfer(payload)");
    }
    if (operationId != null && operation_id != null &&
        String(operationId) !== String(operation_id)) {
      throw new Error("operationId aliases conflict");
    }
    const reservationAliases = [reservation, reservationBatch, reservation_batch]
      .filter(value => value != null);
    if (reservationAliases.length > 1 &&
        reservationAliases.some(value => value !== reservationAliases[0])) {
      throw new Error("reservation aliases conflict");
    }
    if (onPreparedProof != null && on_prepared_proof != null &&
        onPreparedProof !== on_prepared_proof) {
      throw new Error("onPreparedProof aliases conflict");
    }
    const persistPreparedProof = onPreparedProof ?? on_prepared_proof;
    if (typeof persistPreparedProof !== "function") {
      throw new Error("provePreparedBatchTransfer requires onPreparedProof to durably persist the private proof");
    }
    const resolvedOperationID = String(operationId ?? operation_id ?? "").trim();
    if (!resolvedOperationID) {
      throw new Error("provePreparedBatchTransfer requires the original operationId");
    }
    const resolvedReservation = reservation ?? reservationBatch ?? reservation_batch ?? null;
    if (!resolvedReservation) {
      throw new Error("provePreparedBatchTransfer requires the original reservation batch");
    }
    const reservationOperationID = String(
      resolvedReservation.operation_id ?? resolvedReservation.operationId ?? ""
    ).trim();
    if (reservationOperationID && reservationOperationID !== resolvedOperationID) {
      throw new Error("prepared batch transfer operationId does not match the reservation batch");
    }
    const resolvedNowUnix = normalizedBatchNowUnix(
      chainNowUnix ?? chain_now_unix ?? nowUnix ?? Math.floor(Date.now() / 1000)
    );
    validatePreparedBatchTransferPayloadEnvelope(payload, { nowUnix: resolvedNowUnix });
    const resolvedDenom = canonicalAssetDenomV1(denom ?? this.defaultDenom);
    const transferProtocolConfig = await this.assertTransferProtocolConfig(resolvedDenom);
    assertPreparedBatchTransferMatchesActiveConfig(payload, transferProtocolConfig, resolvedDenom);
    const effects = preparedBatchTransferEffectHex(payload);
    batchTransferNullifiersUnspent(
      await this.checkNullifiers(effects.nullifier_hexes),
      effects.nullifier_hexes
    );
    const proofResponse = await proverAdapter.proveBatchTransfer(payload, { signal });
    if (proofResponse?.proof && typeof proofResponse.proof === "object" &&
        proofResponse.version !== batchTransferProofResponseVersion) {
      throw new Error(`unsupported batch transfer proof response version ${JSON.stringify(proofResponse.version)}`);
    }
    const proof = normalizePreparedBatchTransferProof(
      payload,
      proofResponse?.proof && typeof proofResponse.proof === "object" ? proofResponse.proof : proofResponse,
      { nowUnix: resolvedNowUnix }
    );
    await persistPreparedProof(proof, {
      payload,
      operationId: resolvedOperationID,
      reservation: resolvedReservation
    });
    batchTransferNullifiersUnspent(
      await this.checkNullifiers(effects.nullifier_hexes),
      effects.nullifier_hexes
    );
    const message = buildMsgBatchTransferFromPrepared(payload, proof, {
      creator,
      nowUnix: resolvedNowUnix
    });
    return {
      payload,
      proof,
      message,
      effects,
      proofStageOnly: true,
      reservationFinalizationRequired: true
    };
  }

  /**
   * Complete the local stage after a checkpointed batch proof has been
   * restored. This derives the message and operation evidence from the exact
   * payload/proof, creates the reservation-bound sign doc, and atomically
   * advances every reserved input to ProofReady. It performs no wallet or
   * broadcast request.
   */
  async finalizePreparedBatchTransfer({
    payload,
    proof,
    signer,
    pubKeyHex,
    gasLimit,
    memo = "Clairveil batch veiled transfer",
    payments,
    amounts,
    recipient,
    userPrivacyPolicy = "all-private",
    userDisclosureMode = "none",
    userDisclosureTargetPubKeyHex = "",
    expectedRecipientHash,
    expected_recipient_hash,
    expectedRecipientHashes,
    expected_recipient_hashes,
    expectedAmountHashes,
    expected_amount_hashes,
    denom,
    operationId,
    operation_id,
    reservationManager,
    reservation_manager,
    reservation,
    reservationBatch,
    reservation_batch,
    chainNowUnix,
    chain_now_unix
  } = {}) {
    if (!this.enableExperimentalBatchTransfer) {
      throw new Error("one-proof batch transfer is feature-gated; construct the client with enableExperimentalBatchTransfer: true after completing downstream conformance and localnet validation");
    }
    if (operationId != null && operation_id != null && String(operationId) !== String(operation_id)) {
      throw new Error("operationId aliases conflict");
    }
    if (chainNowUnix != null && chain_now_unix != null && Number(chainNowUnix) !== Number(chain_now_unix)) {
      throw new Error("batch transfer chainNowUnix aliases conflict");
    }
    if (reservationManager != null && reservation_manager != null && reservationManager !== reservation_manager) {
      throw new Error("reservationManager aliases conflict");
    }
    const reservationAliases = [reservation, reservationBatch, reservation_batch]
      .filter(value => value != null);
    if (reservationAliases.length > 1 && reservationAliases.some(value => value !== reservationAliases[0])) {
      throw new Error("reservation aliases conflict");
    }
    const resolvedReservationManager = reservationManager ?? reservation_manager ?? null;
    if (!resolvedReservationManager) {
      throw new Error("finalizePreparedBatchTransfer requires the original reservationManager");
    }
    const resolvedReservation = reservation ?? reservationBatch ?? reservation_batch ?? null;
    if (!resolvedReservation?.reservation_ids?.length) {
      throw new Error("finalizePreparedBatchTransfer requires the original reservation batch");
    }
    const resolvedOperationID = String(operationId ?? operation_id ?? "").trim();
    if (!resolvedOperationID) {
      throw new Error("finalizePreparedBatchTransfer requires the original operationId");
    }
    const reservationOperationID = String(
      resolvedReservation.operation_id ?? resolvedReservation.operationId ?? ""
    ).trim();
    if (reservationOperationID && reservationOperationID !== resolvedOperationID) {
      throw new Error("prepared batch transfer operationId does not match the reservation batch");
    }
    const resolvedSigner = String(signer || "").trim();
    if (!resolvedSigner) throw new Error("finalizePreparedBatchTransfer requires the original Cosmos signer");
    const resolvedNowUnix = normalizedBatchNowUnix(
      chainNowUnix ?? chain_now_unix ?? Math.floor(Date.now() / 1000)
    );
    validatePreparedBatchTransferPayloadEnvelope(payload, { nowUnix: resolvedNowUnix });
    const resolvedDenom = canonicalAssetDenomV1(denom ?? this.defaultDenom);
    const transferProtocolConfig = await this.assertTransferProtocolConfig(resolvedDenom);
    assertPreparedBatchTransferMatchesActiveConfig(payload, transferProtocolConfig, resolvedDenom);

    const normalizedPayments = normalizeBatchTransferPayments({
      payments,
      amounts,
      recipient,
      userPrivacyPolicy,
      userDisclosureMode,
      userDisclosureTargetPubKeyHex
    });
    const legacyOperationEvidence = resolveBatchOperationEvidence({
      amounts: normalizedPayments.map(payment => payment.amount),
      expectedRecipientHash,
      expected_recipient_hash,
      expectedRecipientHashes,
      expected_recipient_hashes,
      expectedAmountHashes,
      expected_amount_hashes
    });
    const resolvedPayments = normalizedPayments.map((payment, index) => {
      const legacyRecipientHash = legacyOperationEvidence.recipientHashes[index] || "";
      const legacyAmountHash = legacyOperationEvidence.amountHashes[index] || "";
      if (payment.expectedRecipientHash && legacyRecipientHash &&
          canonicalBatchEvidenceDigest(payment.expectedRecipientHash, `batch payment ${index} expected recipient hash`) !==
            canonicalBatchEvidenceDigest(legacyRecipientHash, `batch payment ${index} legacy expected recipient hash`)) {
        throw new Error(`batch payment ${index} expected recipient hash conflicts with the top-level evidence`);
      }
      if (payment.expectedAmountHash && legacyAmountHash &&
          canonicalBatchEvidenceDigest(payment.expectedAmountHash, `batch payment ${index} expected amount hash`) !==
            canonicalBatchEvidenceDigest(legacyAmountHash, `batch payment ${index} legacy expected amount hash`)) {
        throw new Error(`batch payment ${index} expected amount hash conflicts with the top-level evidence`);
      }
      return Object.freeze({
        ...payment,
        expectedRecipientHash: payment.expectedRecipientHash || legacyRecipientHash,
        expectedAmountHash: payment.expectedAmountHash || legacyAmountHash
      });
    });
    const preparedPayments = resolvedPayments.map((payment, index) => {
      const capabilities = assertTransferDisclosureCapabilities(transferProtocolConfig.disclosure_config, {
        userPrivacyPolicy: payment.userPrivacyPolicy,
        userDisclosureMode: payment.userDisclosureMode
      });
      const privacyPolicy = transferPrivacyPolicyNames.indexOf(capabilities.policy);
      const disclosureMode = transferDisclosureModeNames.indexOf(capabilities.mode);
      if (privacyPolicy !== 0 && disclosureMode === 2 && !payment.userDisclosureTargetPubKeyHex) {
        throw new Error(`batch transfer payment ${index} recipient-encrypted disclosure requires a disclosure target public key`);
      }
      const coin = parseCoin(payment.amount, resolvedDenom);
      if (coin.denom !== resolvedDenom) {
        throw new Error(`batch transfer payment ${index} denom must equal ${resolvedDenom}`);
      }
      return Object.freeze({ ...payment, privacyPolicy, disclosureMode, coin });
    });
    const normalizedProof = normalizePreparedBatchTransferProof(payload, proof, { nowUnix: resolvedNowUnix });
    const message = buildMsgBatchTransferFromPrepared(payload, normalizedProof, {
      creator: resolvedSigner,
      nowUnix: resolvedNowUnix
    });
    const expectedOutputs = buildBatchTransferExpectedOutputEvidence({
      payload,
      payments: preparedPayments,
      operationId: resolvedOperationID,
      denom: resolvedDenom,
      shieldedPrefix: this.shieldedPrefix,
      nowUnix: resolvedNowUnix
    });
    const operationEvidence = buildBatchTransferOperationEvidence({
      payload,
      proof: normalizedProof,
      expectedOutputs,
      operationId: resolvedOperationID,
      denom: resolvedDenom,
      shieldedPrefix: this.shieldedPrefix,
      nowUnix: resolvedNowUnix
    });
    const signDoc = await this.createBatchTransferSignDoc({
      signer: resolvedSigner,
      pubKeyHex,
      gasLimit,
      message,
      memo,
      expectedCircuitIdentity:
        transferProtocolConfig.circuit_config.circuit_set_identity,
      chainNowUnix: resolvedNowUnix
    });
    const effects = preparedBatchTransferEffectHex(payload);
    if (resolvedReservation.reservation_ids.length !== effects.nullifier_hexes.length) {
      throw new Error("prepared batch transfer reservation count does not match its input nullifiers");
    }
    batchTransferNullifiersUnspent(
      await this.checkNullifiers(effects.nullifier_hexes),
      effects.nullifier_hexes
    );
    const persistedOutputMode = String(
      resolvedReservation.reservations?.[0]?.metadata?.batch_transfer_output_mode ||
      (payload.outputs.length === 32 ? "exact32" : "compact")
    );
    await markReservationProofReady(resolvedReservationManager, resolvedReservation, {
      payloadHash: payload.payload_hash,
      signDocHash: cosmosSignDocBindingHash(signDoc),
      expectedOperationEvidenceHash: operationEvidence.evidenceHash,
      operationSuccessEvidenceRequired: true,
      metadata: {
        payload_expires_at_unix: String(payload.expires_at_unix),
        batch_transfer_input_count: effects.nullifier_hexes.length,
        batch_transfer_output_count: payload.outputs.length,
        batch_transfer_output_mode: persistedOutputMode,
        batch_transfer_nullifier_hexes: effects.nullifier_hexes,
        batch_transfer_output_commitment_hexes: effects.output_commitment_hexes,
        batch_transfer_operation_evidence: operationEvidence.evidence,
        batch_transfer_operation_evidence_hash: operationEvidence.evidenceHash
      }
    });
    return {
      payload,
      proof: normalizedProof,
      message,
      effects,
      operationEvidence: operationEvidence.evidence,
      operationEvidenceHash: operationEvidence.evidenceHash,
      signDoc: markCosmosSignDocReservationRequired(signDoc, resolvedReservation),
      reservation: reservationBatchSummary(resolvedReservation)
    };
  }

  async prepareWithdraw({
    wallet,
    material,
    amount,
    recipient,
    proverAdapter,
    signal,
    denom,
    assetDenom,
    scan,
    after,
    afterHeight,
    after_height,
    afterSequence,
    after_sequence,
    page,
    limit = 200,
    maxPages = defaultPrepareScanMaxPages,
    max_pages,
    eventTypes,
    event_types,
    outputLimit,
    output_limit,
    eventLimit,
    event_limit,
    maxEncodedBytes,
    max_encoded_bytes,
    scanSource,
    scan_source,
    expiresAtUnix,
    chainNowUnix,
    chain_now_unix,
    gasLimit = 5000000,
    reservationManager,
    reservation_manager
  } = {}) {
    const resolvedReservationManager = reservationManager ?? reservation_manager ?? null;
    const privacy = material || await this.deriveWalletPrivacyMaterial(wallet);
    const scanOptions = resolveScanOptions({
      scan,
      after,
      afterHeight,
      after_height,
      afterSequence,
      after_sequence,
      page,
      limit,
      maxPages,
      max_pages,
      eventTypes,
      event_types,
      outputLimit,
      output_limit,
      eventLimit,
      event_limit,
      maxEncodedBytes,
      max_encoded_bytes,
      scanSource,
      scan_source
    });
    const scanResult = await this.scanNotes({
      rootSeed: privacy.rootSeed,
      ...scanOptions,
      limit: scanOptions.limit ?? 200,
      maxPages: scanOptions.maxPages ?? defaultPrepareScanMaxPages,
      includeFoundNotes: true
    });
    const availableFoundNotes = await reservationAvailableNotes(resolvedReservationManager, scanResult.foundNotes);
    const plan = planWithdrawNotes({
      notes: availableFoundNotes,
      amount,
      denom: assetDenom ?? denom ?? this.defaultDenom
    });
    if (!plan.canBuildTx) {
      return {
        status: plan.status,
        plan,
        scan: scanResult,
        privacyAccount: publicPrivacyAccount(privacy)
      };
    }
    assertPlanCanBuildTx(plan);
    await this.assertProtocolPreflight(assetDenom ?? denom ?? this.defaultDenom);

    let reservationBatch = null;
    try {
      reservationBatch = await preparePlanReservation(resolvedReservationManager, {
        plan,
        kind: "withdraw",
        metadata: {
          amount,
          recipient
        }
      });
      const heartbeatResult = await withReservationHeartbeat(resolvedReservationManager, reservationBatch, async ({ assertHeartbeatHealthy, heartbeatNow }) => {
        const built = await this.buildWithdrawMessage({
          proverAdapter,
          creator: privacy.address,
          notes: [plan.selectedNote],
          amount,
          assetDenom: assetDenom ?? denom ?? this.defaultDenom,
          recipient,
          rootSeed: privacy.rootSeed,
          chainId: this.chainId,
          expiresAtUnix,
          chainNowUnix: chainNowUnix ?? chain_now_unix,
          signal
        });
        assertHeartbeatHealthy();
        const signDoc = await this.buildDirectSignDoc({
          signer: privacy.address,
          pubKeyHex: privacy.pubKeyHex,
          gasLimit,
          messages: [
            {
              typeUrl: msgWithdrawTypeUrl,
              value: built.message
            }
          ],
          memo: reservationBatch
            ? reservationRequiredCosmosMemo("Clairveil veiled withdraw")
            : "Clairveil veiled withdraw"
        });
        const signDocHash = cosmosSignDocBindingHash(signDoc);
        await heartbeatNow();
        await markReservationProofReady(
          resolvedReservationManager,
          reservationBatch,
          withdrawProofReadyMetadata(built, { signDocHash })
        );
        return {
          built,
          signDoc: markCosmosSignDocReservationRequired(
            signDoc,
            reservationBatch
          )
        };
      });
      const { built, signDoc } = heartbeatResult;

      return {
        ...reservationReconciliationFields(heartbeatResult),
        status: "ready",
        plan,
        scan: scanResult,
        signDoc,
        proverPayload: built.proverPayload,
        proof: built.proof,
        payload: built.payload,
        message: built.message,
        selectedNote: built.selectedNote,
        reservation: reservationBatchSummary(reservationBatch),
        privacyAccount: publicPrivacyAccount(privacy)
      };
    } catch (error) {
      await rollbackPlanReservationPreservingError(resolvedReservationManager, reservationBatch, error);
      throw error;
    }
  }

  async prepareRelayWithdraw({
    wallet,
    material,
    amount,
    recipient,
    proverAdapter,
    signal,
    denom,
    assetDenom,
    scan,
    after,
    afterHeight,
    after_height,
    afterSequence,
    after_sequence,
    page,
    limit = 200,
    maxPages = defaultPrepareScanMaxPages,
    max_pages,
    eventTypes,
    event_types,
    outputLimit,
    output_limit,
    eventLimit,
    event_limit,
    maxEncodedBytes,
    max_encoded_bytes,
    scanSource,
    scan_source,
    expiresAtUnix,
    chainNowUnix,
    chain_now_unix,
    reservationManager,
    reservation_manager
  } = {}) {
    const resolvedReservationManager = reservationManager ?? reservation_manager ?? null;
    const privacy = material || await this.deriveWalletPrivacyMaterial(wallet);
    const scanOptions = resolveScanOptions({
      scan,
      after,
      afterHeight,
      after_height,
      afterSequence,
      after_sequence,
      page,
      limit,
      maxPages,
      max_pages,
      eventTypes,
      event_types,
      outputLimit,
      output_limit,
      eventLimit,
      event_limit,
      maxEncodedBytes,
      max_encoded_bytes,
      scanSource,
      scan_source
    });
    const scanResult = await this.scanNotes({
      rootSeed: privacy.rootSeed,
      ...scanOptions,
      limit: scanOptions.limit ?? 200,
      maxPages: scanOptions.maxPages ?? defaultPrepareScanMaxPages,
      includeFoundNotes: true
    });
    const availableFoundNotes = await reservationAvailableNotes(resolvedReservationManager, scanResult.foundNotes);
    const plan = planWithdrawNotes({
      notes: availableFoundNotes,
      amount,
      denom: assetDenom ?? denom ?? this.defaultDenom
    });
    if (!plan.canBuildTx) {
      return {
        status: plan.status,
        plan,
        scan: scanResult,
        privacyAccount: publicPrivacyAccount(privacy)
      };
    }
    assertPlanCanBuildTx(plan);
    await this.assertProtocolPreflight(assetDenom ?? denom ?? this.defaultDenom);

    let reservationBatch = null;
    try {
      reservationBatch = await preparePlanReservation(resolvedReservationManager, {
        plan,
        kind: "relay_withdraw"
      });
      const heartbeatResult = await withReservationHeartbeat(resolvedReservationManager, reservationBatch, async ({ assertHeartbeatHealthy, heartbeatNow }) => {
        const built = await this.buildRelayWithdrawPayload({
          proverAdapter,
          notes: [plan.selectedNote],
          amount,
          assetDenom: assetDenom ?? denom ?? this.defaultDenom,
          recipient,
          rootSeed: privacy.rootSeed,
          chainId: this.chainId,
          expiresAtUnix,
          chainNowUnix: chainNowUnix ?? chain_now_unix,
          signal
        });
        assertHeartbeatHealthy();
        await heartbeatNow();
        await markReservationProofReady(resolvedReservationManager, reservationBatch, withdrawProofReadyMetadata(built));
        return { built };
      });
      const { built } = heartbeatResult;

      return {
        ...reservationReconciliationFields(heartbeatResult),
        status: "ready",
        plan,
        scan: scanResult,
        proverPayload: built.proverPayload,
        proof: built.proof,
        payload: built.payload,
        selectedNote: built.selectedNote,
        reservation: reservationBatchSummary(reservationBatch),
        privacyAccount: publicPrivacyAccount(privacy)
      };
    } catch (error) {
      await rollbackPlanReservationPreservingError(resolvedReservationManager, reservationBatch, error);
      throw error;
    }
  }

  async createDepositSignDoc(input) {
    return this.prepareDeposit(input);
  }

  async createTransferSignDoc(input) {
    const result = await this.prepareTransfer(input);
    if (result.status !== "ready") {
      throw new Error(result.plan?.message || `transfer is not ready: ${result.status}`);
    }
    return result;
  }

  async createTransferBatchSignDoc(input) {
    const result = await this.prepareTransferBatch(input);
    if (result.status !== "ready") {
      throw new Error(result.plan?.message || `transfer batch is not ready: ${result.status}`);
    }
    return result;
  }

  async createBatchTransferSignDoc({
    signer,
    pubKeyHex,
    gasLimit,
    message,
    memo = "Clairveil batch veiled transfer",
    expectedCircuitIdentity,
    chainNowUnix,
    chain_now_unix
  } = {}) {
    if (!this.enableExperimentalBatchTransfer) {
      throw new Error("one-proof batch transfer is feature-gated; construct the client with enableExperimentalBatchTransfer: true after completing downstream conformance and localnet validation");
    }
    if (!message || typeof message !== "object") {
      throw new Error("MsgBatchTransfer message is required");
    }
    if (chainNowUnix != null && chain_now_unix != null &&
        Number(chainNowUnix) !== Number(chain_now_unix)) {
      throw new Error("batch transfer chainNowUnix aliases conflict");
    }
    const normalizedMessage = MsgBatchTransfer.fromPartial(message);
    const normalizedSigner = String(signer || "").trim();
    const creator = String(normalizedMessage.creator || "").trim();
    if (!normalizedSigner || !creator || creator !== normalizedSigner) {
      throw new Error("MsgBatchTransfer creator must match the Cosmos sign-doc signer");
    }
    if (normalizedMessage.proof.length !== batchTransferProofSize) {
      throw new Error(`batch proof must be exactly ${batchTransferProofSize} bytes`);
    }
    const effects = validateBatchTransferEffectsV1(normalizedMessage);
    const resolvedNowUnix = normalizedBatchNowUnix(
      chainNowUnix ?? chain_now_unix ?? Math.floor(Date.now() / 1000)
    );
    if (BigInt(resolvedNowUnix) >= effects.expiresAtUnix) {
      throw new Error("MsgBatchTransfer expired before sign-doc creation");
    }
    const encodedMessage = MsgBatchTransfer.encode(normalizedMessage).finish();
    if (encodedMessage.length > maxBatchTransferMessageBytesV1) {
      throw new Error(`MsgBatchTransfer exceeds the ${maxBatchTransferMessageBytesV1}-byte hard cap`);
    }
    await this.assertCircuitConfig({ expectedCircuitIdentity });
    return this.buildDirectSignDoc({
      signer,
      pubKeyHex,
      gasLimit,
      messages: [{
        typeUrl: msgBatchTransferTypeUrl,
        value: normalizedMessage
      }],
      memo
    });
  }

  async createWithdrawSignDoc(input) {
    const result = await this.prepareWithdraw(input);
    if (result.status !== "ready") {
      throw new Error(result.plan?.message || `withdraw is not ready: ${result.status}`);
    }
    return result;
  }

  async createRelayWithdrawPayload(input) {
    const result = await this.prepareRelayWithdraw(input);
    if (result.status !== "ready") {
      throw new Error(result.plan?.message || `relay withdraw is not ready: ${result.status}`);
    }
    return result;
  }

  async buildPreparedTransferPayload(input) {
    const transferDenom = input?.transferDenom ?? input?.denom ?? this.defaultDenom;
    const transferProtocolConfig = await this.assertTransferProtocolConfig(transferDenom);
    const boundInput = bindRawTransferBuilderProtocolConfig(input, transferProtocolConfig);
    const merklePathProvider = input?.merklePathProvider ??
      await this.createTransferMerklePathSnapshotProvider(input?.inputs);
    return buildPreparedTransferPayloadCore({
      ...boundInput,
      merklePathProvider,
      shieldedPrefix: this.shieldedPrefix,
      transferDenom,
      chainId: input?.chainId ?? this.chainId
    });
  }

  async buildTransferMessage(input) {
    const transferDenom = input?.transferDenom ?? input?.denom ?? this.defaultDenom;
    const transferProtocolConfig = await this.assertTransferProtocolConfig(transferDenom);
    const boundInput = bindRawTransferBuilderProtocolConfig(input, transferProtocolConfig);
    const merklePathProvider = input?.merklePathProvider ??
      await this.createTransferMerklePathSnapshotProvider(input?.inputs);
    return buildTransferMessageCore({
      ...boundInput,
      merklePathProvider,
      shieldedPrefix: this.shieldedPrefix,
      transferDenom,
      chainId: input?.chainId ?? this.chainId,
      checkNullifiers: input?.checkNullifiers ?? (nullifiers => this.checkNullifiers(nullifiers))
    });
  }

  async buildPreparedWithdrawProverPayload(input) {
    const assetDenom = input?.assetDenom ?? input?.denom ?? this.defaultDenom;
    await this.assertProtocolPreflight(assetDenom);
    return buildPreparedWithdrawProverPayloadCore({
      merklePathProvider: this,
      accountPrefix: this.accountPrefix,
      assetDenom,
      ...input,
      chainId: input?.chainId ?? this.chainId
    });
  }

  async buildRelayWithdrawPayload(input) {
    const assetDenom = input?.assetDenom ?? input?.denom ?? this.defaultDenom;
    await this.assertProtocolPreflight(assetDenom);
    return buildRelayWithdrawPayloadCore({
      merklePathProvider: this,
      accountPrefix: this.accountPrefix,
      assetDenom,
      ...input,
      chainId: input?.chainId ?? this.chainId,
      checkNullifiers: input?.checkNullifiers ?? (nullifiers => this.checkNullifiers(nullifiers))
    });
  }

  async buildWithdrawMessage(input) {
    const assetDenom = input?.assetDenom ?? input?.denom ?? this.defaultDenom;
    await this.assertProtocolPreflight(assetDenom);
    return buildWithdrawMessageCore({
      merklePathProvider: this,
      accountPrefix: this.accountPrefix,
      assetDenom,
      ...input,
      chainId: input?.chainId ?? this.chainId,
      checkNullifiers: input?.checkNullifiers ?? (nullifiers => this.checkNullifiers(nullifiers))
    });
  }

  buildRelayWithdrawMessageFromPayload({
    payload,
    relayer,
    creator,
    chainNowUnix,
    nowUnix,
    expectedChainId,
    expectedRecipient,
    accountPrefix
  } = {}) {
    if (!payload) {
      throw new Error("payload is required for relay withdraw");
    }
    return buildRelayWithdrawMsgFromPayloadCore(payload, relayer ?? creator, {
      chainNowUnix: chainNowUnix ?? nowUnix,
      expectedChainId: expectedChainId ?? this.chainId,
      expectedRecipient,
      accountPrefix: accountPrefix ?? this.accountPrefix
    });
  }

  async createRelayWithdrawSignDoc({
    payload,
    relayer,
    creator,
    pubKeyHex,
    pub_key_hex,
    gasLimit = 5000000,
    feeAmount = [],
    memo = "Clairveil relay withdraw",
    chainNowUnix,
    nowUnix,
    expectedChainId,
    expectedRecipient,
    accountPrefix
  } = {}) {
    const signer = relayer ?? creator;
    const message = this.buildRelayWithdrawMessageFromPayload({
      payload,
      relayer: signer,
      chainNowUnix: chainNowUnix ?? nowUnix,
      expectedChainId,
      expectedRecipient,
      accountPrefix
    });
    const signDoc = await this.buildDirectSignDoc({
      signer: String(signer || ""),
      pubKeyHex: pubKeyHex ?? pub_key_hex,
      gasLimit,
      feeAmount,
      messages: [
        {
          typeUrl: msgWithdrawTypeUrl,
          value: message
        }
      ],
      memo
    });
    return {
      status: "ready",
      relayer: message.creator,
      payload,
      message,
      signDoc
    };
  }

  async decodeUserDisclosure({
    txHash,
    tx_hash,
    address,
    pubKeyHex,
    pub_key_hex,
    signatureBase64,
    signature_base64,
    skipSignerPubKeyCheck,
    skip_signer_pubkey_check,
    assetDenom,
    asset_denom,
    ...eventQuery
  }) {
    const normalizedTxHash = String(txHash ?? tx_hash ?? "").trim().toUpperCase();
    const event = await this.findPrivacyEventByTxHash(normalizedTxHash, eventQuery);
    const disclosureAssetDenom = resolveDisclosureAssetDenom(assetDenom, asset_denom, this.defaultDenom);
    if (eventAttribute(event, "user_disclosure_mode") === "USER_DISCLOSURE_MODE_PUBLIC") {
      return decodeUserDisclosureFromEvent(
        event,
        1n,
        "",
        normalizedTxHash,
        { shieldedPrefix: this.shieldedPrefix, assetDenom: disclosureAssetDenom }
      );
    }
    const signerPubKeyHex = pubKeyHex ?? pub_key_hex;
    const skipSignerCheck = Boolean(skipSignerPubKeyCheck ?? skip_signer_pubkey_check);
    if (!skipSignerCheck) {
      assertSignerPubKey(address, signerPubKeyHex, this.bech32Prefix);
    }
    const material = derivePrivacyMaterial({
      address,
      pubKeyHex: signerPubKeyHex,
      signatureBase64: signatureBase64 ?? signature_base64,
      shieldedPrefix: this.shieldedPrefix
    });
    return decodeUserDisclosureFromEvent(
      event,
      material.disclosureScalar,
      material.disclosurePubKeyHex,
      normalizedTxHash,
      { shieldedPrefix: this.shieldedPrefix, assetDenom: disclosureAssetDenom }
    );
  }

  async decodeSelfViewDisclosure({
    txHash,
    tx_hash,
    address,
    pubKeyHex,
    pub_key_hex,
    signatureBase64,
    signature_base64,
    skipSignerPubKeyCheck,
    skip_signer_pubkey_check,
    disclosureScalar,
    disclosure_scalar,
    disclosureScalarHex,
    disclosure_scalar_hex,
    assetDenom,
    asset_denom,
    ...eventQuery
  }) {
    const normalizedTxHash = String(txHash ?? tx_hash ?? "").trim().toUpperCase();
    const event = await this.findPrivacyEventByTxHash(normalizedTxHash, eventQuery);
    const disclosureAssetDenom = resolveDisclosureAssetDenom(assetDenom, asset_denom, this.defaultDenom);
    const directScalar = disclosureScalar ?? disclosure_scalar;
    const directScalarHex = disclosureScalarHex ?? disclosure_scalar_hex;
    if (directScalar != null || directScalarHex != null) {
      return decodeSelfViewDisclosureFromEvent(
        event,
        directScalar != null ? directScalar : disclosureScalarFromHex(directScalarHex),
        normalizedTxHash,
        { shieldedPrefix: this.shieldedPrefix, assetDenom: disclosureAssetDenom }
      );
    }
    const signerPubKeyHex = pubKeyHex ?? pub_key_hex;
    const skipSignerCheck = Boolean(skipSignerPubKeyCheck ?? skip_signer_pubkey_check);
    if (!skipSignerCheck) {
      assertSignerPubKey(address, signerPubKeyHex, this.bech32Prefix);
    }
    const material = derivePrivacyMaterial({
      address,
      pubKeyHex: signerPubKeyHex,
      signatureBase64: signatureBase64 ?? signature_base64,
      shieldedPrefix: this.shieldedPrefix
    });
    return decodeSelfViewDisclosureFromEvent(
      event,
      material.disclosureScalar,
      normalizedTxHash,
      { shieldedPrefix: this.shieldedPrefix, assetDenom: disclosureAssetDenom }
    );
  }

  async decodeAuditDisclosure({
    txHash,
    tx_hash,
    disclosurePrivKeyHex,
    disclosure_privkey_hex,
    assetDenom,
    asset_denom,
    ...eventQuery
  }) {
    const normalizedTxHash = String(txHash ?? tx_hash ?? "").trim().toUpperCase();
    const event = await this.findPrivacyEventByTxHash(normalizedTxHash, eventQuery);
    const disclosureAssetDenom = resolveDisclosureAssetDenom(assetDenom, asset_denom, this.defaultDenom);
    return decodeAuditDisclosureFromEvent(
      event,
      disclosureScalarFromHex(disclosurePrivKeyHex ?? disclosure_privkey_hex),
      normalizedTxHash,
      { shieldedPrefix: this.shieldedPrefix, assetDenom: disclosureAssetDenom }
    );
  }

  /**
   * Decode a Batch V1 user disclosure from a validated PrivacyScanOutputV2
   * record. Public records need no wallet material; recipient-encrypted
   * records can use either an explicit scalar/key pair or wallet-derived
   * privacy material.
   */
  async decodeBatchUserDisclosure({
    output,
    scanOutput,
    txHash,
    tx_hash,
    address,
    pubKeyHex,
    pub_key_hex,
    signatureBase64,
    signature_base64,
    skipSignerPubKeyCheck,
    skip_signer_pubkey_check,
    disclosureScalar,
    disclosure_scalar,
    disclosureScalarHex,
    disclosure_scalar_hex,
    disclosurePubKeyHex,
    disclosure_pubkey_hex,
    assetDenom,
    asset_denom
  } = {}) {
    const selectedOutput = output ?? scanOutput;
    if (!selectedOutput) throw new Error("Batch user disclosure requires a PrivacyScanOutputV2 output");
    const mode = selectedOutput.userDisclosureMode ?? selectedOutput.user_disclosure_mode;
    const isPublic = mode === 1 || mode === "1" || mode === "USER_DISCLOSURE_MODE_PUBLIC";
    const common = {
      txHash: txHash ?? tx_hash,
      shieldedPrefix: this.shieldedPrefix,
      assetDenom: resolveDisclosureAssetDenom(assetDenom, asset_denom, this.defaultDenom)
    };
    if (isPublic) return decodeBatchUserDisclosureFromScanOutput(selectedOutput, common);

    const directScalar = disclosureScalar ?? disclosure_scalar;
    const directScalarHex = disclosureScalarHex ?? disclosure_scalar_hex;
    const directPubKey = disclosurePubKeyHex ?? disclosure_pubkey_hex;
    if (directScalar != null || directScalarHex != null || directPubKey != null) {
      return decodeBatchUserDisclosureFromScanOutput(selectedOutput, {
        ...common,
        disclosureScalar: directScalar != null ? directScalar : disclosureScalarFromHex(directScalarHex),
        disclosurePubKeyHex: directPubKey
      });
    }
    const signerPubKeyHex = pubKeyHex ?? pub_key_hex;
    const skipSignerCheck = Boolean(skipSignerPubKeyCheck ?? skip_signer_pubkey_check);
    if (!skipSignerCheck) assertSignerPubKey(address, signerPubKeyHex, this.bech32Prefix);
    const material = derivePrivacyMaterial({
      address,
      pubKeyHex: signerPubKeyHex,
      signatureBase64: signatureBase64 ?? signature_base64,
      shieldedPrefix: this.shieldedPrefix
    });
    return decodeBatchUserDisclosureFromScanOutput(selectedOutput, {
      ...common,
      disclosureScalar: material.disclosureScalar,
      disclosurePubKeyHex: material.disclosurePubKeyHex
    });
  }

  /** Decode a Batch V1 self-view disclosure from a validated PrivacyScanOutputV2 record. */
  async decodeBatchSelfViewDisclosure({
    output,
    scanOutput,
    txHash,
    tx_hash,
    address,
    pubKeyHex,
    pub_key_hex,
    signatureBase64,
    signature_base64,
    skipSignerPubKeyCheck,
    skip_signer_pubkey_check,
    disclosureScalar,
    disclosure_scalar,
    disclosureScalarHex,
    disclosure_scalar_hex,
    assetDenom,
    asset_denom
  } = {}) {
    const selectedOutput = output ?? scanOutput;
    if (!selectedOutput) throw new Error("Batch self-view disclosure requires a PrivacyScanOutputV2 output");
    const common = {
      txHash: txHash ?? tx_hash,
      shieldedPrefix: this.shieldedPrefix,
      assetDenom: resolveDisclosureAssetDenom(assetDenom, asset_denom, this.defaultDenom)
    };
    const directScalar = disclosureScalar ?? disclosure_scalar;
    const directScalarHex = disclosureScalarHex ?? disclosure_scalar_hex;
    if (directScalar != null || directScalarHex != null) {
      return decodeBatchSelfViewDisclosureFromScanOutput(selectedOutput, {
        ...common,
        disclosureScalar: directScalar != null ? directScalar : disclosureScalarFromHex(directScalarHex)
      });
    }
    const signerPubKeyHex = pubKeyHex ?? pub_key_hex;
    const skipSignerCheck = Boolean(skipSignerPubKeyCheck ?? skip_signer_pubkey_check);
    if (!skipSignerCheck) assertSignerPubKey(address, signerPubKeyHex, this.bech32Prefix);
    const material = derivePrivacyMaterial({
      address,
      pubKeyHex: signerPubKeyHex,
      signatureBase64: signatureBase64 ?? signature_base64,
      shieldedPrefix: this.shieldedPrefix
    });
    return decodeBatchSelfViewDisclosureFromScanOutput(selectedOutput, {
      ...common,
      disclosureScalar: material.disclosureScalar
    });
  }

  /** Decode a Batch V1 auditor disclosure from a validated PrivacyScanOutputV2 record. */
  async decodeBatchAuditDisclosure({
    output,
    scanOutput,
    txHash,
    tx_hash,
    disclosurePrivKeyHex,
    disclosure_privkey_hex,
    disclosureScalar,
    disclosure_scalar,
    disclosureScalarHex,
    disclosure_scalar_hex,
    assetDenom,
    asset_denom
  } = {}) {
    const selectedOutput = output ?? scanOutput;
    if (!selectedOutput) throw new Error("Batch audit disclosure requires a PrivacyScanOutputV2 output");
    const directScalar = disclosureScalar ?? disclosure_scalar;
    const directScalarHex = disclosureScalarHex ?? disclosure_scalar_hex;
    return decodeBatchAuditDisclosureFromScanOutput(selectedOutput, {
      txHash: txHash ?? tx_hash,
      shieldedPrefix: this.shieldedPrefix,
      assetDenom: resolveDisclosureAssetDenom(assetDenom, asset_denom, this.defaultDenom),
      disclosureScalar: directScalar != null
        ? directScalar
        : disclosureScalarFromHex(directScalarHex ?? disclosurePrivKeyHex ?? disclosure_privkey_hex)
    });
  }

  async buildDirectSignDoc({ signer, pubKeyHex, messages, memo = "", gasLimit = 200000, feeAmount = [] }) {
    assertSignerPubKey(signer, pubKeyHex, this.bech32Prefix);
    const account = await this.getAccountInfo(signer);
    const pubkey = encodePubkey({
      type: "tendermint/PubKeySecp256k1",
      value: toBase64(fromHex(pubKeyHex, "pubKeyHex"))
    });
    const bodyBytes = this.registry.encodeTxBody({
      messages,
      memo
    });
    const authInfoBytes = makeAuthInfoBytes(
      [{ pubkey, sequence: account.sequence }],
      feeAmount,
      gasLimit,
      undefined,
      undefined
    );
    const signDoc = makeSignDoc(bodyBytes, authInfoBytes, this.chainId, account.accountNumber);
    return {
      bodyBytes: toBase64(signDoc.bodyBytes),
      authInfoBytes: toBase64(signDoc.authInfoBytes),
      chainId: signDoc.chainId,
      accountNumber: signDoc.accountNumber.toString()
    };
  }

  buildTxRawBytes({ bodyBytes, authInfoBytes, signature }) {
    const txRaw = TxRaw.fromPartial({
      bodyBytes: fromBase64(bodyBytes, "bodyBytes"),
      authInfoBytes: fromBase64(authInfoBytes, "authInfoBytes"),
      signatures: [fromBase64(signature, "signature")]
    });
    return TxRaw.encode(txRaw).finish();
  }

  async _broadcastTxRawBytes(txBytes, signedTx, waitOptions) {
    const reservationContext = broadcastReservationContext(waitOptions || signedTx || {});
    const signDocHash = cosmosSignDocBindingHash(signedTx);
    const reservationRequired = cosmosSignDocMetadata(signedTx).reservationRequired ||
      cosmosTxBodyRequiresReservation(signedTx);
    if (reservationRequired && !reservationContext) {
      throw new Error("prepared reserved Cosmos signed transaction requires reservationManager and reservation");
    }
    const txBytesHash = sha256Hex(txBytes);
    await validateRelayBroadcastContext(waitOptions || signedTx || {}, {
      expectedChainId: this.chainId,
      accountPrefix: this.accountPrefix,
      signedTx,
      reservationContext,
      signDocHash
    });
    const client = await this.connect();
    // Batch proof preparation checks nullifiers, but wallet signing can take
    // arbitrarily long. Re-read the exact persisted batch inputs at the final
    // broadcast boundary so a stale proof can never be submitted.
    await recheckReservedBatchTransferNullifiers(
      reservationContext,
      nullifiers => this.checkNullifiers(nullifiers)
    );
    await beginBroadcastReservation(
      reservationContext,
      "cosmos_broadcast_tx_sync",
      { txBytesHash, signDocHash }
    );
    let txhash = "";
    let tx;
    try {
      // Do not reconstruct TxRaw here: callers may have checkpointed the
      // exact wallet-produced bytes for crash-safe retransmission.
      txhash = await client.broadcastTxSync(Uint8Array.from(txBytes));
      tx = await this.waitForTx(txhash, waitOptions);
    } catch (error) {
      const wrapped = attachBroadcastEvidence(error, { txHash: txhash, txBytesHash });
      await markBroadcastReservationUnknown(reservationContext, wrapped, { txHash: txhash, txBytesHash });
      throw wrapped;
    }
    const rawTxCode = tx?.code;
    const txCode = typeof rawTxCode === "number"
      ? Number.isSafeInteger(rawTxCode) && rawTxCode >= 0 ? rawTxCode : null
      : typeof rawTxCode === "string" && /^(0|[1-9][0-9]*)$/.test(rawTxCode)
        ? Number(rawTxCode)
        : null;
    const rawLog = String(tx?.raw_log || "");
    const broadcast = {
      txhash,
      code: txCode,
      raw_log: tx ? rawLog : `transaction was broadcast but not found yet: ${txhash}`
    };
    if (tx && txCode !== 0) {
      const detail = txCode == null
        ? "missing or malformed code"
        : `code ${txCode}: ${rawLog || "no raw log"}`;
      const error = new Error(`broadcasted transaction did not include an explicit successful result (${detail})`);
      error.txhash = txhash;
      error.txHash = txhash;
      error.txBytesHash = txBytesHash;
      error.broadcast = broadcast;
      error.tx = tx;
      await markBroadcastReservationUnknown(reservationContext, error, { txHash: txhash, txBytesHash });
      throw error;
    }
    const result = {
      ok: Boolean(tx && txCode === 0),
      broadcast,
      tx,
      txBytesHash,
      error: tx ? "" : broadcast.raw_log
    };
    if (result.ok) {
      await markBroadcastReservationSubmitted(reservationContext, { txHash: txhash, txBytesHash });
    } else {
      await markBroadcastReservationUnknown(
        reservationContext,
        new Error(result.error),
        { txHash: txhash, txBytesHash }
      );
    }
    return result;
  }

  /**
   * Broadcast an exact pre-encoded TxRaw checkpoint. The bytes are decoded
   * only for reservation and relay validation and are never re-encoded before
   * the RPC boundary.
   */
  async broadcastTxRawBytes(txRawBytes, waitOptions) {
    const txBytes = normalizedTxRawBytes(txRawBytes);
    return this._broadcastTxRawBytes(txBytes, signedTxFromRawBytes(txBytes), waitOptions);
  }

  async broadcastSignedTx(signedTx, waitOptions) {
    const txBytes = this.buildTxRawBytes(signedTx);
    return this._broadcastTxRawBytes(txBytes, signedTx, waitOptions);
  }

  /**
   * Ask the wallet to sign, then return a checkpoint containing the exact
   * TxRaw bytes. Persist txRawBytes before calling broadcastTxRawBytes when a
   * process restart must be able to retransmit the same signed transaction.
   */
  async signDirect(input = {}) {
    const {
      wallet,
      walletSignDoc,
      reservationContext,
      signDocHash,
      broadcastOptions
    } = directBroadcastContext(input);
    const reservationRequired = cosmosSignDocMetadata(input.signDoc).reservationRequired ||
      cosmosTxBodyRequiresReservation(input.signDoc);
    if (reservationRequired && !reservationContext) {
      throw new Error("prepared reserved Cosmos sign doc requires reservationManager and reservation");
    }
    await validateRelayBroadcastContext(broadcastOptions, {
      expectedChainId: this.chainId,
      accountPrefix: this.accountPrefix,
      signedTx: walletSignDoc,
      reservationContext,
      signDocHash
    });
    const adapter = createWalletAdapter(wallet);
    let signed;
    try {
      signed = await adapter.signDirect(directSignDocFromBase64(walletSignDoc), {
        signDoc: walletSignDoc
      });
    } catch (error) {
      if (isExplicitWalletRejection(error)) {
        await markSigningReservationRejected(reservationContext, error);
      }
      throw error;
    }
    const signedDoc = signed.signed || {};
    const signature = signed.signature?.signature || signed.signature;
    const signedTx = {
      bodyBytes: toBase64(signedDoc.bodyBytes || fromBase64(walletSignDoc.bodyBytes, "bodyBytes")),
      authInfoBytes: toBase64(signedDoc.authInfoBytes || fromBase64(walletSignDoc.authInfoBytes, "authInfoBytes")),
      signature
    };
    const signedTxSignDocHash = cosmosSignDocBindingHash(signedTx);
    await validateRelayBroadcastContext(broadcastOptions, {
      expectedChainId: this.chainId,
      accountPrefix: this.accountPrefix,
      signedTx,
      reservationContext,
      signDocHash: signedTxSignDocHash
    });
    const txRawBytes = this.buildTxRawBytes(signedTx);
    return Object.freeze({
      signedTx: Object.freeze({ ...signedTx }),
      txRawBytes: Uint8Array.from(txRawBytes),
      txBytesHash: sha256Hex(txRawBytes),
      signDocHash: signedTxSignDocHash
    });
  }

  async signDirectAndBroadcast(input = {}) {
    const checkpoint = await this.signDirect(input);
    const { broadcastOptions } = directBroadcastContext(input);
    return this.broadcastTxRawBytes(checkpoint.txRawBytes, broadcastOptions);
  }
}

export function createClairveilClient(options) {
  return new ClairveilJS(options);
}
